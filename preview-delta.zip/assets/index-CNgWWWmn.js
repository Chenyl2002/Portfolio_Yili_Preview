const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./threejs-override-KmpEGO8-.js","./three.core-BZngiA0R.js","./Game-cVqG07WU.js","./preload-helper-PPVm8Dsz.js"])))=>i.map(i=>d[i]);
import { _ as u } from "./preload-helper-PPVm8Dsz.js";
import { R as f } from "./three.core-BZngiA0R.js";
(async () => {
  (function() {
    const a = document.createElement("link").relList;
    if (a && a.supports && a.supports("modulepreload")) return;
    for (const e of document.querySelectorAll('link[rel="modulepreload"]')) o(e);
    new MutationObserver((e) => {
      for (const t of e) if (t.type === "childList") for (const n of t.addedNodes) n.tagName === "LINK" && n.rel === "modulepreload" && o(n);
    }).observe(document, {
      childList: true,
      subtree: true
    });
    function i(e) {
      const t = {};
      return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), e.crossOrigin === "use-credentials" ? t.credentials = "include" : e.crossOrigin === "anonymous" ? t.credentials = "omit" : t.credentials = "same-origin", t;
    }
    function o(e) {
      if (e.ep) return;
      e.ep = true;
      const t = i(e);
      fetch(e.href, t);
    }
  })();
  function m({ document: r, reload: a = () => window.location.reload() }) {
    const i = r.querySelector(".js-graphics-fallback"), o = i.querySelector("h1"), e = i.querySelector("[data-fallback-status]"), t = i.querySelector("[data-fallback-retry]"), n = r.querySelector(".game");
    let l = false, s = false;
    return t.addEventListener("click", () => {
      if (!s) {
        s = true, t.disabled = true, t.setAttribute("aria-busy", "true"), e.textContent = "\u6B63\u5728\u91CD\u65B0\u8F7D\u5165\u9875\u9762\u5E76\u5C1D\u8BD5\u4E09\u7EF4\u573A\u666F\uFF1B\u5982\u679C\u4ECD\u4E0D\u53EF\u7528\uFF0C\u53EF\u7EE7\u7EED\u9605\u8BFB\u4E0B\u65B9\u4F5C\u54C1\u3002";
        try {
          a();
        } catch {
          s = false, t.disabled = false, t.removeAttribute("aria-busy"), e.textContent = "\u9875\u9762\u672A\u80FD\u91CD\u65B0\u8F7D\u5165\u3002\u53EF\u4F7F\u7528\u6D4F\u89C8\u5668\u5237\u65B0\uFF0C\u6216\u7EE7\u7EED\u9605\u8BFB\u4E0B\u65B9\u4F5C\u54C1\u3002";
        }
      }
    }), {
      show() {
        if (l) return false;
        l = true, r.documentElement.classList.add("is-graphics-fallback"), n.hidden = true, n.inert = true, n.setAttribute("aria-hidden", "true"), i.hidden = false, e.textContent = "\u4E09\u7EF4\u573A\u666F\u6682\u65F6\u65E0\u6CD5\u663E\u793A\uFF0C\u5DF2\u5207\u6362\u4E3A\u53EF\u76F4\u63A5\u9605\u8BFB\u7684\u4F5C\u54C1\u96C6\u3002\u9879\u76EE\u8D44\u6599\u4E0E\u8054\u7CFB\u65B9\u5F0F\u4ECD\u53EF\u4F7F\u7528\u3002";
        for (const c of i.querySelectorAll("img[data-fallback-src]")) c.src = c.dataset.fallbackSrc, c.removeAttribute("data-fallback-src");
        return o.focus({
          preventScroll: true
        }), true;
      }
    };
  }
  async function p({ createGame: r, fallback: a, onCreated: i = () => {
  } }) {
    let o;
    try {
      return o = await r(() => a.show()), i(o), await o.ready, o;
    } catch (e) {
      return o == null ? void 0 : o.failGraphics(e), a.show(), null;
    }
  }
  const d = `
\u9648\u5B9C\u7406 \xB7 \u5173\u5361\u4E0E\u73A9\u6CD5\u8BBE\u8BA1\u4F5C\u54C1\u96C6

\u6B64\u9875\u9762\u662F\u6280\u672F\u9884\u89C8\uFF0C\u4E2A\u4EBA\u9879\u76EE\u804C\u8D23\u5728\u4F5C\u54C1\u96C6\u9875\u9762\u4E2D\u5206\u522B\u6807\u6CE8\u3002
\u539F\u7248\u4E16\u754C\u3001\u9A7E\u9A76\u3001\u7269\u7406\u4E0E\u4EA4\u4E92\u57FA\u7840\u7531 Bruno Simon \u521B\u4F5C\u3002
\u539F\u7248\u6E90\u7801\uFF1Ahttps://github.com/brunosimon/folio-2025
Copyright (c) 2025 Bruno Simon.
\u5F00\u6E90\u8BB8\u53EF\u4E0E\u7B2C\u4E09\u65B9\u7248\u6743\u58F0\u660E\u89C1\u201C\u5236\u4F5C\u4E0E\u6765\u6E90\u201D\u3002

\u6E32\u67D3\uFF1AThree.js\uFF08\u7248\u672C ${f}\uFF09
\u7269\u7406\uFF1ARapier\u3002\u97F3\u9891\uFF1AHowler.js\u3002\u97F3\u4E50\uFF1AKounine\uFF08CC0\uFF09\u3002
\u5B57\u4F53\uFF1ANoto Sans CJK\uFF08SIL \u5F00\u653E\u5B57\u4F53\u8BB8\u53EF\uFF09\u3002

\u5728\u7F51\u5740\u672B\u5C3E\u6DFB\u52A0 #debug \u53EF\u6253\u5F00\u5F00\u53D1\u8C03\u8BD5\u9762\u677F\u3002
\u9762\u677F\u4E2D\u7684\u5DE5\u7A0B\u53C2\u6570\u540D\u79F0\u6CBF\u7528\u4EE3\u7801\u6807\u8BC6\u7B26\uFF0C\u4FBF\u4E8E\u6838\u5BF9\u6E90\u7801\u3002
\u6309 V \u5207\u6362\u81EA\u7531\u89C6\u89D2\uFF0C\u6309 H \u663E\u793A\u6216\u9690\u85CF\u8C03\u8BD5\u9762\u677F\u3002
`;
  for (let r = 0; r < d.length; r++) d[r].match(/[╔║═╗╚╝╔╝]/);
  const h = m({
    document
  });
  await p({
    fallback: h,
    createGame: async (r) => {
      document.fonts && await Promise.allSettled([
        document.fonts.load("400 20px Nunito"),
        document.fonts.load('700 20px "Amatic SC"'),
        document.fonts.load('500 20px "Pally-Medium"'),
        document.fonts.load('700 20px "Yili Sans"')
      ]), await u(() => import("./threejs-override-KmpEGO8-.js"), __vite__mapDeps([0,1]), import.meta.url);
      const { Game: a } = await u(async () => {
        const { Game: i } = await import("./Game-cVqG07WU.js").then(async (m2) => {
          await m2.__tla;
          return m2;
        }).then((o) => o.G);
        return {
          Game: i
        };
      }, __vite__mapDeps([2,3,1]), import.meta.url);
      return new a({
        onGraphicsFailure: r
      });
    },
    onCreated: (r) => {
    }
  });
})();
