const yd = "183", gd = { LEFT: 0, MIDDLE: 1, RIGHT: 2, ROTATE: 0, DOLLY: 1, PAN: 2 }, xd = { ROTATE: 0, PAN: 1, DOLLY_PAN: 2, DOLLY_ROTATE: 3 }, bd = 0, Md = 1, wd = 2, _d = 3, vd = 0, Sd = 1, Ad = 2, Td = 3, Yn = 0, hh = 1, Cd = 2, Id = 0, Xr = 1, zd = 2, Bd = 3, Fd = 4, kd = 5, Pd = 6, Zr = 100, Rd = 101, Od = 102, Ed = 103, Nd = 104, Ld = 200, Dd = 201, Vd = 202, Ud = 203, Yr = 204, $r = 205, Wd = 206, Gd = 207, qd = 208, Hd = 209, Jd = 210, Xd = 211, Zd = 212, Yd = 213, $d = 214, jr = 0, Qr = 1, Kr = 2, qs = 3, ta = 4, ea = 5, ia = 6, sa = 7, ar = 0, jd = 1, Qd = 2, Kd = 0, tp = 1, ep = 2, ip = 3, sp = 4, np = 5, rp = 6, ap = 7, na = "attached", lh = "detached", or = 300, sn = 301, ch = 302, uh = 303, dh = 304, ph = 306, $n = 1e3, Zt = 1001, jn = 1002, Bt = 1003, fh = 1004, op = 1004, mh = 1005, hp = 1005, Gt = 1006, yh = 1007, lp = 1007, hr = 1008, cp = 1008, lr = 1009, gh = 1010, xh = 1011, bh = 1012, Mh = 1013, nn = 1014, bi = 1015, wh = 1016, _h = 1017, vh = 1018, up = 1020, Sh = 35902, Ah = 35899, Th = 1021, Ch = 1022, Hi = 1023, Qn = 1026, Ih = 1027, Mo = 1028, wo = 1029, zh = 1030, Bh = 1031, dp = 1032, Fh = 1033, kh = 33776, Ph = 33777, Rh = 33778, Oh = 33779, Eh = 35840, Nh = 35841, Lh = 35842, Dh = 35843, Vh = 36196, Uh = 37492, Wh = 37496, Gh = 37488, qh = 37489, Hh = 37490, Jh = 37491, Xh = 37808, Zh = 37809, Yh = 37810, $h = 37811, jh = 37812, Qh = 37813, Kh = 37814, tl = 37815, el = 37816, il = 37817, sl = 37818, nl = 37819, rl = 37820, al = 37821, ol = 36492, hl = 36494, ll = 36495, cl = 36283, ul = 36284, dl = 36285, pl = 36286, fl = 2200, ml = 2201, yl = 2202, Hs = 2300, Kn = 2301, cn = 2302, ra = 2303, fi = 2400, mi = 2401, Js = 2402, cr = 2500, _o = 2501, pp = 0, fp = 1, mp = 2, gl = 3200, yp = 3201, gp = 3202, xp = 3203, vi = 0, bp = 1, vo = "", Ot = "srgb", aa = "srgb-linear", oa = "linear", un = "srgb", Mp = "", wp = "rg", _p = "ga", vp = 0, Je = 7680, Sp = 7681, Ap = 7682, Tp = 7683, Cp = 34055, Ip = 34056, zp = 5386, Bp = 512, Fp = 513, kp = 514, Pp = 515, Rp = 516, Op = 517, Ep = 518, ha = 519, Np = 512, Lp = 513, Dp = 514, Vp = 515, Up = 516, Wp = 517, Gp = 518, qp = 519, Xs = 35044, Hp = 35048, Jp = 35040, Xp = 35045, Zp = 35049, Yp = 35041, $p = 35046, jp = 35050, Qp = 35042, Kp = "100", tf = "300 es", Yt = 2e3, Mi = 2001, ef = { COMPUTE: "compute", RENDER: "render" }, sf = { PERSPECTIVE: "perspective", LINEAR: "linear", FLAT: "flat" }, nf = { NORMAL: "normal", CENTROID: "centroid", SAMPLE: "sample", FIRST: "first", EITHER: "either" }, rf = { TEXTURE_COMPARE: "depthTextureCompare" };
function xl(l) {
  for (let t = l.length - 1; t >= 0; --t) if (l[t] >= 65535) return true;
  return false;
}
const bl = { Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array };
function yi(l, t) {
  return new bl[l](t);
}
function So(l) {
  return ArrayBuffer.isView(l) && !(l instanceof DataView);
}
function Zs(l) {
  return document.createElementNS("http://www.w3.org/1999/xhtml", l);
}
function af() {
  const l = Zs("canvas");
  return l.style.display = "block", l;
}
const la = {};
let _e = null;
function of(l) {
  _e = l;
}
function hf() {
  return _e;
}
function ca(...l) {
  const t = "THREE." + l.shift();
  _e ? _e("log", t, ...l) : console.log(t, ...l);
}
function Ao(l) {
  const t = l[0];
  if (typeof t == "string" && t.startsWith("TSL:")) {
    const e = l[1];
    e && e.isStackTrace ? l[0] += " " + e.getLocation() : l[1] = 'Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.';
  }
  return l;
}
function N(...l) {
  l = Ao(l);
  const t = "THREE." + l.shift();
  if (_e) _e("warn", t, ...l);
  else {
    const e = l[0];
    e && e.isStackTrace ? console.warn(e.getError(t)) : console.warn(t, ...l);
  }
}
function Y(...l) {
  l = Ao(l);
  const t = "THREE." + l.shift();
  if (_e) _e("error", t, ...l);
  else {
    const e = l[0];
    e && e.isStackTrace ? console.error(e.getError(t)) : console.error(t, ...l);
  }
}
function ua(...l) {
  const t = l.join(" ");
  t in la || (la[t] = true, N(...l));
}
const lf = { [jr]: Qr, [Kr]: ia, [ta]: sa, [qs]: ea, [Qr]: jr, [ia]: Kr, [sa]: ta, [ea]: qs };
class Se {
  addEventListener(t, e) {
    this._listeners === void 0 && (this._listeners = {});
    const i = this._listeners;
    i[t] === void 0 && (i[t] = []), i[t].indexOf(e) === -1 && i[t].push(e);
  }
  hasEventListener(t, e) {
    const i = this._listeners;
    return i === void 0 ? false : i[t] !== void 0 && i[t].indexOf(e) !== -1;
  }
  removeEventListener(t, e) {
    const i = this._listeners;
    if (i === void 0) return;
    const s = i[t];
    if (s !== void 0) {
      const n = s.indexOf(e);
      n !== -1 && s.splice(n, 1);
    }
  }
  dispatchEvent(t) {
    const e = this._listeners;
    if (e === void 0) return;
    const i = e[t.type];
    if (i !== void 0) {
      t.target = this;
      const s = i.slice(0);
      for (let n = 0, r = s.length; n < r; n++) s[n].call(this, t);
      t.target = null;
    }
  }
}
const dt = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0a", "0b", "0c", "0d", "0e", "0f", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1a", "1b", "1c", "1d", "1e", "1f", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "2a", "2b", "2c", "2d", "2e", "2f", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "3a", "3b", "3c", "3d", "3e", "3f", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "4a", "4b", "4c", "4d", "4e", "4f", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "5a", "5b", "5c", "5d", "5e", "5f", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "6a", "6b", "6c", "6d", "6e", "6f", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "7a", "7b", "7c", "7d", "7e", "7f", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8a", "8b", "8c", "8d", "8e", "8f", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9a", "9b", "9c", "9d", "9e", "9f", "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "aa", "ab", "ac", "ad", "ae", "af", "b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "ba", "bb", "bc", "bd", "be", "bf", "c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "ca", "cb", "cc", "cd", "ce", "cf", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "da", "db", "dc", "dd", "de", "df", "e0", "e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8", "e9", "ea", "eb", "ec", "ed", "ee", "ef", "f0", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "fa", "fb", "fc", "fd", "fe", "ff"];
let da = 1234567;
const Ve = Math.PI / 180, Ji = 180 / Math.PI;
function zt() {
  const l = Math.random() * 4294967295 | 0, t = Math.random() * 4294967295 | 0, e = Math.random() * 4294967295 | 0, i = Math.random() * 4294967295 | 0;
  return (dt[l & 255] + dt[l >> 8 & 255] + dt[l >> 16 & 255] + dt[l >> 24 & 255] + "-" + dt[t & 255] + dt[t >> 8 & 255] + "-" + dt[t >> 16 & 15 | 64] + dt[t >> 24 & 255] + "-" + dt[e & 63 | 128] + dt[e >> 8 & 255] + "-" + dt[e >> 16 & 255] + dt[e >> 24 & 255] + dt[i & 255] + dt[i >> 8 & 255] + dt[i >> 16 & 255] + dt[i >> 24 & 255]).toLowerCase();
}
function L(l, t, e) {
  return Math.max(t, Math.min(e, l));
}
function ur(l, t) {
  return (l % t + t) % t;
}
function Ml(l, t, e, i, s) {
  return i + (l - t) * (s - i) / (e - t);
}
function wl(l, t, e) {
  return l !== t ? (e - l) / (t - l) : 0;
}
function Wi(l, t, e) {
  return (1 - e) * l + e * t;
}
function _l(l, t, e, i) {
  return Wi(l, t, 1 - Math.exp(-e * i));
}
function vl(l, t = 1) {
  return t - Math.abs(ur(l, t * 2) - t);
}
function Sl(l, t, e) {
  return l <= t ? 0 : l >= e ? 1 : (l = (l - t) / (e - t), l * l * (3 - 2 * l));
}
function Al(l, t, e) {
  return l <= t ? 0 : l >= e ? 1 : (l = (l - t) / (e - t), l * l * l * (l * (l * 6 - 15) + 10));
}
function Tl(l, t) {
  return l + Math.floor(Math.random() * (t - l + 1));
}
function Cl(l, t) {
  return l + Math.random() * (t - l);
}
function Il(l) {
  return l * (0.5 - Math.random());
}
function zl(l) {
  l !== void 0 && (da = l);
  let t = da += 1831565813;
  return t = Math.imul(t ^ t >>> 15, t | 1), t ^= t + Math.imul(t ^ t >>> 7, t | 61), ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function Bl(l) {
  return l * Ve;
}
function Fl(l) {
  return l * Ji;
}
function kl(l) {
  return (l & l - 1) === 0 && l !== 0;
}
function Pl(l) {
  return Math.pow(2, Math.ceil(Math.log(l) / Math.LN2));
}
function Rl(l) {
  return Math.pow(2, Math.floor(Math.log(l) / Math.LN2));
}
function Ol(l, t, e, i, s) {
  const n = Math.cos, r = Math.sin, a = n(e / 2), o = r(e / 2), h = n((t + i) / 2), c = r((t + i) / 2), u = n((t - i) / 2), d = r((t - i) / 2), p = n((i - t) / 2), f = r((i - t) / 2);
  switch (s) {
    case "XYX":
      l.set(a * c, o * u, o * d, a * h);
      break;
    case "YZY":
      l.set(o * d, a * c, o * u, a * h);
      break;
    case "ZXZ":
      l.set(o * u, o * d, a * c, a * h);
      break;
    case "XZX":
      l.set(a * c, o * f, o * p, a * h);
      break;
    case "YXY":
      l.set(o * p, a * c, o * f, a * h);
      break;
    case "ZYZ":
      l.set(o * f, o * p, a * c, a * h);
      break;
    default:
      N("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: " + s);
  }
}
function gt(l, t) {
  switch (t.constructor) {
    case Float32Array:
      return l;
    case Uint32Array:
      return l / 4294967295;
    case Uint16Array:
      return l / 65535;
    case Uint8Array:
      return l / 255;
    case Int32Array:
      return Math.max(l / 2147483647, -1);
    case Int16Array:
      return Math.max(l / 32767, -1);
    case Int8Array:
      return Math.max(l / 127, -1);
    default:
      throw new Error("Invalid component type.");
  }
}
function W(l, t) {
  switch (t.constructor) {
    case Float32Array:
      return l;
    case Uint32Array:
      return Math.round(l * 4294967295);
    case Uint16Array:
      return Math.round(l * 65535);
    case Uint8Array:
      return Math.round(l * 255);
    case Int32Array:
      return Math.round(l * 2147483647);
    case Int16Array:
      return Math.round(l * 32767);
    case Int8Array:
      return Math.round(l * 127);
    default:
      throw new Error("Invalid component type.");
  }
}
const cf = { DEG2RAD: Ve, RAD2DEG: Ji, generateUUID: zt, clamp: L, euclideanModulo: ur, mapLinear: Ml, inverseLerp: wl, lerp: Wi, damp: _l, pingpong: vl, smoothstep: Sl, smootherstep: Al, randInt: Tl, randFloat: Cl, randFloatSpread: Il, seededRandom: zl, degToRad: Bl, radToDeg: Fl, isPowerOfTwo: kl, ceilPowerOfTwo: Pl, floorPowerOfTwo: Rl, setQuaternionFromProperEuler: Ol, normalize: W, denormalize: gt };
class I {
  constructor(t = 0, e = 0) {
    I.prototype.isVector2 = true, this.x = t, this.y = e;
  }
  get width() {
    return this.x;
  }
  set width(t) {
    this.x = t;
  }
  get height() {
    return this.y;
  }
  set height(t) {
    this.y = t;
  }
  set(t, e) {
    return this.x = t, this.y = e, this;
  }
  setScalar(t) {
    return this.x = t, this.y = t, this;
  }
  setX(t) {
    return this.x = t, this;
  }
  setY(t) {
    return this.y = t, this;
  }
  setComponent(t, e) {
    switch (t) {
      case 0:
        this.x = e;
        break;
      case 1:
        this.y = e;
        break;
      default:
        throw new Error("index is out of range: " + t);
    }
    return this;
  }
  getComponent(t) {
    switch (t) {
      case 0:
        return this.x;
      case 1:
        return this.y;
      default:
        throw new Error("index is out of range: " + t);
    }
  }
  clone() {
    return new this.constructor(this.x, this.y);
  }
  copy(t) {
    return this.x = t.x, this.y = t.y, this;
  }
  add(t) {
    return this.x += t.x, this.y += t.y, this;
  }
  addScalar(t) {
    return this.x += t, this.y += t, this;
  }
  addVectors(t, e) {
    return this.x = t.x + e.x, this.y = t.y + e.y, this;
  }
  addScaledVector(t, e) {
    return this.x += t.x * e, this.y += t.y * e, this;
  }
  sub(t) {
    return this.x -= t.x, this.y -= t.y, this;
  }
  subScalar(t) {
    return this.x -= t, this.y -= t, this;
  }
  subVectors(t, e) {
    return this.x = t.x - e.x, this.y = t.y - e.y, this;
  }
  multiply(t) {
    return this.x *= t.x, this.y *= t.y, this;
  }
  multiplyScalar(t) {
    return this.x *= t, this.y *= t, this;
  }
  divide(t) {
    return this.x /= t.x, this.y /= t.y, this;
  }
  divideScalar(t) {
    return this.multiplyScalar(1 / t);
  }
  applyMatrix3(t) {
    const e = this.x, i = this.y, s = t.elements;
    return this.x = s[0] * e + s[3] * i + s[6], this.y = s[1] * e + s[4] * i + s[7], this;
  }
  min(t) {
    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this;
  }
  max(t) {
    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this;
  }
  clamp(t, e) {
    return this.x = L(this.x, t.x, e.x), this.y = L(this.y, t.y, e.y), this;
  }
  clampScalar(t, e) {
    return this.x = L(this.x, t, e), this.y = L(this.y, t, e), this;
  }
  clampLength(t, e) {
    const i = this.length();
    return this.divideScalar(i || 1).multiplyScalar(L(i, t, e));
  }
  floor() {
    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this;
  }
  ceil() {
    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this;
  }
  round() {
    return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
  }
  roundToZero() {
    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this;
  }
  negate() {
    return this.x = -this.x, this.y = -this.y, this;
  }
  dot(t) {
    return this.x * t.x + this.y * t.y;
  }
  cross(t) {
    return this.x * t.y - this.y * t.x;
  }
  lengthSq() {
    return this.x * this.x + this.y * this.y;
  }
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  }
  manhattanLength() {
    return Math.abs(this.x) + Math.abs(this.y);
  }
  normalize() {
    return this.divideScalar(this.length() || 1);
  }
  angle() {
    return Math.atan2(-this.y, -this.x) + Math.PI;
  }
  angleTo(t) {
    const e = Math.sqrt(this.lengthSq() * t.lengthSq());
    if (e === 0) return Math.PI / 2;
    const i = this.dot(t) / e;
    return Math.acos(L(i, -1, 1));
  }
  distanceTo(t) {
    return Math.sqrt(this.distanceToSquared(t));
  }
  distanceToSquared(t) {
    const e = this.x - t.x, i = this.y - t.y;
    return e * e + i * i;
  }
  manhattanDistanceTo(t) {
    return Math.abs(this.x - t.x) + Math.abs(this.y - t.y);
  }
  setLength(t) {
    return this.normalize().multiplyScalar(t);
  }
  lerp(t, e) {
    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this;
  }
  lerpVectors(t, e, i) {
    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this;
  }
  equals(t) {
    return t.x === this.x && t.y === this.y;
  }
  fromArray(t, e = 0) {
    return this.x = t[e], this.y = t[e + 1], this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this.x, t[e + 1] = this.y, t;
  }
  fromBufferAttribute(t, e) {
    return this.x = t.getX(e), this.y = t.getY(e), this;
  }
  rotateAround(t, e) {
    const i = Math.cos(e), s = Math.sin(e), n = this.x - t.x, r = this.y - t.y;
    return this.x = n * i - r * s + t.x, this.y = n * s + r * i + t.y, this;
  }
  random() {
    return this.x = Math.random(), this.y = Math.random(), this;
  }
  *[Symbol.iterator]() {
    yield this.x, yield this.y;
  }
}
class _t {
  constructor(t = 0, e = 0, i = 0, s = 1) {
    this.isQuaternion = true, this._x = t, this._y = e, this._z = i, this._w = s;
  }
  static slerpFlat(t, e, i, s, n, r, a) {
    let o = i[s + 0], h = i[s + 1], c = i[s + 2], u = i[s + 3], d = n[r + 0], p = n[r + 1], f = n[r + 2], m = n[r + 3];
    if (u !== m || o !== d || h !== p || c !== f) {
      let g = o * d + h * p + c * f + u * m;
      g < 0 && (d = -d, p = -p, f = -f, m = -m, g = -g);
      let y = 1 - a;
      if (g < 0.9995) {
        const x = Math.acos(g), b = Math.sin(x);
        y = Math.sin(y * x) / b, a = Math.sin(a * x) / b, o = o * y + d * a, h = h * y + p * a, c = c * y + f * a, u = u * y + m * a;
      } else {
        o = o * y + d * a, h = h * y + p * a, c = c * y + f * a, u = u * y + m * a;
        const x = 1 / Math.sqrt(o * o + h * h + c * c + u * u);
        o *= x, h *= x, c *= x, u *= x;
      }
    }
    t[e] = o, t[e + 1] = h, t[e + 2] = c, t[e + 3] = u;
  }
  static multiplyQuaternionsFlat(t, e, i, s, n, r) {
    const a = i[s], o = i[s + 1], h = i[s + 2], c = i[s + 3], u = n[r], d = n[r + 1], p = n[r + 2], f = n[r + 3];
    return t[e] = a * f + c * u + o * p - h * d, t[e + 1] = o * f + c * d + h * u - a * p, t[e + 2] = h * f + c * p + a * d - o * u, t[e + 3] = c * f - a * u - o * d - h * p, t;
  }
  get x() {
    return this._x;
  }
  set x(t) {
    this._x = t, this._onChangeCallback();
  }
  get y() {
    return this._y;
  }
  set y(t) {
    this._y = t, this._onChangeCallback();
  }
  get z() {
    return this._z;
  }
  set z(t) {
    this._z = t, this._onChangeCallback();
  }
  get w() {
    return this._w;
  }
  set w(t) {
    this._w = t, this._onChangeCallback();
  }
  set(t, e, i, s) {
    return this._x = t, this._y = e, this._z = i, this._w = s, this._onChangeCallback(), this;
  }
  clone() {
    return new this.constructor(this._x, this._y, this._z, this._w);
  }
  copy(t) {
    return this._x = t.x, this._y = t.y, this._z = t.z, this._w = t.w, this._onChangeCallback(), this;
  }
  setFromEuler(t, e = true) {
    const i = t._x, s = t._y, n = t._z, r = t._order, a = Math.cos, o = Math.sin, h = a(i / 2), c = a(s / 2), u = a(n / 2), d = o(i / 2), p = o(s / 2), f = o(n / 2);
    switch (r) {
      case "XYZ":
        this._x = d * c * u + h * p * f, this._y = h * p * u - d * c * f, this._z = h * c * f + d * p * u, this._w = h * c * u - d * p * f;
        break;
      case "YXZ":
        this._x = d * c * u + h * p * f, this._y = h * p * u - d * c * f, this._z = h * c * f - d * p * u, this._w = h * c * u + d * p * f;
        break;
      case "ZXY":
        this._x = d * c * u - h * p * f, this._y = h * p * u + d * c * f, this._z = h * c * f + d * p * u, this._w = h * c * u - d * p * f;
        break;
      case "ZYX":
        this._x = d * c * u - h * p * f, this._y = h * p * u + d * c * f, this._z = h * c * f - d * p * u, this._w = h * c * u + d * p * f;
        break;
      case "YZX":
        this._x = d * c * u + h * p * f, this._y = h * p * u + d * c * f, this._z = h * c * f - d * p * u, this._w = h * c * u - d * p * f;
        break;
      case "XZY":
        this._x = d * c * u - h * p * f, this._y = h * p * u - d * c * f, this._z = h * c * f + d * p * u, this._w = h * c * u + d * p * f;
        break;
      default:
        N("Quaternion: .setFromEuler() encountered an unknown order: " + r);
    }
    return e === true && this._onChangeCallback(), this;
  }
  setFromAxisAngle(t, e) {
    const i = e / 2, s = Math.sin(i);
    return this._x = t.x * s, this._y = t.y * s, this._z = t.z * s, this._w = Math.cos(i), this._onChangeCallback(), this;
  }
  setFromRotationMatrix(t) {
    const e = t.elements, i = e[0], s = e[4], n = e[8], r = e[1], a = e[5], o = e[9], h = e[2], c = e[6], u = e[10], d = i + a + u;
    if (d > 0) {
      const p = 0.5 / Math.sqrt(d + 1);
      this._w = 0.25 / p, this._x = (c - o) * p, this._y = (n - h) * p, this._z = (r - s) * p;
    } else if (i > a && i > u) {
      const p = 2 * Math.sqrt(1 + i - a - u);
      this._w = (c - o) / p, this._x = 0.25 * p, this._y = (s + r) / p, this._z = (n + h) / p;
    } else if (a > u) {
      const p = 2 * Math.sqrt(1 + a - i - u);
      this._w = (n - h) / p, this._x = (s + r) / p, this._y = 0.25 * p, this._z = (o + c) / p;
    } else {
      const p = 2 * Math.sqrt(1 + u - i - a);
      this._w = (r - s) / p, this._x = (n + h) / p, this._y = (o + c) / p, this._z = 0.25 * p;
    }
    return this._onChangeCallback(), this;
  }
  setFromUnitVectors(t, e) {
    let i = t.dot(e) + 1;
    return i < 1e-8 ? (i = 0, Math.abs(t.x) > Math.abs(t.z) ? (this._x = -t.y, this._y = t.x, this._z = 0, this._w = i) : (this._x = 0, this._y = -t.z, this._z = t.y, this._w = i)) : (this._x = t.y * e.z - t.z * e.y, this._y = t.z * e.x - t.x * e.z, this._z = t.x * e.y - t.y * e.x, this._w = i), this.normalize();
  }
  angleTo(t) {
    return 2 * Math.acos(Math.abs(L(this.dot(t), -1, 1)));
  }
  rotateTowards(t, e) {
    const i = this.angleTo(t);
    if (i === 0) return this;
    const s = Math.min(1, e / i);
    return this.slerp(t, s), this;
  }
  identity() {
    return this.set(0, 0, 0, 1);
  }
  invert() {
    return this.conjugate();
  }
  conjugate() {
    return this._x *= -1, this._y *= -1, this._z *= -1, this._onChangeCallback(), this;
  }
  dot(t) {
    return this._x * t._x + this._y * t._y + this._z * t._z + this._w * t._w;
  }
  lengthSq() {
    return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
  }
  length() {
    return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
  }
  normalize() {
    let t = this.length();
    return t === 0 ? (this._x = 0, this._y = 0, this._z = 0, this._w = 1) : (t = 1 / t, this._x = this._x * t, this._y = this._y * t, this._z = this._z * t, this._w = this._w * t), this._onChangeCallback(), this;
  }
  multiply(t) {
    return this.multiplyQuaternions(this, t);
  }
  premultiply(t) {
    return this.multiplyQuaternions(t, this);
  }
  multiplyQuaternions(t, e) {
    const i = t._x, s = t._y, n = t._z, r = t._w, a = e._x, o = e._y, h = e._z, c = e._w;
    return this._x = i * c + r * a + s * h - n * o, this._y = s * c + r * o + n * a - i * h, this._z = n * c + r * h + i * o - s * a, this._w = r * c - i * a - s * o - n * h, this._onChangeCallback(), this;
  }
  slerp(t, e) {
    let i = t._x, s = t._y, n = t._z, r = t._w, a = this.dot(t);
    a < 0 && (i = -i, s = -s, n = -n, r = -r, a = -a);
    let o = 1 - e;
    if (a < 0.9995) {
      const h = Math.acos(a), c = Math.sin(h);
      o = Math.sin(o * h) / c, e = Math.sin(e * h) / c, this._x = this._x * o + i * e, this._y = this._y * o + s * e, this._z = this._z * o + n * e, this._w = this._w * o + r * e, this._onChangeCallback();
    } else this._x = this._x * o + i * e, this._y = this._y * o + s * e, this._z = this._z * o + n * e, this._w = this._w * o + r * e, this.normalize();
    return this;
  }
  slerpQuaternions(t, e, i) {
    return this.copy(t).slerp(e, i);
  }
  random() {
    const t = 2 * Math.PI * Math.random(), e = 2 * Math.PI * Math.random(), i = Math.random(), s = Math.sqrt(1 - i), n = Math.sqrt(i);
    return this.set(s * Math.sin(t), s * Math.cos(t), n * Math.sin(e), n * Math.cos(e));
  }
  equals(t) {
    return t._x === this._x && t._y === this._y && t._z === this._z && t._w === this._w;
  }
  fromArray(t, e = 0) {
    return this._x = t[e], this._y = t[e + 1], this._z = t[e + 2], this._w = t[e + 3], this._onChangeCallback(), this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this._x, t[e + 1] = this._y, t[e + 2] = this._z, t[e + 3] = this._w, t;
  }
  fromBufferAttribute(t, e) {
    return this._x = t.getX(e), this._y = t.getY(e), this._z = t.getZ(e), this._w = t.getW(e), this._onChangeCallback(), this;
  }
  toJSON() {
    return this.toArray();
  }
  _onChange(t) {
    return this._onChangeCallback = t, this;
  }
  _onChangeCallback() {
  }
  *[Symbol.iterator]() {
    yield this._x, yield this._y, yield this._z, yield this._w;
  }
}
class w {
  constructor(t = 0, e = 0, i = 0) {
    w.prototype.isVector3 = true, this.x = t, this.y = e, this.z = i;
  }
  set(t, e, i) {
    return i === void 0 && (i = this.z), this.x = t, this.y = e, this.z = i, this;
  }
  setScalar(t) {
    return this.x = t, this.y = t, this.z = t, this;
  }
  setX(t) {
    return this.x = t, this;
  }
  setY(t) {
    return this.y = t, this;
  }
  setZ(t) {
    return this.z = t, this;
  }
  setComponent(t, e) {
    switch (t) {
      case 0:
        this.x = e;
        break;
      case 1:
        this.y = e;
        break;
      case 2:
        this.z = e;
        break;
      default:
        throw new Error("index is out of range: " + t);
    }
    return this;
  }
  getComponent(t) {
    switch (t) {
      case 0:
        return this.x;
      case 1:
        return this.y;
      case 2:
        return this.z;
      default:
        throw new Error("index is out of range: " + t);
    }
  }
  clone() {
    return new this.constructor(this.x, this.y, this.z);
  }
  copy(t) {
    return this.x = t.x, this.y = t.y, this.z = t.z, this;
  }
  add(t) {
    return this.x += t.x, this.y += t.y, this.z += t.z, this;
  }
  addScalar(t) {
    return this.x += t, this.y += t, this.z += t, this;
  }
  addVectors(t, e) {
    return this.x = t.x + e.x, this.y = t.y + e.y, this.z = t.z + e.z, this;
  }
  addScaledVector(t, e) {
    return this.x += t.x * e, this.y += t.y * e, this.z += t.z * e, this;
  }
  sub(t) {
    return this.x -= t.x, this.y -= t.y, this.z -= t.z, this;
  }
  subScalar(t) {
    return this.x -= t, this.y -= t, this.z -= t, this;
  }
  subVectors(t, e) {
    return this.x = t.x - e.x, this.y = t.y - e.y, this.z = t.z - e.z, this;
  }
  multiply(t) {
    return this.x *= t.x, this.y *= t.y, this.z *= t.z, this;
  }
  multiplyScalar(t) {
    return this.x *= t, this.y *= t, this.z *= t, this;
  }
  multiplyVectors(t, e) {
    return this.x = t.x * e.x, this.y = t.y * e.y, this.z = t.z * e.z, this;
  }
  applyEuler(t) {
    return this.applyQuaternion(pa.setFromEuler(t));
  }
  applyAxisAngle(t, e) {
    return this.applyQuaternion(pa.setFromAxisAngle(t, e));
  }
  applyMatrix3(t) {
    const e = this.x, i = this.y, s = this.z, n = t.elements;
    return this.x = n[0] * e + n[3] * i + n[6] * s, this.y = n[1] * e + n[4] * i + n[7] * s, this.z = n[2] * e + n[5] * i + n[8] * s, this;
  }
  applyNormalMatrix(t) {
    return this.applyMatrix3(t).normalize();
  }
  applyMatrix4(t) {
    const e = this.x, i = this.y, s = this.z, n = t.elements, r = 1 / (n[3] * e + n[7] * i + n[11] * s + n[15]);
    return this.x = (n[0] * e + n[4] * i + n[8] * s + n[12]) * r, this.y = (n[1] * e + n[5] * i + n[9] * s + n[13]) * r, this.z = (n[2] * e + n[6] * i + n[10] * s + n[14]) * r, this;
  }
  applyQuaternion(t) {
    const e = this.x, i = this.y, s = this.z, n = t.x, r = t.y, a = t.z, o = t.w, h = 2 * (r * s - a * i), c = 2 * (a * e - n * s), u = 2 * (n * i - r * e);
    return this.x = e + o * h + r * u - a * c, this.y = i + o * c + a * h - n * u, this.z = s + o * u + n * c - r * h, this;
  }
  project(t) {
    return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix);
  }
  unproject(t) {
    return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld);
  }
  transformDirection(t) {
    const e = this.x, i = this.y, s = this.z, n = t.elements;
    return this.x = n[0] * e + n[4] * i + n[8] * s, this.y = n[1] * e + n[5] * i + n[9] * s, this.z = n[2] * e + n[6] * i + n[10] * s, this.normalize();
  }
  divide(t) {
    return this.x /= t.x, this.y /= t.y, this.z /= t.z, this;
  }
  divideScalar(t) {
    return this.multiplyScalar(1 / t);
  }
  min(t) {
    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this.z = Math.min(this.z, t.z), this;
  }
  max(t) {
    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this.z = Math.max(this.z, t.z), this;
  }
  clamp(t, e) {
    return this.x = L(this.x, t.x, e.x), this.y = L(this.y, t.y, e.y), this.z = L(this.z, t.z, e.z), this;
  }
  clampScalar(t, e) {
    return this.x = L(this.x, t, e), this.y = L(this.y, t, e), this.z = L(this.z, t, e), this;
  }
  clampLength(t, e) {
    const i = this.length();
    return this.divideScalar(i || 1).multiplyScalar(L(i, t, e));
  }
  floor() {
    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), this;
  }
  ceil() {
    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), this;
  }
  round() {
    return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), this;
  }
  roundToZero() {
    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this.z = Math.trunc(this.z), this;
  }
  negate() {
    return this.x = -this.x, this.y = -this.y, this.z = -this.z, this;
  }
  dot(t) {
    return this.x * t.x + this.y * t.y + this.z * t.z;
  }
  lengthSq() {
    return this.x * this.x + this.y * this.y + this.z * this.z;
  }
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
  }
  manhattanLength() {
    return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z);
  }
  normalize() {
    return this.divideScalar(this.length() || 1);
  }
  setLength(t) {
    return this.normalize().multiplyScalar(t);
  }
  lerp(t, e) {
    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this.z += (t.z - this.z) * e, this;
  }
  lerpVectors(t, e, i) {
    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this.z = t.z + (e.z - t.z) * i, this;
  }
  cross(t) {
    return this.crossVectors(this, t);
  }
  crossVectors(t, e) {
    const i = t.x, s = t.y, n = t.z, r = e.x, a = e.y, o = e.z;
    return this.x = s * o - n * a, this.y = n * r - i * o, this.z = i * a - s * r, this;
  }
  projectOnVector(t) {
    const e = t.lengthSq();
    if (e === 0) return this.set(0, 0, 0);
    const i = t.dot(this) / e;
    return this.copy(t).multiplyScalar(i);
  }
  projectOnPlane(t) {
    return dn.copy(this).projectOnVector(t), this.sub(dn);
  }
  reflect(t) {
    return this.sub(dn.copy(t).multiplyScalar(2 * this.dot(t)));
  }
  angleTo(t) {
    const e = Math.sqrt(this.lengthSq() * t.lengthSq());
    if (e === 0) return Math.PI / 2;
    const i = this.dot(t) / e;
    return Math.acos(L(i, -1, 1));
  }
  distanceTo(t) {
    return Math.sqrt(this.distanceToSquared(t));
  }
  distanceToSquared(t) {
    const e = this.x - t.x, i = this.y - t.y, s = this.z - t.z;
    return e * e + i * i + s * s;
  }
  manhattanDistanceTo(t) {
    return Math.abs(this.x - t.x) + Math.abs(this.y - t.y) + Math.abs(this.z - t.z);
  }
  setFromSpherical(t) {
    return this.setFromSphericalCoords(t.radius, t.phi, t.theta);
  }
  setFromSphericalCoords(t, e, i) {
    const s = Math.sin(e) * t;
    return this.x = s * Math.sin(i), this.y = Math.cos(e) * t, this.z = s * Math.cos(i), this;
  }
  setFromCylindrical(t) {
    return this.setFromCylindricalCoords(t.radius, t.theta, t.y);
  }
  setFromCylindricalCoords(t, e, i) {
    return this.x = t * Math.sin(e), this.y = i, this.z = t * Math.cos(e), this;
  }
  setFromMatrixPosition(t) {
    const e = t.elements;
    return this.x = e[12], this.y = e[13], this.z = e[14], this;
  }
  setFromMatrixScale(t) {
    const e = this.setFromMatrixColumn(t, 0).length(), i = this.setFromMatrixColumn(t, 1).length(), s = this.setFromMatrixColumn(t, 2).length();
    return this.x = e, this.y = i, this.z = s, this;
  }
  setFromMatrixColumn(t, e) {
    return this.fromArray(t.elements, e * 4);
  }
  setFromMatrix3Column(t, e) {
    return this.fromArray(t.elements, e * 3);
  }
  setFromEuler(t) {
    return this.x = t._x, this.y = t._y, this.z = t._z, this;
  }
  setFromColor(t) {
    return this.x = t.r, this.y = t.g, this.z = t.b, this;
  }
  equals(t) {
    return t.x === this.x && t.y === this.y && t.z === this.z;
  }
  fromArray(t, e = 0) {
    return this.x = t[e], this.y = t[e + 1], this.z = t[e + 2], this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this.x, t[e + 1] = this.y, t[e + 2] = this.z, t;
  }
  fromBufferAttribute(t, e) {
    return this.x = t.getX(e), this.y = t.getY(e), this.z = t.getZ(e), this;
  }
  random() {
    return this.x = Math.random(), this.y = Math.random(), this.z = Math.random(), this;
  }
  randomDirection() {
    const t = Math.random() * Math.PI * 2, e = Math.random() * 2 - 1, i = Math.sqrt(1 - e * e);
    return this.x = i * Math.cos(t), this.y = e, this.z = i * Math.sin(t), this;
  }
  *[Symbol.iterator]() {
    yield this.x, yield this.y, yield this.z;
  }
}
const dn = new w(), pa = new _t();
class Qt {
  constructor(t, e, i, s, n, r, a, o, h) {
    Qt.prototype.isMatrix3 = true, this.elements = [1, 0, 0, 0, 1, 0, 0, 0, 1], t !== void 0 && this.set(t, e, i, s, n, r, a, o, h);
  }
  set(t, e, i, s, n, r, a, o, h) {
    const c = this.elements;
    return c[0] = t, c[1] = s, c[2] = a, c[3] = e, c[4] = n, c[5] = o, c[6] = i, c[7] = r, c[8] = h, this;
  }
  identity() {
    return this.set(1, 0, 0, 0, 1, 0, 0, 0, 1), this;
  }
  copy(t) {
    const e = this.elements, i = t.elements;
    return e[0] = i[0], e[1] = i[1], e[2] = i[2], e[3] = i[3], e[4] = i[4], e[5] = i[5], e[6] = i[6], e[7] = i[7], e[8] = i[8], this;
  }
  extractBasis(t, e, i) {
    return t.setFromMatrix3Column(this, 0), e.setFromMatrix3Column(this, 1), i.setFromMatrix3Column(this, 2), this;
  }
  setFromMatrix4(t) {
    const e = t.elements;
    return this.set(e[0], e[4], e[8], e[1], e[5], e[9], e[2], e[6], e[10]), this;
  }
  multiply(t) {
    return this.multiplyMatrices(this, t);
  }
  premultiply(t) {
    return this.multiplyMatrices(t, this);
  }
  multiplyMatrices(t, e) {
    const i = t.elements, s = e.elements, n = this.elements, r = i[0], a = i[3], o = i[6], h = i[1], c = i[4], u = i[7], d = i[2], p = i[5], f = i[8], m = s[0], g = s[3], y = s[6], x = s[1], b = s[4], M = s[7], _ = s[2], v = s[5], A = s[8];
    return n[0] = r * m + a * x + o * _, n[3] = r * g + a * b + o * v, n[6] = r * y + a * M + o * A, n[1] = h * m + c * x + u * _, n[4] = h * g + c * b + u * v, n[7] = h * y + c * M + u * A, n[2] = d * m + p * x + f * _, n[5] = d * g + p * b + f * v, n[8] = d * y + p * M + f * A, this;
  }
  multiplyScalar(t) {
    const e = this.elements;
    return e[0] *= t, e[3] *= t, e[6] *= t, e[1] *= t, e[4] *= t, e[7] *= t, e[2] *= t, e[5] *= t, e[8] *= t, this;
  }
  determinant() {
    const t = this.elements, e = t[0], i = t[1], s = t[2], n = t[3], r = t[4], a = t[5], o = t[6], h = t[7], c = t[8];
    return e * r * c - e * a * h - i * n * c + i * a * o + s * n * h - s * r * o;
  }
  invert() {
    const t = this.elements, e = t[0], i = t[1], s = t[2], n = t[3], r = t[4], a = t[5], o = t[6], h = t[7], c = t[8], u = c * r - a * h, d = a * o - c * n, p = h * n - r * o, f = e * u + i * d + s * p;
    if (f === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0);
    const m = 1 / f;
    return t[0] = u * m, t[1] = (s * h - c * i) * m, t[2] = (a * i - s * r) * m, t[3] = d * m, t[4] = (c * e - s * o) * m, t[5] = (s * n - a * e) * m, t[6] = p * m, t[7] = (i * o - h * e) * m, t[8] = (r * e - i * n) * m, this;
  }
  transpose() {
    let t;
    const e = this.elements;
    return t = e[1], e[1] = e[3], e[3] = t, t = e[2], e[2] = e[6], e[6] = t, t = e[5], e[5] = e[7], e[7] = t, this;
  }
  getNormalMatrix(t) {
    return this.setFromMatrix4(t).invert().transpose();
  }
  transposeIntoArray(t) {
    const e = this.elements;
    return t[0] = e[0], t[1] = e[3], t[2] = e[6], t[3] = e[1], t[4] = e[4], t[5] = e[7], t[6] = e[2], t[7] = e[5], t[8] = e[8], this;
  }
  setUvTransform(t, e, i, s, n, r, a) {
    const o = Math.cos(n), h = Math.sin(n);
    return this.set(i * o, i * h, -i * (o * r + h * a) + r + t, -s * h, s * o, -s * (-h * r + o * a) + a + e, 0, 0, 1), this;
  }
  scale(t, e) {
    return this.premultiply(pn.makeScale(t, e)), this;
  }
  rotate(t) {
    return this.premultiply(pn.makeRotation(-t)), this;
  }
  translate(t, e) {
    return this.premultiply(pn.makeTranslation(t, e)), this;
  }
  makeTranslation(t, e) {
    return t.isVector2 ? this.set(1, 0, t.x, 0, 1, t.y, 0, 0, 1) : this.set(1, 0, t, 0, 1, e, 0, 0, 1), this;
  }
  makeRotation(t) {
    const e = Math.cos(t), i = Math.sin(t);
    return this.set(e, -i, 0, i, e, 0, 0, 0, 1), this;
  }
  makeScale(t, e) {
    return this.set(t, 0, 0, 0, e, 0, 0, 0, 1), this;
  }
  equals(t) {
    const e = this.elements, i = t.elements;
    for (let s = 0; s < 9; s++) if (e[s] !== i[s]) return false;
    return true;
  }
  fromArray(t, e = 0) {
    for (let i = 0; i < 9; i++) this.elements[i] = t[i + e];
    return this;
  }
  toArray(t = [], e = 0) {
    const i = this.elements;
    return t[e] = i[0], t[e + 1] = i[1], t[e + 2] = i[2], t[e + 3] = i[3], t[e + 4] = i[4], t[e + 5] = i[5], t[e + 6] = i[6], t[e + 7] = i[7], t[e + 8] = i[8], t;
  }
  clone() {
    return new this.constructor().fromArray(this.elements);
  }
}
const pn = new Qt(), fa = new Qt().set(0.4123908, 0.3575843, 0.1804808, 0.212639, 0.7151687, 0.0721923, 0.0193308, 0.1191948, 0.9505322), ma = new Qt().set(3.2409699, -1.5373832, -0.4986108, -0.9692436, 1.8759675, 0.0415551, 0.0556301, -0.203977, 1.0569715);
function El() {
  const l = { enabled: true, workingColorSpace: aa, spaces: {}, convert: function(s, n, r) {
    return this.enabled === false || n === r || !n || !r || (this.spaces[n].transfer === un && (s.r = de(s.r), s.g = de(s.g), s.b = de(s.b)), this.spaces[n].primaries !== this.spaces[r].primaries && (s.applyMatrix3(this.spaces[n].toXYZ), s.applyMatrix3(this.spaces[r].fromXYZ)), this.spaces[r].transfer === un && (s.r = gi(s.r), s.g = gi(s.g), s.b = gi(s.b))), s;
  }, workingToColorSpace: function(s, n) {
    return this.convert(s, this.workingColorSpace, n);
  }, colorSpaceToWorking: function(s, n) {
    return this.convert(s, n, this.workingColorSpace);
  }, getPrimaries: function(s) {
    return this.spaces[s].primaries;
  }, getTransfer: function(s) {
    return s === vo ? oa : this.spaces[s].transfer;
  }, getToneMappingMode: function(s) {
    return this.spaces[s].outputColorSpaceConfig.toneMappingMode || "standard";
  }, getLuminanceCoefficients: function(s, n = this.workingColorSpace) {
    return s.fromArray(this.spaces[n].luminanceCoefficients);
  }, define: function(s) {
    Object.assign(this.spaces, s);
  }, _getMatrix: function(s, n, r) {
    return s.copy(this.spaces[n].toXYZ).multiply(this.spaces[r].fromXYZ);
  }, _getDrawingBufferColorSpace: function(s) {
    return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace;
  }, _getUnpackColorSpace: function(s = this.workingColorSpace) {
    return this.spaces[s].workingColorSpaceConfig.unpackColorSpace;
  }, fromWorkingColorSpace: function(s, n) {
    return ua("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."), l.workingToColorSpace(s, n);
  }, toWorkingColorSpace: function(s, n) {
    return ua("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."), l.colorSpaceToWorking(s, n);
  } }, t = [0.64, 0.33, 0.3, 0.6, 0.15, 0.06], e = [0.2126, 0.7152, 0.0722], i = [0.3127, 0.329];
  return l.define({ [aa]: { primaries: t, whitePoint: i, transfer: oa, toXYZ: fa, fromXYZ: ma, luminanceCoefficients: e, workingColorSpaceConfig: { unpackColorSpace: Ot }, outputColorSpaceConfig: { drawingBufferColorSpace: Ot } }, [Ot]: { primaries: t, whitePoint: i, transfer: un, toXYZ: fa, fromXYZ: ma, luminanceCoefficients: e, outputColorSpaceConfig: { drawingBufferColorSpace: Ot } } }), l;
}
const Rt = El();
function de(l) {
  return l < 0.04045 ? l * 0.0773993808 : Math.pow(l * 0.9478672986 + 0.0521327014, 2.4);
}
function gi(l) {
  return l < 31308e-7 ? l * 12.92 : 1.055 * Math.pow(l, 0.41666) - 0.055;
}
let Xe;
class Nl {
  static getDataURL(t, e = "image/png") {
    if (/^data:/i.test(t.src) || typeof HTMLCanvasElement > "u") return t.src;
    let i;
    if (t instanceof HTMLCanvasElement) i = t;
    else {
      Xe === void 0 && (Xe = Zs("canvas")), Xe.width = t.width, Xe.height = t.height;
      const s = Xe.getContext("2d");
      t instanceof ImageData ? s.putImageData(t, 0, 0) : s.drawImage(t, 0, 0, t.width, t.height), i = Xe;
    }
    return i.toDataURL(e);
  }
  static sRGBToLinear(t) {
    if (typeof HTMLImageElement < "u" && t instanceof HTMLImageElement || typeof HTMLCanvasElement < "u" && t instanceof HTMLCanvasElement || typeof ImageBitmap < "u" && t instanceof ImageBitmap) {
      const e = Zs("canvas");
      e.width = t.width, e.height = t.height;
      const i = e.getContext("2d");
      i.drawImage(t, 0, 0, t.width, t.height);
      const s = i.getImageData(0, 0, t.width, t.height), n = s.data;
      for (let r = 0; r < n.length; r++) n[r] = de(n[r] / 255) * 255;
      return i.putImageData(s, 0, 0), e;
    } else if (t.data) {
      const e = t.data.slice(0);
      for (let i = 0; i < e.length; i++) e instanceof Uint8Array || e instanceof Uint8ClampedArray ? e[i] = Math.floor(de(e[i] / 255) * 255) : e[i] = de(e[i]);
      return { data: e, width: t.width, height: t.height };
    } else return N("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."), t;
  }
}
let Ll = 0;
class Le {
  constructor(t = null) {
    this.isSource = true, Object.defineProperty(this, "id", { value: Ll++ }), this.uuid = zt(), this.data = t, this.dataReady = true, this.version = 0;
  }
  getSize(t) {
    const e = this.data;
    return typeof HTMLVideoElement < "u" && e instanceof HTMLVideoElement ? t.set(e.videoWidth, e.videoHeight, 0) : typeof VideoFrame < "u" && e instanceof VideoFrame ? t.set(e.displayHeight, e.displayWidth, 0) : e !== null ? t.set(e.width, e.height, e.depth || 0) : t.set(0, 0, 0), t;
  }
  set needsUpdate(t) {
    t === true && this.version++;
  }
  toJSON(t) {
    const e = t === void 0 || typeof t == "string";
    if (!e && t.images[this.uuid] !== void 0) return t.images[this.uuid];
    const i = { uuid: this.uuid, url: "" }, s = this.data;
    if (s !== null) {
      let n;
      if (Array.isArray(s)) {
        n = [];
        for (let r = 0, a = s.length; r < a; r++) s[r].isDataTexture ? n.push(fn(s[r].image)) : n.push(fn(s[r]));
      } else n = fn(s);
      i.url = n;
    }
    return e || (t.images[this.uuid] = i), i;
  }
}
function fn(l) {
  return typeof HTMLImageElement < "u" && l instanceof HTMLImageElement || typeof HTMLCanvasElement < "u" && l instanceof HTMLCanvasElement || typeof ImageBitmap < "u" && l instanceof ImageBitmap ? Nl.getDataURL(l) : l.data ? { data: Array.from(l.data), width: l.width, height: l.height, type: l.data.constructor.name } : (N("Texture: Unable to serialize Texture."), {});
}
let Dl = 0;
const mn = new w();
class lt extends Se {
  constructor(t = lt.DEFAULT_IMAGE, e = lt.DEFAULT_MAPPING, i = Zt, s = Zt, n = Gt, r = hr, a = Hi, o = lr, h = lt.DEFAULT_ANISOTROPY, c = vo) {
    super(), this.isTexture = true, Object.defineProperty(this, "id", { value: Dl++ }), this.uuid = zt(), this.name = "", this.source = new Le(t), this.mipmaps = [], this.mapping = e, this.channel = 0, this.wrapS = i, this.wrapT = s, this.magFilter = n, this.minFilter = r, this.anisotropy = h, this.format = a, this.internalFormat = null, this.type = o, this.offset = new I(0, 0), this.repeat = new I(1, 1), this.center = new I(0, 0), this.rotation = 0, this.matrixAutoUpdate = true, this.matrix = new Qt(), this.generateMipmaps = true, this.premultiplyAlpha = false, this.flipY = true, this.unpackAlignment = 4, this.colorSpace = c, this.userData = {}, this.updateRanges = [], this.version = 0, this.onUpdate = null, this.renderTarget = null, this.isRenderTargetTexture = false, this.isArrayTexture = !!(t && t.depth && t.depth > 1), this.pmremVersion = 0;
  }
  get width() {
    return this.source.getSize(mn).x;
  }
  get height() {
    return this.source.getSize(mn).y;
  }
  get depth() {
    return this.source.getSize(mn).z;
  }
  get image() {
    return this.source.data;
  }
  set image(t = null) {
    this.source.data = t;
  }
  updateMatrix() {
    this.matrix.setUvTransform(this.offset.x, this.offset.y, this.repeat.x, this.repeat.y, this.rotation, this.center.x, this.center.y);
  }
  addUpdateRange(t, e) {
    this.updateRanges.push({ start: t, count: e });
  }
  clearUpdateRanges() {
    this.updateRanges.length = 0;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    return this.name = t.name, this.source = t.source, this.mipmaps = t.mipmaps.slice(0), this.mapping = t.mapping, this.channel = t.channel, this.wrapS = t.wrapS, this.wrapT = t.wrapT, this.magFilter = t.magFilter, this.minFilter = t.minFilter, this.anisotropy = t.anisotropy, this.format = t.format, this.internalFormat = t.internalFormat, this.type = t.type, this.offset.copy(t.offset), this.repeat.copy(t.repeat), this.center.copy(t.center), this.rotation = t.rotation, this.matrixAutoUpdate = t.matrixAutoUpdate, this.matrix.copy(t.matrix), this.generateMipmaps = t.generateMipmaps, this.premultiplyAlpha = t.premultiplyAlpha, this.flipY = t.flipY, this.unpackAlignment = t.unpackAlignment, this.colorSpace = t.colorSpace, this.renderTarget = t.renderTarget, this.isRenderTargetTexture = t.isRenderTargetTexture, this.isArrayTexture = t.isArrayTexture, this.userData = JSON.parse(JSON.stringify(t.userData)), this.needsUpdate = true, this;
  }
  setValues(t) {
    for (const e in t) {
      const i = t[e];
      if (i === void 0) {
        N(`Texture.setValues(): parameter '${e}' has value of undefined.`);
        continue;
      }
      const s = this[e];
      if (s === void 0) {
        N(`Texture.setValues(): property '${e}' does not exist.`);
        continue;
      }
      s && i && s.isVector2 && i.isVector2 || s && i && s.isVector3 && i.isVector3 || s && i && s.isMatrix3 && i.isMatrix3 ? s.copy(i) : this[e] = i;
    }
  }
  toJSON(t) {
    const e = t === void 0 || typeof t == "string";
    if (!e && t.textures[this.uuid] !== void 0) return t.textures[this.uuid];
    const i = { metadata: { version: 4.7, type: "Texture", generator: "Texture.toJSON" }, uuid: this.uuid, name: this.name, image: this.source.toJSON(t).uuid, mapping: this.mapping, channel: this.channel, repeat: [this.repeat.x, this.repeat.y], offset: [this.offset.x, this.offset.y], center: [this.center.x, this.center.y], rotation: this.rotation, wrap: [this.wrapS, this.wrapT], format: this.format, internalFormat: this.internalFormat, type: this.type, colorSpace: this.colorSpace, minFilter: this.minFilter, magFilter: this.magFilter, anisotropy: this.anisotropy, flipY: this.flipY, generateMipmaps: this.generateMipmaps, premultiplyAlpha: this.premultiplyAlpha, unpackAlignment: this.unpackAlignment };
    return Object.keys(this.userData).length > 0 && (i.userData = this.userData), e || (t.textures[this.uuid] = i), i;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
  transformUv(t) {
    if (this.mapping !== or) return t;
    if (t.applyMatrix3(this.matrix), t.x < 0 || t.x > 1) switch (this.wrapS) {
      case $n:
        t.x = t.x - Math.floor(t.x);
        break;
      case Zt:
        t.x = t.x < 0 ? 0 : 1;
        break;
      case jn:
        Math.abs(Math.floor(t.x) % 2) === 1 ? t.x = Math.ceil(t.x) - t.x : t.x = t.x - Math.floor(t.x);
        break;
    }
    if (t.y < 0 || t.y > 1) switch (this.wrapT) {
      case $n:
        t.y = t.y - Math.floor(t.y);
        break;
      case Zt:
        t.y = t.y < 0 ? 0 : 1;
        break;
      case jn:
        Math.abs(Math.floor(t.y) % 2) === 1 ? t.y = Math.ceil(t.y) - t.y : t.y = t.y - Math.floor(t.y);
        break;
    }
    return this.flipY && (t.y = 1 - t.y), t;
  }
  set needsUpdate(t) {
    t === true && (this.version++, this.source.needsUpdate = true);
  }
  set needsPMREMUpdate(t) {
    t === true && this.pmremVersion++;
  }
}
lt.DEFAULT_IMAGE = null;
lt.DEFAULT_MAPPING = or;
lt.DEFAULT_ANISOTROPY = 1;
class Nt {
  constructor(t = 0, e = 0, i = 0, s = 1) {
    Nt.prototype.isVector4 = true, this.x = t, this.y = e, this.z = i, this.w = s;
  }
  get width() {
    return this.z;
  }
  set width(t) {
    this.z = t;
  }
  get height() {
    return this.w;
  }
  set height(t) {
    this.w = t;
  }
  set(t, e, i, s) {
    return this.x = t, this.y = e, this.z = i, this.w = s, this;
  }
  setScalar(t) {
    return this.x = t, this.y = t, this.z = t, this.w = t, this;
  }
  setX(t) {
    return this.x = t, this;
  }
  setY(t) {
    return this.y = t, this;
  }
  setZ(t) {
    return this.z = t, this;
  }
  setW(t) {
    return this.w = t, this;
  }
  setComponent(t, e) {
    switch (t) {
      case 0:
        this.x = e;
        break;
      case 1:
        this.y = e;
        break;
      case 2:
        this.z = e;
        break;
      case 3:
        this.w = e;
        break;
      default:
        throw new Error("index is out of range: " + t);
    }
    return this;
  }
  getComponent(t) {
    switch (t) {
      case 0:
        return this.x;
      case 1:
        return this.y;
      case 2:
        return this.z;
      case 3:
        return this.w;
      default:
        throw new Error("index is out of range: " + t);
    }
  }
  clone() {
    return new this.constructor(this.x, this.y, this.z, this.w);
  }
  copy(t) {
    return this.x = t.x, this.y = t.y, this.z = t.z, this.w = t.w !== void 0 ? t.w : 1, this;
  }
  add(t) {
    return this.x += t.x, this.y += t.y, this.z += t.z, this.w += t.w, this;
  }
  addScalar(t) {
    return this.x += t, this.y += t, this.z += t, this.w += t, this;
  }
  addVectors(t, e) {
    return this.x = t.x + e.x, this.y = t.y + e.y, this.z = t.z + e.z, this.w = t.w + e.w, this;
  }
  addScaledVector(t, e) {
    return this.x += t.x * e, this.y += t.y * e, this.z += t.z * e, this.w += t.w * e, this;
  }
  sub(t) {
    return this.x -= t.x, this.y -= t.y, this.z -= t.z, this.w -= t.w, this;
  }
  subScalar(t) {
    return this.x -= t, this.y -= t, this.z -= t, this.w -= t, this;
  }
  subVectors(t, e) {
    return this.x = t.x - e.x, this.y = t.y - e.y, this.z = t.z - e.z, this.w = t.w - e.w, this;
  }
  multiply(t) {
    return this.x *= t.x, this.y *= t.y, this.z *= t.z, this.w *= t.w, this;
  }
  multiplyScalar(t) {
    return this.x *= t, this.y *= t, this.z *= t, this.w *= t, this;
  }
  applyMatrix4(t) {
    const e = this.x, i = this.y, s = this.z, n = this.w, r = t.elements;
    return this.x = r[0] * e + r[4] * i + r[8] * s + r[12] * n, this.y = r[1] * e + r[5] * i + r[9] * s + r[13] * n, this.z = r[2] * e + r[6] * i + r[10] * s + r[14] * n, this.w = r[3] * e + r[7] * i + r[11] * s + r[15] * n, this;
  }
  divide(t) {
    return this.x /= t.x, this.y /= t.y, this.z /= t.z, this.w /= t.w, this;
  }
  divideScalar(t) {
    return this.multiplyScalar(1 / t);
  }
  setAxisAngleFromQuaternion(t) {
    this.w = 2 * Math.acos(t.w);
    const e = Math.sqrt(1 - t.w * t.w);
    return e < 1e-4 ? (this.x = 1, this.y = 0, this.z = 0) : (this.x = t.x / e, this.y = t.y / e, this.z = t.z / e), this;
  }
  setAxisAngleFromRotationMatrix(t) {
    let e, i, s, n;
    const o = t.elements, h = o[0], c = o[4], u = o[8], d = o[1], p = o[5], f = o[9], m = o[2], g = o[6], y = o[10];
    if (Math.abs(c - d) < 0.01 && Math.abs(u - m) < 0.01 && Math.abs(f - g) < 0.01) {
      if (Math.abs(c + d) < 0.1 && Math.abs(u + m) < 0.1 && Math.abs(f + g) < 0.1 && Math.abs(h + p + y - 3) < 0.1) return this.set(1, 0, 0, 0), this;
      e = Math.PI;
      const b = (h + 1) / 2, M = (p + 1) / 2, _ = (y + 1) / 2, v = (c + d) / 4, A = (u + m) / 4, S = (f + g) / 4;
      return b > M && b > _ ? b < 0.01 ? (i = 0, s = 0.707106781, n = 0.707106781) : (i = Math.sqrt(b), s = v / i, n = A / i) : M > _ ? M < 0.01 ? (i = 0.707106781, s = 0, n = 0.707106781) : (s = Math.sqrt(M), i = v / s, n = S / s) : _ < 0.01 ? (i = 0.707106781, s = 0.707106781, n = 0) : (n = Math.sqrt(_), i = A / n, s = S / n), this.set(i, s, n, e), this;
    }
    let x = Math.sqrt((g - f) * (g - f) + (u - m) * (u - m) + (d - c) * (d - c));
    return Math.abs(x) < 1e-3 && (x = 1), this.x = (g - f) / x, this.y = (u - m) / x, this.z = (d - c) / x, this.w = Math.acos((h + p + y - 1) / 2), this;
  }
  setFromMatrixPosition(t) {
    const e = t.elements;
    return this.x = e[12], this.y = e[13], this.z = e[14], this.w = e[15], this;
  }
  min(t) {
    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this.z = Math.min(this.z, t.z), this.w = Math.min(this.w, t.w), this;
  }
  max(t) {
    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this.z = Math.max(this.z, t.z), this.w = Math.max(this.w, t.w), this;
  }
  clamp(t, e) {
    return this.x = L(this.x, t.x, e.x), this.y = L(this.y, t.y, e.y), this.z = L(this.z, t.z, e.z), this.w = L(this.w, t.w, e.w), this;
  }
  clampScalar(t, e) {
    return this.x = L(this.x, t, e), this.y = L(this.y, t, e), this.z = L(this.z, t, e), this.w = L(this.w, t, e), this;
  }
  clampLength(t, e) {
    const i = this.length();
    return this.divideScalar(i || 1).multiplyScalar(L(i, t, e));
  }
  floor() {
    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), this.w = Math.floor(this.w), this;
  }
  ceil() {
    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), this.w = Math.ceil(this.w), this;
  }
  round() {
    return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), this.w = Math.round(this.w), this;
  }
  roundToZero() {
    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this.z = Math.trunc(this.z), this.w = Math.trunc(this.w), this;
  }
  negate() {
    return this.x = -this.x, this.y = -this.y, this.z = -this.z, this.w = -this.w, this;
  }
  dot(t) {
    return this.x * t.x + this.y * t.y + this.z * t.z + this.w * t.w;
  }
  lengthSq() {
    return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
  }
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
  }
  manhattanLength() {
    return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w);
  }
  normalize() {
    return this.divideScalar(this.length() || 1);
  }
  setLength(t) {
    return this.normalize().multiplyScalar(t);
  }
  lerp(t, e) {
    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this.z += (t.z - this.z) * e, this.w += (t.w - this.w) * e, this;
  }
  lerpVectors(t, e, i) {
    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this.z = t.z + (e.z - t.z) * i, this.w = t.w + (e.w - t.w) * i, this;
  }
  equals(t) {
    return t.x === this.x && t.y === this.y && t.z === this.z && t.w === this.w;
  }
  fromArray(t, e = 0) {
    return this.x = t[e], this.y = t[e + 1], this.z = t[e + 2], this.w = t[e + 3], this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this.x, t[e + 1] = this.y, t[e + 2] = this.z, t[e + 3] = this.w, t;
  }
  fromBufferAttribute(t, e) {
    return this.x = t.getX(e), this.y = t.getY(e), this.z = t.getZ(e), this.w = t.getW(e), this;
  }
  random() {
    return this.x = Math.random(), this.y = Math.random(), this.z = Math.random(), this.w = Math.random(), this;
  }
  *[Symbol.iterator]() {
    yield this.x, yield this.y, yield this.z, yield this.w;
  }
}
class To extends Se {
  constructor(t = 1, e = 1, i = {}) {
    super(), i = Object.assign({ generateMipmaps: false, internalFormat: null, minFilter: Gt, depthBuffer: true, stencilBuffer: false, resolveDepthBuffer: true, resolveStencilBuffer: true, depthTexture: null, samples: 0, count: 1, depth: 1, multiview: false }, i), this.isRenderTarget = true, this.width = t, this.height = e, this.depth = i.depth, this.scissor = new Nt(0, 0, t, e), this.scissorTest = false, this.viewport = new Nt(0, 0, t, e), this.textures = [];
    const s = { width: t, height: e, depth: i.depth }, n = new lt(s), r = i.count;
    for (let a = 0; a < r; a++) this.textures[a] = n.clone(), this.textures[a].isRenderTargetTexture = true, this.textures[a].renderTarget = this;
    this._setTextureOptions(i), this.depthBuffer = i.depthBuffer, this.stencilBuffer = i.stencilBuffer, this.resolveDepthBuffer = i.resolveDepthBuffer, this.resolveStencilBuffer = i.resolveStencilBuffer, this._depthTexture = null, this.depthTexture = i.depthTexture, this.samples = i.samples, this.multiview = i.multiview;
  }
  _setTextureOptions(t = {}) {
    const e = { minFilter: Gt, generateMipmaps: false, flipY: false, internalFormat: null };
    t.mapping !== void 0 && (e.mapping = t.mapping), t.wrapS !== void 0 && (e.wrapS = t.wrapS), t.wrapT !== void 0 && (e.wrapT = t.wrapT), t.wrapR !== void 0 && (e.wrapR = t.wrapR), t.magFilter !== void 0 && (e.magFilter = t.magFilter), t.minFilter !== void 0 && (e.minFilter = t.minFilter), t.format !== void 0 && (e.format = t.format), t.type !== void 0 && (e.type = t.type), t.anisotropy !== void 0 && (e.anisotropy = t.anisotropy), t.colorSpace !== void 0 && (e.colorSpace = t.colorSpace), t.flipY !== void 0 && (e.flipY = t.flipY), t.generateMipmaps !== void 0 && (e.generateMipmaps = t.generateMipmaps), t.internalFormat !== void 0 && (e.internalFormat = t.internalFormat);
    for (let i = 0; i < this.textures.length; i++) this.textures[i].setValues(e);
  }
  get texture() {
    return this.textures[0];
  }
  set texture(t) {
    this.textures[0] = t;
  }
  set depthTexture(t) {
    this._depthTexture !== null && (this._depthTexture.renderTarget = null), t !== null && (t.renderTarget = this), this._depthTexture = t;
  }
  get depthTexture() {
    return this._depthTexture;
  }
  setSize(t, e, i = 1) {
    if (this.width !== t || this.height !== e || this.depth !== i) {
      this.width = t, this.height = e, this.depth = i;
      for (let s = 0, n = this.textures.length; s < n; s++) this.textures[s].image.width = t, this.textures[s].image.height = e, this.textures[s].image.depth = i, this.textures[s].isData3DTexture !== true && (this.textures[s].isArrayTexture = this.textures[s].image.depth > 1);
      this.dispose();
    }
    this.viewport.set(0, 0, t, e), this.scissor.set(0, 0, t, e);
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    this.width = t.width, this.height = t.height, this.depth = t.depth, this.scissor.copy(t.scissor), this.scissorTest = t.scissorTest, this.viewport.copy(t.viewport), this.textures.length = 0;
    for (let e = 0, i = t.textures.length; e < i; e++) {
      this.textures[e] = t.textures[e].clone(), this.textures[e].isRenderTargetTexture = true, this.textures[e].renderTarget = this;
      const s = Object.assign({}, t.textures[e].image);
      this.textures[e].source = new Le(s);
    }
    return this.depthBuffer = t.depthBuffer, this.stencilBuffer = t.stencilBuffer, this.resolveDepthBuffer = t.resolveDepthBuffer, this.resolveStencilBuffer = t.resolveStencilBuffer, t.depthTexture !== null && (this.depthTexture = t.depthTexture.clone()), this.samples = t.samples, this;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
}
class Co extends To {
  constructor(t = 1, e = 1, i = {}) {
    super(t, e, i), this.isWebGLRenderTarget = true;
  }
}
class Vl extends lt {
  constructor(t = null, e = 1, i = 1, s = 1) {
    super(null), this.isDataArrayTexture = true, this.image = { data: t, width: e, height: i, depth: s }, this.magFilter = Bt, this.minFilter = Bt, this.wrapR = Zt, this.generateMipmaps = false, this.flipY = false, this.unpackAlignment = 1, this.layerUpdates = /* @__PURE__ */ new Set();
  }
  addLayerUpdate(t) {
    this.layerUpdates.add(t);
  }
  clearLayerUpdates() {
    this.layerUpdates.clear();
  }
}
class uf extends Co {
  constructor(t = 1, e = 1, i = 1, s = {}) {
    super(t, e, s), this.isWebGLArrayRenderTarget = true, this.depth = i, this.texture = new Vl(null, t, e, i), this._setTextureOptions(s), this.texture.isRenderTargetTexture = true;
  }
}
class Io extends lt {
  constructor(t = null, e = 1, i = 1, s = 1) {
    super(null), this.isData3DTexture = true, this.image = { data: t, width: e, height: i, depth: s }, this.magFilter = Bt, this.minFilter = Bt, this.wrapR = Zt, this.generateMipmaps = false, this.flipY = false, this.unpackAlignment = 1;
  }
}
class df extends Co {
  constructor(t = 1, e = 1, i = 1, s = {}) {
    super(t, e, s), this.isWebGL3DRenderTarget = true, this.depth = i, this.texture = new Io(null, t, e, i), this._setTextureOptions(s), this.texture.isRenderTargetTexture = true;
  }
}
class G {
  constructor(t, e, i, s, n, r, a, o, h, c, u, d, p, f, m, g) {
    G.prototype.isMatrix4 = true, this.elements = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1], t !== void 0 && this.set(t, e, i, s, n, r, a, o, h, c, u, d, p, f, m, g);
  }
  set(t, e, i, s, n, r, a, o, h, c, u, d, p, f, m, g) {
    const y = this.elements;
    return y[0] = t, y[4] = e, y[8] = i, y[12] = s, y[1] = n, y[5] = r, y[9] = a, y[13] = o, y[2] = h, y[6] = c, y[10] = u, y[14] = d, y[3] = p, y[7] = f, y[11] = m, y[15] = g, this;
  }
  identity() {
    return this.set(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this;
  }
  clone() {
    return new G().fromArray(this.elements);
  }
  copy(t) {
    const e = this.elements, i = t.elements;
    return e[0] = i[0], e[1] = i[1], e[2] = i[2], e[3] = i[3], e[4] = i[4], e[5] = i[5], e[6] = i[6], e[7] = i[7], e[8] = i[8], e[9] = i[9], e[10] = i[10], e[11] = i[11], e[12] = i[12], e[13] = i[13], e[14] = i[14], e[15] = i[15], this;
  }
  copyPosition(t) {
    const e = this.elements, i = t.elements;
    return e[12] = i[12], e[13] = i[13], e[14] = i[14], this;
  }
  setFromMatrix3(t) {
    const e = t.elements;
    return this.set(e[0], e[3], e[6], 0, e[1], e[4], e[7], 0, e[2], e[5], e[8], 0, 0, 0, 0, 1), this;
  }
  extractBasis(t, e, i) {
    return this.determinant() === 0 ? (t.set(1, 0, 0), e.set(0, 1, 0), i.set(0, 0, 1), this) : (t.setFromMatrixColumn(this, 0), e.setFromMatrixColumn(this, 1), i.setFromMatrixColumn(this, 2), this);
  }
  makeBasis(t, e, i) {
    return this.set(t.x, e.x, i.x, 0, t.y, e.y, i.y, 0, t.z, e.z, i.z, 0, 0, 0, 0, 1), this;
  }
  extractRotation(t) {
    if (t.determinant() === 0) return this.identity();
    const e = this.elements, i = t.elements, s = 1 / Ze.setFromMatrixColumn(t, 0).length(), n = 1 / Ze.setFromMatrixColumn(t, 1).length(), r = 1 / Ze.setFromMatrixColumn(t, 2).length();
    return e[0] = i[0] * s, e[1] = i[1] * s, e[2] = i[2] * s, e[3] = 0, e[4] = i[4] * n, e[5] = i[5] * n, e[6] = i[6] * n, e[7] = 0, e[8] = i[8] * r, e[9] = i[9] * r, e[10] = i[10] * r, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, this;
  }
  makeRotationFromEuler(t) {
    const e = this.elements, i = t.x, s = t.y, n = t.z, r = Math.cos(i), a = Math.sin(i), o = Math.cos(s), h = Math.sin(s), c = Math.cos(n), u = Math.sin(n);
    if (t.order === "XYZ") {
      const d = r * c, p = r * u, f = a * c, m = a * u;
      e[0] = o * c, e[4] = -o * u, e[8] = h, e[1] = p + f * h, e[5] = d - m * h, e[9] = -a * o, e[2] = m - d * h, e[6] = f + p * h, e[10] = r * o;
    } else if (t.order === "YXZ") {
      const d = o * c, p = o * u, f = h * c, m = h * u;
      e[0] = d + m * a, e[4] = f * a - p, e[8] = r * h, e[1] = r * u, e[5] = r * c, e[9] = -a, e[2] = p * a - f, e[6] = m + d * a, e[10] = r * o;
    } else if (t.order === "ZXY") {
      const d = o * c, p = o * u, f = h * c, m = h * u;
      e[0] = d - m * a, e[4] = -r * u, e[8] = f + p * a, e[1] = p + f * a, e[5] = r * c, e[9] = m - d * a, e[2] = -r * h, e[6] = a, e[10] = r * o;
    } else if (t.order === "ZYX") {
      const d = r * c, p = r * u, f = a * c, m = a * u;
      e[0] = o * c, e[4] = f * h - p, e[8] = d * h + m, e[1] = o * u, e[5] = m * h + d, e[9] = p * h - f, e[2] = -h, e[6] = a * o, e[10] = r * o;
    } else if (t.order === "YZX") {
      const d = r * o, p = r * h, f = a * o, m = a * h;
      e[0] = o * c, e[4] = m - d * u, e[8] = f * u + p, e[1] = u, e[5] = r * c, e[9] = -a * c, e[2] = -h * c, e[6] = p * u + f, e[10] = d - m * u;
    } else if (t.order === "XZY") {
      const d = r * o, p = r * h, f = a * o, m = a * h;
      e[0] = o * c, e[4] = -u, e[8] = h * c, e[1] = d * u + m, e[5] = r * c, e[9] = p * u - f, e[2] = f * u - p, e[6] = a * c, e[10] = m * u + d;
    }
    return e[3] = 0, e[7] = 0, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, this;
  }
  makeRotationFromQuaternion(t) {
    return this.compose(Ul, t, Wl);
  }
  lookAt(t, e, i) {
    const s = this.elements;
    return Tt.subVectors(t, e), Tt.lengthSq() === 0 && (Tt.z = 1), Tt.normalize(), me.crossVectors(i, Tt), me.lengthSq() === 0 && (Math.abs(i.z) === 1 ? Tt.x += 1e-4 : Tt.z += 1e-4, Tt.normalize(), me.crossVectors(i, Tt)), me.normalize(), ts.crossVectors(Tt, me), s[0] = me.x, s[4] = ts.x, s[8] = Tt.x, s[1] = me.y, s[5] = ts.y, s[9] = Tt.y, s[2] = me.z, s[6] = ts.z, s[10] = Tt.z, this;
  }
  multiply(t) {
    return this.multiplyMatrices(this, t);
  }
  premultiply(t) {
    return this.multiplyMatrices(t, this);
  }
  multiplyMatrices(t, e) {
    const i = t.elements, s = e.elements, n = this.elements, r = i[0], a = i[4], o = i[8], h = i[12], c = i[1], u = i[5], d = i[9], p = i[13], f = i[2], m = i[6], g = i[10], y = i[14], x = i[3], b = i[7], M = i[11], _ = i[15], v = s[0], A = s[4], S = s[8], T = s[12], C = s[1], B = s[5], O = s[9], D = s[13], J = s[2], V = s[6], et = s[10], at = s[14], Lt = s[3], it = s[7], ot = s[11], st = s[15];
    return n[0] = r * v + a * C + o * J + h * Lt, n[4] = r * A + a * B + o * V + h * it, n[8] = r * S + a * O + o * et + h * ot, n[12] = r * T + a * D + o * at + h * st, n[1] = c * v + u * C + d * J + p * Lt, n[5] = c * A + u * B + d * V + p * it, n[9] = c * S + u * O + d * et + p * ot, n[13] = c * T + u * D + d * at + p * st, n[2] = f * v + m * C + g * J + y * Lt, n[6] = f * A + m * B + g * V + y * it, n[10] = f * S + m * O + g * et + y * ot, n[14] = f * T + m * D + g * at + y * st, n[3] = x * v + b * C + M * J + _ * Lt, n[7] = x * A + b * B + M * V + _ * it, n[11] = x * S + b * O + M * et + _ * ot, n[15] = x * T + b * D + M * at + _ * st, this;
  }
  multiplyScalar(t) {
    const e = this.elements;
    return e[0] *= t, e[4] *= t, e[8] *= t, e[12] *= t, e[1] *= t, e[5] *= t, e[9] *= t, e[13] *= t, e[2] *= t, e[6] *= t, e[10] *= t, e[14] *= t, e[3] *= t, e[7] *= t, e[11] *= t, e[15] *= t, this;
  }
  determinant() {
    const t = this.elements, e = t[0], i = t[4], s = t[8], n = t[12], r = t[1], a = t[5], o = t[9], h = t[13], c = t[2], u = t[6], d = t[10], p = t[14], f = t[3], m = t[7], g = t[11], y = t[15], x = o * p - h * d, b = a * p - h * u, M = a * d - o * u, _ = r * p - h * c, v = r * d - o * c, A = r * u - a * c;
    return e * (m * x - g * b + y * M) - i * (f * x - g * _ + y * v) + s * (f * b - m * _ + y * A) - n * (f * M - m * v + g * A);
  }
  transpose() {
    const t = this.elements;
    let e;
    return e = t[1], t[1] = t[4], t[4] = e, e = t[2], t[2] = t[8], t[8] = e, e = t[6], t[6] = t[9], t[9] = e, e = t[3], t[3] = t[12], t[12] = e, e = t[7], t[7] = t[13], t[13] = e, e = t[11], t[11] = t[14], t[14] = e, this;
  }
  setPosition(t, e, i) {
    const s = this.elements;
    return t.isVector3 ? (s[12] = t.x, s[13] = t.y, s[14] = t.z) : (s[12] = t, s[13] = e, s[14] = i), this;
  }
  invert() {
    const t = this.elements, e = t[0], i = t[1], s = t[2], n = t[3], r = t[4], a = t[5], o = t[6], h = t[7], c = t[8], u = t[9], d = t[10], p = t[11], f = t[12], m = t[13], g = t[14], y = t[15], x = e * a - i * r, b = e * o - s * r, M = e * h - n * r, _ = i * o - s * a, v = i * h - n * a, A = s * h - n * o, S = c * m - u * f, T = c * g - d * f, C = c * y - p * f, B = u * g - d * m, O = u * y - p * m, D = d * y - p * g, J = x * D - b * O + M * B + _ * C - v * T + A * S;
    if (J === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    const V = 1 / J;
    return t[0] = (a * D - o * O + h * B) * V, t[1] = (s * O - i * D - n * B) * V, t[2] = (m * A - g * v + y * _) * V, t[3] = (d * v - u * A - p * _) * V, t[4] = (o * C - r * D - h * T) * V, t[5] = (e * D - s * C + n * T) * V, t[6] = (g * M - f * A - y * b) * V, t[7] = (c * A - d * M + p * b) * V, t[8] = (r * O - a * C + h * S) * V, t[9] = (i * C - e * O - n * S) * V, t[10] = (f * v - m * M + y * x) * V, t[11] = (u * M - c * v - p * x) * V, t[12] = (a * T - r * B - o * S) * V, t[13] = (e * B - i * T + s * S) * V, t[14] = (m * b - f * _ - g * x) * V, t[15] = (c * _ - u * b + d * x) * V, this;
  }
  scale(t) {
    const e = this.elements, i = t.x, s = t.y, n = t.z;
    return e[0] *= i, e[4] *= s, e[8] *= n, e[1] *= i, e[5] *= s, e[9] *= n, e[2] *= i, e[6] *= s, e[10] *= n, e[3] *= i, e[7] *= s, e[11] *= n, this;
  }
  getMaxScaleOnAxis() {
    const t = this.elements, e = t[0] * t[0] + t[1] * t[1] + t[2] * t[2], i = t[4] * t[4] + t[5] * t[5] + t[6] * t[6], s = t[8] * t[8] + t[9] * t[9] + t[10] * t[10];
    return Math.sqrt(Math.max(e, i, s));
  }
  makeTranslation(t, e, i) {
    return t.isVector3 ? this.set(1, 0, 0, t.x, 0, 1, 0, t.y, 0, 0, 1, t.z, 0, 0, 0, 1) : this.set(1, 0, 0, t, 0, 1, 0, e, 0, 0, 1, i, 0, 0, 0, 1), this;
  }
  makeRotationX(t) {
    const e = Math.cos(t), i = Math.sin(t);
    return this.set(1, 0, 0, 0, 0, e, -i, 0, 0, i, e, 0, 0, 0, 0, 1), this;
  }
  makeRotationY(t) {
    const e = Math.cos(t), i = Math.sin(t);
    return this.set(e, 0, i, 0, 0, 1, 0, 0, -i, 0, e, 0, 0, 0, 0, 1), this;
  }
  makeRotationZ(t) {
    const e = Math.cos(t), i = Math.sin(t);
    return this.set(e, -i, 0, 0, i, e, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this;
  }
  makeRotationAxis(t, e) {
    const i = Math.cos(e), s = Math.sin(e), n = 1 - i, r = t.x, a = t.y, o = t.z, h = n * r, c = n * a;
    return this.set(h * r + i, h * a - s * o, h * o + s * a, 0, h * a + s * o, c * a + i, c * o - s * r, 0, h * o - s * a, c * o + s * r, n * o * o + i, 0, 0, 0, 0, 1), this;
  }
  makeScale(t, e, i) {
    return this.set(t, 0, 0, 0, 0, e, 0, 0, 0, 0, i, 0, 0, 0, 0, 1), this;
  }
  makeShear(t, e, i, s, n, r) {
    return this.set(1, i, n, 0, t, 1, r, 0, e, s, 1, 0, 0, 0, 0, 1), this;
  }
  compose(t, e, i) {
    const s = this.elements, n = e._x, r = e._y, a = e._z, o = e._w, h = n + n, c = r + r, u = a + a, d = n * h, p = n * c, f = n * u, m = r * c, g = r * u, y = a * u, x = o * h, b = o * c, M = o * u, _ = i.x, v = i.y, A = i.z;
    return s[0] = (1 - (m + y)) * _, s[1] = (p + M) * _, s[2] = (f - b) * _, s[3] = 0, s[4] = (p - M) * v, s[5] = (1 - (d + y)) * v, s[6] = (g + x) * v, s[7] = 0, s[8] = (f + b) * A, s[9] = (g - x) * A, s[10] = (1 - (d + m)) * A, s[11] = 0, s[12] = t.x, s[13] = t.y, s[14] = t.z, s[15] = 1, this;
  }
  decompose(t, e, i) {
    const s = this.elements;
    t.x = s[12], t.y = s[13], t.z = s[14];
    const n = this.determinant();
    if (n === 0) return i.set(1, 1, 1), e.identity(), this;
    let r = Ze.set(s[0], s[1], s[2]).length();
    const a = Ze.set(s[4], s[5], s[6]).length(), o = Ze.set(s[8], s[9], s[10]).length();
    n < 0 && (r = -r), Vt.copy(this);
    const h = 1 / r, c = 1 / a, u = 1 / o;
    return Vt.elements[0] *= h, Vt.elements[1] *= h, Vt.elements[2] *= h, Vt.elements[4] *= c, Vt.elements[5] *= c, Vt.elements[6] *= c, Vt.elements[8] *= u, Vt.elements[9] *= u, Vt.elements[10] *= u, e.setFromRotationMatrix(Vt), i.x = r, i.y = a, i.z = o, this;
  }
  makePerspective(t, e, i, s, n, r, a = Yt, o = false) {
    const h = this.elements, c = 2 * n / (e - t), u = 2 * n / (i - s), d = (e + t) / (e - t), p = (i + s) / (i - s);
    let f, m;
    if (o) f = n / (r - n), m = r * n / (r - n);
    else if (a === Yt) f = -(r + n) / (r - n), m = -2 * r * n / (r - n);
    else if (a === Mi) f = -r / (r - n), m = -r * n / (r - n);
    else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: " + a);
    return h[0] = c, h[4] = 0, h[8] = d, h[12] = 0, h[1] = 0, h[5] = u, h[9] = p, h[13] = 0, h[2] = 0, h[6] = 0, h[10] = f, h[14] = m, h[3] = 0, h[7] = 0, h[11] = -1, h[15] = 0, this;
  }
  makeOrthographic(t, e, i, s, n, r, a = Yt, o = false) {
    const h = this.elements, c = 2 / (e - t), u = 2 / (i - s), d = -(e + t) / (e - t), p = -(i + s) / (i - s);
    let f, m;
    if (o) f = 1 / (r - n), m = r / (r - n);
    else if (a === Yt) f = -2 / (r - n), m = -(r + n) / (r - n);
    else if (a === Mi) f = -1 / (r - n), m = -n / (r - n);
    else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: " + a);
    return h[0] = c, h[4] = 0, h[8] = 0, h[12] = d, h[1] = 0, h[5] = u, h[9] = 0, h[13] = p, h[2] = 0, h[6] = 0, h[10] = f, h[14] = m, h[3] = 0, h[7] = 0, h[11] = 0, h[15] = 1, this;
  }
  equals(t) {
    const e = this.elements, i = t.elements;
    for (let s = 0; s < 16; s++) if (e[s] !== i[s]) return false;
    return true;
  }
  fromArray(t, e = 0) {
    for (let i = 0; i < 16; i++) this.elements[i] = t[i + e];
    return this;
  }
  toArray(t = [], e = 0) {
    const i = this.elements;
    return t[e] = i[0], t[e + 1] = i[1], t[e + 2] = i[2], t[e + 3] = i[3], t[e + 4] = i[4], t[e + 5] = i[5], t[e + 6] = i[6], t[e + 7] = i[7], t[e + 8] = i[8], t[e + 9] = i[9], t[e + 10] = i[10], t[e + 11] = i[11], t[e + 12] = i[12], t[e + 13] = i[13], t[e + 14] = i[14], t[e + 15] = i[15], t;
  }
}
const Ze = new w(), Vt = new G(), Ul = new w(0, 0, 0), Wl = new w(1, 1, 1), me = new w(), ts = new w(), Tt = new w(), ya = new G(), ga = new _t();
class jt {
  constructor(t = 0, e = 0, i = 0, s = jt.DEFAULT_ORDER) {
    this.isEuler = true, this._x = t, this._y = e, this._z = i, this._order = s;
  }
  get x() {
    return this._x;
  }
  set x(t) {
    this._x = t, this._onChangeCallback();
  }
  get y() {
    return this._y;
  }
  set y(t) {
    this._y = t, this._onChangeCallback();
  }
  get z() {
    return this._z;
  }
  set z(t) {
    this._z = t, this._onChangeCallback();
  }
  get order() {
    return this._order;
  }
  set order(t) {
    this._order = t, this._onChangeCallback();
  }
  set(t, e, i, s = this._order) {
    return this._x = t, this._y = e, this._z = i, this._order = s, this._onChangeCallback(), this;
  }
  clone() {
    return new this.constructor(this._x, this._y, this._z, this._order);
  }
  copy(t) {
    return this._x = t._x, this._y = t._y, this._z = t._z, this._order = t._order, this._onChangeCallback(), this;
  }
  setFromRotationMatrix(t, e = this._order, i = true) {
    const s = t.elements, n = s[0], r = s[4], a = s[8], o = s[1], h = s[5], c = s[9], u = s[2], d = s[6], p = s[10];
    switch (e) {
      case "XYZ":
        this._y = Math.asin(L(a, -1, 1)), Math.abs(a) < 0.9999999 ? (this._x = Math.atan2(-c, p), this._z = Math.atan2(-r, n)) : (this._x = Math.atan2(d, h), this._z = 0);
        break;
      case "YXZ":
        this._x = Math.asin(-L(c, -1, 1)), Math.abs(c) < 0.9999999 ? (this._y = Math.atan2(a, p), this._z = Math.atan2(o, h)) : (this._y = Math.atan2(-u, n), this._z = 0);
        break;
      case "ZXY":
        this._x = Math.asin(L(d, -1, 1)), Math.abs(d) < 0.9999999 ? (this._y = Math.atan2(-u, p), this._z = Math.atan2(-r, h)) : (this._y = 0, this._z = Math.atan2(o, n));
        break;
      case "ZYX":
        this._y = Math.asin(-L(u, -1, 1)), Math.abs(u) < 0.9999999 ? (this._x = Math.atan2(d, p), this._z = Math.atan2(o, n)) : (this._x = 0, this._z = Math.atan2(-r, h));
        break;
      case "YZX":
        this._z = Math.asin(L(o, -1, 1)), Math.abs(o) < 0.9999999 ? (this._x = Math.atan2(-c, h), this._y = Math.atan2(-u, n)) : (this._x = 0, this._y = Math.atan2(a, p));
        break;
      case "XZY":
        this._z = Math.asin(-L(r, -1, 1)), Math.abs(r) < 0.9999999 ? (this._x = Math.atan2(d, h), this._y = Math.atan2(a, n)) : (this._x = Math.atan2(-c, p), this._y = 0);
        break;
      default:
        N("Euler: .setFromRotationMatrix() encountered an unknown order: " + e);
    }
    return this._order = e, i === true && this._onChangeCallback(), this;
  }
  setFromQuaternion(t, e, i) {
    return ya.makeRotationFromQuaternion(t), this.setFromRotationMatrix(ya, e, i);
  }
  setFromVector3(t, e = this._order) {
    return this.set(t.x, t.y, t.z, e);
  }
  reorder(t) {
    return ga.setFromEuler(this), this.setFromQuaternion(ga, t);
  }
  equals(t) {
    return t._x === this._x && t._y === this._y && t._z === this._z && t._order === this._order;
  }
  fromArray(t) {
    return this._x = t[0], this._y = t[1], this._z = t[2], t[3] !== void 0 && (this._order = t[3]), this._onChangeCallback(), this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this._x, t[e + 1] = this._y, t[e + 2] = this._z, t[e + 3] = this._order, t;
  }
  _onChange(t) {
    return this._onChangeCallback = t, this;
  }
  _onChangeCallback() {
  }
  *[Symbol.iterator]() {
    yield this._x, yield this._y, yield this._z, yield this._order;
  }
}
jt.DEFAULT_ORDER = "XYZ";
class zo {
  constructor() {
    this.mask = 1;
  }
  set(t) {
    this.mask = (1 << t | 0) >>> 0;
  }
  enable(t) {
    this.mask |= 1 << t | 0;
  }
  enableAll() {
    this.mask = -1;
  }
  toggle(t) {
    this.mask ^= 1 << t | 0;
  }
  disable(t) {
    this.mask &= ~(1 << t | 0);
  }
  disableAll() {
    this.mask = 0;
  }
  test(t) {
    return (this.mask & t.mask) !== 0;
  }
  isEnabled(t) {
    return (this.mask & (1 << t | 0)) !== 0;
  }
}
let Gl = 0;
const xa = new w(), Ye = new _t(), ne = new G(), es = new w(), Ii = new w(), ql = new w(), Hl = new _t(), ba = new w(1, 0, 0), Ma = new w(0, 1, 0), wa = new w(0, 0, 1), _a = { type: "added" }, Jl = { type: "removed" }, $e = { type: "childadded", child: null }, yn = { type: "childremoved", child: null };
class $ extends Se {
  constructor() {
    super(), this.isObject3D = true, Object.defineProperty(this, "id", { value: Gl++ }), this.uuid = zt(), this.name = "", this.type = "Object3D", this.parent = null, this.children = [], this.up = $.DEFAULT_UP.clone();
    const t = new w(), e = new jt(), i = new _t(), s = new w(1, 1, 1);
    function n() {
      i.setFromEuler(e, false);
    }
    function r() {
      e.setFromQuaternion(i, void 0, false);
    }
    e._onChange(n), i._onChange(r), Object.defineProperties(this, { position: { configurable: true, enumerable: true, value: t }, rotation: { configurable: true, enumerable: true, value: e }, quaternion: { configurable: true, enumerable: true, value: i }, scale: { configurable: true, enumerable: true, value: s }, modelViewMatrix: { value: new G() }, normalMatrix: { value: new Qt() } }), this.matrix = new G(), this.matrixWorld = new G(), this.matrixAutoUpdate = $.DEFAULT_MATRIX_AUTO_UPDATE, this.matrixWorldAutoUpdate = $.DEFAULT_MATRIX_WORLD_AUTO_UPDATE, this.matrixWorldNeedsUpdate = false, this.layers = new zo(), this.visible = true, this.castShadow = false, this.receiveShadow = false, this.frustumCulled = true, this.renderOrder = 0, this.animations = [], this.customDepthMaterial = void 0, this.customDistanceMaterial = void 0, this.static = false, this.userData = {}, this.pivot = null;
  }
  onBeforeShadow() {
  }
  onAfterShadow() {
  }
  onBeforeRender() {
  }
  onAfterRender() {
  }
  applyMatrix4(t) {
    this.matrixAutoUpdate && this.updateMatrix(), this.matrix.premultiply(t), this.matrix.decompose(this.position, this.quaternion, this.scale);
  }
  applyQuaternion(t) {
    return this.quaternion.premultiply(t), this;
  }
  setRotationFromAxisAngle(t, e) {
    this.quaternion.setFromAxisAngle(t, e);
  }
  setRotationFromEuler(t) {
    this.quaternion.setFromEuler(t, true);
  }
  setRotationFromMatrix(t) {
    this.quaternion.setFromRotationMatrix(t);
  }
  setRotationFromQuaternion(t) {
    this.quaternion.copy(t);
  }
  rotateOnAxis(t, e) {
    return Ye.setFromAxisAngle(t, e), this.quaternion.multiply(Ye), this;
  }
  rotateOnWorldAxis(t, e) {
    return Ye.setFromAxisAngle(t, e), this.quaternion.premultiply(Ye), this;
  }
  rotateX(t) {
    return this.rotateOnAxis(ba, t);
  }
  rotateY(t) {
    return this.rotateOnAxis(Ma, t);
  }
  rotateZ(t) {
    return this.rotateOnAxis(wa, t);
  }
  translateOnAxis(t, e) {
    return xa.copy(t).applyQuaternion(this.quaternion), this.position.add(xa.multiplyScalar(e)), this;
  }
  translateX(t) {
    return this.translateOnAxis(ba, t);
  }
  translateY(t) {
    return this.translateOnAxis(Ma, t);
  }
  translateZ(t) {
    return this.translateOnAxis(wa, t);
  }
  localToWorld(t) {
    return this.updateWorldMatrix(true, false), t.applyMatrix4(this.matrixWorld);
  }
  worldToLocal(t) {
    return this.updateWorldMatrix(true, false), t.applyMatrix4(ne.copy(this.matrixWorld).invert());
  }
  lookAt(t, e, i) {
    t.isVector3 ? es.copy(t) : es.set(t, e, i);
    const s = this.parent;
    this.updateWorldMatrix(true, false), Ii.setFromMatrixPosition(this.matrixWorld), this.isCamera || this.isLight ? ne.lookAt(Ii, es, this.up) : ne.lookAt(es, Ii, this.up), this.quaternion.setFromRotationMatrix(ne), s && (ne.extractRotation(s.matrixWorld), Ye.setFromRotationMatrix(ne), this.quaternion.premultiply(Ye.invert()));
  }
  add(t) {
    if (arguments.length > 1) {
      for (let e = 0; e < arguments.length; e++) this.add(arguments[e]);
      return this;
    }
    return t === this ? (Y("Object3D.add: object can't be added as a child of itself.", t), this) : (t && t.isObject3D ? (t.removeFromParent(), t.parent = this, this.children.push(t), t.dispatchEvent(_a), $e.child = t, this.dispatchEvent($e), $e.child = null) : Y("Object3D.add: object not an instance of THREE.Object3D.", t), this);
  }
  remove(t) {
    if (arguments.length > 1) {
      for (let i = 0; i < arguments.length; i++) this.remove(arguments[i]);
      return this;
    }
    const e = this.children.indexOf(t);
    return e !== -1 && (t.parent = null, this.children.splice(e, 1), t.dispatchEvent(Jl), yn.child = t, this.dispatchEvent(yn), yn.child = null), this;
  }
  removeFromParent() {
    const t = this.parent;
    return t !== null && t.remove(this), this;
  }
  clear() {
    return this.remove(...this.children);
  }
  attach(t) {
    return this.updateWorldMatrix(true, false), ne.copy(this.matrixWorld).invert(), t.parent !== null && (t.parent.updateWorldMatrix(true, false), ne.multiply(t.parent.matrixWorld)), t.applyMatrix4(ne), t.removeFromParent(), t.parent = this, this.children.push(t), t.updateWorldMatrix(false, true), t.dispatchEvent(_a), $e.child = t, this.dispatchEvent($e), $e.child = null, this;
  }
  getObjectById(t) {
    return this.getObjectByProperty("id", t);
  }
  getObjectByName(t) {
    return this.getObjectByProperty("name", t);
  }
  getObjectByProperty(t, e) {
    if (this[t] === e) return this;
    for (let i = 0, s = this.children.length; i < s; i++) {
      const r = this.children[i].getObjectByProperty(t, e);
      if (r !== void 0) return r;
    }
  }
  getObjectsByProperty(t, e, i = []) {
    this[t] === e && i.push(this);
    const s = this.children;
    for (let n = 0, r = s.length; n < r; n++) s[n].getObjectsByProperty(t, e, i);
    return i;
  }
  getWorldPosition(t) {
    return this.updateWorldMatrix(true, false), t.setFromMatrixPosition(this.matrixWorld);
  }
  getWorldQuaternion(t) {
    return this.updateWorldMatrix(true, false), this.matrixWorld.decompose(Ii, t, ql), t;
  }
  getWorldScale(t) {
    return this.updateWorldMatrix(true, false), this.matrixWorld.decompose(Ii, Hl, t), t;
  }
  getWorldDirection(t) {
    this.updateWorldMatrix(true, false);
    const e = this.matrixWorld.elements;
    return t.set(e[8], e[9], e[10]).normalize();
  }
  raycast() {
  }
  traverse(t) {
    t(this);
    const e = this.children;
    for (let i = 0, s = e.length; i < s; i++) e[i].traverse(t);
  }
  traverseVisible(t) {
    if (this.visible === false) return;
    t(this);
    const e = this.children;
    for (let i = 0, s = e.length; i < s; i++) e[i].traverseVisible(t);
  }
  traverseAncestors(t) {
    const e = this.parent;
    e !== null && (t(e), e.traverseAncestors(t));
  }
  updateMatrix() {
    this.matrix.compose(this.position, this.quaternion, this.scale);
    const t = this.pivot;
    if (t !== null) {
      const e = t.x, i = t.y, s = t.z, n = this.matrix.elements;
      n[12] += e - n[0] * e - n[4] * i - n[8] * s, n[13] += i - n[1] * e - n[5] * i - n[9] * s, n[14] += s - n[2] * e - n[6] * i - n[10] * s;
    }
    this.matrixWorldNeedsUpdate = true;
  }
  updateMatrixWorld(t) {
    this.matrixAutoUpdate && this.updateMatrix(), (this.matrixWorldNeedsUpdate || t) && (this.matrixWorldAutoUpdate === true && (this.parent === null ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix)), this.matrixWorldNeedsUpdate = false, t = true);
    const e = this.children;
    for (let i = 0, s = e.length; i < s; i++) e[i].updateMatrixWorld(t);
  }
  updateWorldMatrix(t, e) {
    const i = this.parent;
    if (t === true && i !== null && i.updateWorldMatrix(true, false), this.matrixAutoUpdate && this.updateMatrix(), this.matrixWorldAutoUpdate === true && (this.parent === null ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix)), e === true) {
      const s = this.children;
      for (let n = 0, r = s.length; n < r; n++) s[n].updateWorldMatrix(false, true);
    }
  }
  toJSON(t) {
    const e = t === void 0 || typeof t == "string", i = {};
    e && (t = { geometries: {}, materials: {}, textures: {}, images: {}, shapes: {}, skeletons: {}, animations: {}, nodes: {} }, i.metadata = { version: 4.7, type: "Object", generator: "Object3D.toJSON" });
    const s = {};
    s.uuid = this.uuid, s.type = this.type, this.name !== "" && (s.name = this.name), this.castShadow === true && (s.castShadow = true), this.receiveShadow === true && (s.receiveShadow = true), this.visible === false && (s.visible = false), this.frustumCulled === false && (s.frustumCulled = false), this.renderOrder !== 0 && (s.renderOrder = this.renderOrder), this.static !== false && (s.static = this.static), Object.keys(this.userData).length > 0 && (s.userData = this.userData), s.layers = this.layers.mask, s.matrix = this.matrix.toArray(), s.up = this.up.toArray(), this.pivot !== null && (s.pivot = this.pivot.toArray()), this.matrixAutoUpdate === false && (s.matrixAutoUpdate = false), this.morphTargetDictionary !== void 0 && (s.morphTargetDictionary = Object.assign({}, this.morphTargetDictionary)), this.morphTargetInfluences !== void 0 && (s.morphTargetInfluences = this.morphTargetInfluences.slice()), this.isInstancedMesh && (s.type = "InstancedMesh", s.count = this.count, s.instanceMatrix = this.instanceMatrix.toJSON(), this.instanceColor !== null && (s.instanceColor = this.instanceColor.toJSON())), this.isBatchedMesh && (s.type = "BatchedMesh", s.perObjectFrustumCulled = this.perObjectFrustumCulled, s.sortObjects = this.sortObjects, s.drawRanges = this._drawRanges, s.reservedRanges = this._reservedRanges, s.geometryInfo = this._geometryInfo.map((a) => ({ ...a, boundingBox: a.boundingBox ? a.boundingBox.toJSON() : void 0, boundingSphere: a.boundingSphere ? a.boundingSphere.toJSON() : void 0 })), s.instanceInfo = this._instanceInfo.map((a) => ({ ...a })), s.availableInstanceIds = this._availableInstanceIds.slice(), s.availableGeometryIds = this._availableGeometryIds.slice(), s.nextIndexStart = this._nextIndexStart, s.nextVertexStart = this._nextVertexStart, s.geometryCount = this._geometryCount, s.maxInstanceCount = this._maxInstanceCount, s.maxVertexCount = this._maxVertexCount, s.maxIndexCount = this._maxIndexCount, s.geometryInitialized = this._geometryInitialized, s.matricesTexture = this._matricesTexture.toJSON(t), s.indirectTexture = this._indirectTexture.toJSON(t), this._colorsTexture !== null && (s.colorsTexture = this._colorsTexture.toJSON(t)), this.boundingSphere !== null && (s.boundingSphere = this.boundingSphere.toJSON()), this.boundingBox !== null && (s.boundingBox = this.boundingBox.toJSON()));
    function n(a, o) {
      return a[o.uuid] === void 0 && (a[o.uuid] = o.toJSON(t)), o.uuid;
    }
    if (this.isScene) this.background && (this.background.isColor ? s.background = this.background.toJSON() : this.background.isTexture && (s.background = this.background.toJSON(t).uuid)), this.environment && this.environment.isTexture && this.environment.isRenderTargetTexture !== true && (s.environment = this.environment.toJSON(t).uuid);
    else if (this.isMesh || this.isLine || this.isPoints) {
      s.geometry = n(t.geometries, this.geometry);
      const a = this.geometry.parameters;
      if (a !== void 0 && a.shapes !== void 0) {
        const o = a.shapes;
        if (Array.isArray(o)) for (let h = 0, c = o.length; h < c; h++) {
          const u = o[h];
          n(t.shapes, u);
        }
        else n(t.shapes, o);
      }
    }
    if (this.isSkinnedMesh && (s.bindMode = this.bindMode, s.bindMatrix = this.bindMatrix.toArray(), this.skeleton !== void 0 && (n(t.skeletons, this.skeleton), s.skeleton = this.skeleton.uuid)), this.material !== void 0) if (Array.isArray(this.material)) {
      const a = [];
      for (let o = 0, h = this.material.length; o < h; o++) a.push(n(t.materials, this.material[o]));
      s.material = a;
    } else s.material = n(t.materials, this.material);
    if (this.children.length > 0) {
      s.children = [];
      for (let a = 0; a < this.children.length; a++) s.children.push(this.children[a].toJSON(t).object);
    }
    if (this.animations.length > 0) {
      s.animations = [];
      for (let a = 0; a < this.animations.length; a++) {
        const o = this.animations[a];
        s.animations.push(n(t.animations, o));
      }
    }
    if (e) {
      const a = r(t.geometries), o = r(t.materials), h = r(t.textures), c = r(t.images), u = r(t.shapes), d = r(t.skeletons), p = r(t.animations), f = r(t.nodes);
      a.length > 0 && (i.geometries = a), o.length > 0 && (i.materials = o), h.length > 0 && (i.textures = h), c.length > 0 && (i.images = c), u.length > 0 && (i.shapes = u), d.length > 0 && (i.skeletons = d), p.length > 0 && (i.animations = p), f.length > 0 && (i.nodes = f);
    }
    return i.object = s, i;
    function r(a) {
      const o = [];
      for (const h in a) {
        const c = a[h];
        delete c.metadata, o.push(c);
      }
      return o;
    }
  }
  clone(t) {
    return new this.constructor().copy(this, t);
  }
  copy(t, e = true) {
    if (this.name = t.name, this.up.copy(t.up), this.position.copy(t.position), this.rotation.order = t.rotation.order, this.quaternion.copy(t.quaternion), this.scale.copy(t.scale), t.pivot !== null && (this.pivot = t.pivot.clone()), this.matrix.copy(t.matrix), this.matrixWorld.copy(t.matrixWorld), this.matrixAutoUpdate = t.matrixAutoUpdate, this.matrixWorldAutoUpdate = t.matrixWorldAutoUpdate, this.matrixWorldNeedsUpdate = t.matrixWorldNeedsUpdate, this.layers.mask = t.layers.mask, this.visible = t.visible, this.castShadow = t.castShadow, this.receiveShadow = t.receiveShadow, this.frustumCulled = t.frustumCulled, this.renderOrder = t.renderOrder, this.static = t.static, this.animations = t.animations.slice(), this.userData = JSON.parse(JSON.stringify(t.userData)), e === true) for (let i = 0; i < t.children.length; i++) {
      const s = t.children[i];
      this.add(s.clone());
    }
    return this;
  }
}
$.DEFAULT_UP = new w(0, 1, 0);
$.DEFAULT_MATRIX_AUTO_UPDATE = true;
$.DEFAULT_MATRIX_WORLD_AUTO_UPDATE = true;
class Di extends $ {
  constructor() {
    super(), this.isGroup = true, this.type = "Group";
  }
}
const Xl = { type: "move" };
class pf {
  constructor() {
    this._targetRay = null, this._grip = null, this._hand = null;
  }
  getHandSpace() {
    return this._hand === null && (this._hand = new Di(), this._hand.matrixAutoUpdate = false, this._hand.visible = false, this._hand.joints = {}, this._hand.inputState = { pinching: false }), this._hand;
  }
  getTargetRaySpace() {
    return this._targetRay === null && (this._targetRay = new Di(), this._targetRay.matrixAutoUpdate = false, this._targetRay.visible = false, this._targetRay.hasLinearVelocity = false, this._targetRay.linearVelocity = new w(), this._targetRay.hasAngularVelocity = false, this._targetRay.angularVelocity = new w()), this._targetRay;
  }
  getGripSpace() {
    return this._grip === null && (this._grip = new Di(), this._grip.matrixAutoUpdate = false, this._grip.visible = false, this._grip.hasLinearVelocity = false, this._grip.linearVelocity = new w(), this._grip.hasAngularVelocity = false, this._grip.angularVelocity = new w()), this._grip;
  }
  dispatchEvent(t) {
    return this._targetRay !== null && this._targetRay.dispatchEvent(t), this._grip !== null && this._grip.dispatchEvent(t), this._hand !== null && this._hand.dispatchEvent(t), this;
  }
  connect(t) {
    if (t && t.hand) {
      const e = this._hand;
      if (e) for (const i of t.hand.values()) this._getHandJoint(e, i);
    }
    return this.dispatchEvent({ type: "connected", data: t }), this;
  }
  disconnect(t) {
    return this.dispatchEvent({ type: "disconnected", data: t }), this._targetRay !== null && (this._targetRay.visible = false), this._grip !== null && (this._grip.visible = false), this._hand !== null && (this._hand.visible = false), this;
  }
  update(t, e, i) {
    let s = null, n = null, r = null;
    const a = this._targetRay, o = this._grip, h = this._hand;
    if (t && e.session.visibilityState !== "visible-blurred") {
      if (h && t.hand) {
        r = true;
        for (const m of t.hand.values()) {
          const g = e.getJointPose(m, i), y = this._getHandJoint(h, m);
          g !== null && (y.matrix.fromArray(g.transform.matrix), y.matrix.decompose(y.position, y.rotation, y.scale), y.matrixWorldNeedsUpdate = true, y.jointRadius = g.radius), y.visible = g !== null;
        }
        const c = h.joints["index-finger-tip"], u = h.joints["thumb-tip"], d = c.position.distanceTo(u.position), p = 0.02, f = 5e-3;
        h.inputState.pinching && d > p + f ? (h.inputState.pinching = false, this.dispatchEvent({ type: "pinchend", handedness: t.handedness, target: this })) : !h.inputState.pinching && d <= p - f && (h.inputState.pinching = true, this.dispatchEvent({ type: "pinchstart", handedness: t.handedness, target: this }));
      } else o !== null && t.gripSpace && (n = e.getPose(t.gripSpace, i), n !== null && (o.matrix.fromArray(n.transform.matrix), o.matrix.decompose(o.position, o.rotation, o.scale), o.matrixWorldNeedsUpdate = true, n.linearVelocity ? (o.hasLinearVelocity = true, o.linearVelocity.copy(n.linearVelocity)) : o.hasLinearVelocity = false, n.angularVelocity ? (o.hasAngularVelocity = true, o.angularVelocity.copy(n.angularVelocity)) : o.hasAngularVelocity = false));
      a !== null && (s = e.getPose(t.targetRaySpace, i), s === null && n !== null && (s = n), s !== null && (a.matrix.fromArray(s.transform.matrix), a.matrix.decompose(a.position, a.rotation, a.scale), a.matrixWorldNeedsUpdate = true, s.linearVelocity ? (a.hasLinearVelocity = true, a.linearVelocity.copy(s.linearVelocity)) : a.hasLinearVelocity = false, s.angularVelocity ? (a.hasAngularVelocity = true, a.angularVelocity.copy(s.angularVelocity)) : a.hasAngularVelocity = false, this.dispatchEvent(Xl)));
    }
    return a !== null && (a.visible = s !== null), o !== null && (o.visible = n !== null), h !== null && (h.visible = r !== null), this;
  }
  _getHandJoint(t, e) {
    if (t.joints[e.jointName] === void 0) {
      const i = new Di();
      i.matrixAutoUpdate = false, i.visible = false, t.joints[e.jointName] = i, t.add(i);
    }
    return t.joints[e.jointName];
  }
}
const Bo = { aliceblue: 15792383, antiquewhite: 16444375, aqua: 65535, aquamarine: 8388564, azure: 15794175, beige: 16119260, bisque: 16770244, black: 0, blanchedalmond: 16772045, blue: 255, blueviolet: 9055202, brown: 10824234, burlywood: 14596231, cadetblue: 6266528, chartreuse: 8388352, chocolate: 13789470, coral: 16744272, cornflowerblue: 6591981, cornsilk: 16775388, crimson: 14423100, cyan: 65535, darkblue: 139, darkcyan: 35723, darkgoldenrod: 12092939, darkgray: 11119017, darkgreen: 25600, darkgrey: 11119017, darkkhaki: 12433259, darkmagenta: 9109643, darkolivegreen: 5597999, darkorange: 16747520, darkorchid: 10040012, darkred: 9109504, darksalmon: 15308410, darkseagreen: 9419919, darkslateblue: 4734347, darkslategray: 3100495, darkslategrey: 3100495, darkturquoise: 52945, darkviolet: 9699539, deeppink: 16716947, deepskyblue: 49151, dimgray: 6908265, dimgrey: 6908265, dodgerblue: 2003199, firebrick: 11674146, floralwhite: 16775920, forestgreen: 2263842, fuchsia: 16711935, gainsboro: 14474460, ghostwhite: 16316671, gold: 16766720, goldenrod: 14329120, gray: 8421504, green: 32768, greenyellow: 11403055, grey: 8421504, honeydew: 15794160, hotpink: 16738740, indianred: 13458524, indigo: 4915330, ivory: 16777200, khaki: 15787660, lavender: 15132410, lavenderblush: 16773365, lawngreen: 8190976, lemonchiffon: 16775885, lightblue: 11393254, lightcoral: 15761536, lightcyan: 14745599, lightgoldenrodyellow: 16448210, lightgray: 13882323, lightgreen: 9498256, lightgrey: 13882323, lightpink: 16758465, lightsalmon: 16752762, lightseagreen: 2142890, lightskyblue: 8900346, lightslategray: 7833753, lightslategrey: 7833753, lightsteelblue: 11584734, lightyellow: 16777184, lime: 65280, limegreen: 3329330, linen: 16445670, magenta: 16711935, maroon: 8388608, mediumaquamarine: 6737322, mediumblue: 205, mediumorchid: 12211667, mediumpurple: 9662683, mediumseagreen: 3978097, mediumslateblue: 8087790, mediumspringgreen: 64154, mediumturquoise: 4772300, mediumvioletred: 13047173, midnightblue: 1644912, mintcream: 16121850, mistyrose: 16770273, moccasin: 16770229, navajowhite: 16768685, navy: 128, oldlace: 16643558, olive: 8421376, olivedrab: 7048739, orange: 16753920, orangered: 16729344, orchid: 14315734, palegoldenrod: 15657130, palegreen: 10025880, paleturquoise: 11529966, palevioletred: 14381203, papayawhip: 16773077, peachpuff: 16767673, peru: 13468991, pink: 16761035, plum: 14524637, powderblue: 11591910, purple: 8388736, rebeccapurple: 6697881, red: 16711680, rosybrown: 12357519, royalblue: 4286945, saddlebrown: 9127187, salmon: 16416882, sandybrown: 16032864, seagreen: 3050327, seashell: 16774638, sienna: 10506797, silver: 12632256, skyblue: 8900331, slateblue: 6970061, slategray: 7372944, slategrey: 7372944, snow: 16775930, springgreen: 65407, steelblue: 4620980, tan: 13808780, teal: 32896, thistle: 14204888, tomato: 16737095, turquoise: 4251856, violet: 15631086, wheat: 16113331, white: 16777215, whitesmoke: 16119285, yellow: 16776960, yellowgreen: 10145074 }, ye = { h: 0, s: 0, l: 0 }, is = { h: 0, s: 0, l: 0 };
function gn(l, t, e) {
  return e < 0 && (e += 1), e > 1 && (e -= 1), e < 1 / 6 ? l + (t - l) * 6 * e : e < 1 / 2 ? t : e < 2 / 3 ? l + (t - l) * 6 * (2 / 3 - e) : l;
}
class U {
  constructor(t, e, i) {
    return this.isColor = true, this.r = 1, this.g = 1, this.b = 1, this.set(t, e, i);
  }
  set(t, e, i) {
    if (e === void 0 && i === void 0) {
      const s = t;
      s && s.isColor ? this.copy(s) : typeof s == "number" ? this.setHex(s) : typeof s == "string" && this.setStyle(s);
    } else this.setRGB(t, e, i);
    return this;
  }
  setScalar(t) {
    return this.r = t, this.g = t, this.b = t, this;
  }
  setHex(t, e = Ot) {
    return t = Math.floor(t), this.r = (t >> 16 & 255) / 255, this.g = (t >> 8 & 255) / 255, this.b = (t & 255) / 255, Rt.colorSpaceToWorking(this, e), this;
  }
  setRGB(t, e, i, s = Rt.workingColorSpace) {
    return this.r = t, this.g = e, this.b = i, Rt.colorSpaceToWorking(this, s), this;
  }
  setHSL(t, e, i, s = Rt.workingColorSpace) {
    if (t = ur(t, 1), e = L(e, 0, 1), i = L(i, 0, 1), e === 0) this.r = this.g = this.b = i;
    else {
      const n = i <= 0.5 ? i * (1 + e) : i + e - i * e, r = 2 * i - n;
      this.r = gn(r, n, t + 1 / 3), this.g = gn(r, n, t), this.b = gn(r, n, t - 1 / 3);
    }
    return Rt.colorSpaceToWorking(this, s), this;
  }
  setStyle(t, e = Ot) {
    function i(n) {
      n !== void 0 && parseFloat(n) < 1 && N("Color: Alpha component of " + t + " will be ignored.");
    }
    let s;
    if (s = /^(\w+)\(([^\)]*)\)/.exec(t)) {
      let n;
      const r = s[1], a = s[2];
      switch (r) {
        case "rgb":
        case "rgba":
          if (n = /^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return i(n[4]), this.setRGB(Math.min(255, parseInt(n[1], 10)) / 255, Math.min(255, parseInt(n[2], 10)) / 255, Math.min(255, parseInt(n[3], 10)) / 255, e);
          if (n = /^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return i(n[4]), this.setRGB(Math.min(100, parseInt(n[1], 10)) / 100, Math.min(100, parseInt(n[2], 10)) / 100, Math.min(100, parseInt(n[3], 10)) / 100, e);
          break;
        case "hsl":
        case "hsla":
          if (n = /^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return i(n[4]), this.setHSL(parseFloat(n[1]) / 360, parseFloat(n[2]) / 100, parseFloat(n[3]) / 100, e);
          break;
        default:
          N("Color: Unknown color model " + t);
      }
    } else if (s = /^\#([A-Fa-f\d]+)$/.exec(t)) {
      const n = s[1], r = n.length;
      if (r === 3) return this.setRGB(parseInt(n.charAt(0), 16) / 15, parseInt(n.charAt(1), 16) / 15, parseInt(n.charAt(2), 16) / 15, e);
      if (r === 6) return this.setHex(parseInt(n, 16), e);
      N("Color: Invalid hex color " + t);
    } else if (t && t.length > 0) return this.setColorName(t, e);
    return this;
  }
  setColorName(t, e = Ot) {
    const i = Bo[t.toLowerCase()];
    return i !== void 0 ? this.setHex(i, e) : N("Color: Unknown color " + t), this;
  }
  clone() {
    return new this.constructor(this.r, this.g, this.b);
  }
  copy(t) {
    return this.r = t.r, this.g = t.g, this.b = t.b, this;
  }
  copySRGBToLinear(t) {
    return this.r = de(t.r), this.g = de(t.g), this.b = de(t.b), this;
  }
  copyLinearToSRGB(t) {
    return this.r = gi(t.r), this.g = gi(t.g), this.b = gi(t.b), this;
  }
  convertSRGBToLinear() {
    return this.copySRGBToLinear(this), this;
  }
  convertLinearToSRGB() {
    return this.copyLinearToSRGB(this), this;
  }
  getHex(t = Ot) {
    return Rt.workingToColorSpace(pt.copy(this), t), Math.round(L(pt.r * 255, 0, 255)) * 65536 + Math.round(L(pt.g * 255, 0, 255)) * 256 + Math.round(L(pt.b * 255, 0, 255));
  }
  getHexString(t = Ot) {
    return ("000000" + this.getHex(t).toString(16)).slice(-6);
  }
  getHSL(t, e = Rt.workingColorSpace) {
    Rt.workingToColorSpace(pt.copy(this), e);
    const i = pt.r, s = pt.g, n = pt.b, r = Math.max(i, s, n), a = Math.min(i, s, n);
    let o, h;
    const c = (a + r) / 2;
    if (a === r) o = 0, h = 0;
    else {
      const u = r - a;
      switch (h = c <= 0.5 ? u / (r + a) : u / (2 - r - a), r) {
        case i:
          o = (s - n) / u + (s < n ? 6 : 0);
          break;
        case s:
          o = (n - i) / u + 2;
          break;
        case n:
          o = (i - s) / u + 4;
          break;
      }
      o /= 6;
    }
    return t.h = o, t.s = h, t.l = c, t;
  }
  getRGB(t, e = Rt.workingColorSpace) {
    return Rt.workingToColorSpace(pt.copy(this), e), t.r = pt.r, t.g = pt.g, t.b = pt.b, t;
  }
  getStyle(t = Ot) {
    Rt.workingToColorSpace(pt.copy(this), t);
    const e = pt.r, i = pt.g, s = pt.b;
    return t !== Ot ? `color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})` : `rgb(${Math.round(e * 255)},${Math.round(i * 255)},${Math.round(s * 255)})`;
  }
  offsetHSL(t, e, i) {
    return this.getHSL(ye), this.setHSL(ye.h + t, ye.s + e, ye.l + i);
  }
  add(t) {
    return this.r += t.r, this.g += t.g, this.b += t.b, this;
  }
  addColors(t, e) {
    return this.r = t.r + e.r, this.g = t.g + e.g, this.b = t.b + e.b, this;
  }
  addScalar(t) {
    return this.r += t, this.g += t, this.b += t, this;
  }
  sub(t) {
    return this.r = Math.max(0, this.r - t.r), this.g = Math.max(0, this.g - t.g), this.b = Math.max(0, this.b - t.b), this;
  }
  multiply(t) {
    return this.r *= t.r, this.g *= t.g, this.b *= t.b, this;
  }
  multiplyScalar(t) {
    return this.r *= t, this.g *= t, this.b *= t, this;
  }
  lerp(t, e) {
    return this.r += (t.r - this.r) * e, this.g += (t.g - this.g) * e, this.b += (t.b - this.b) * e, this;
  }
  lerpColors(t, e, i) {
    return this.r = t.r + (e.r - t.r) * i, this.g = t.g + (e.g - t.g) * i, this.b = t.b + (e.b - t.b) * i, this;
  }
  lerpHSL(t, e) {
    this.getHSL(ye), t.getHSL(is);
    const i = Wi(ye.h, is.h, e), s = Wi(ye.s, is.s, e), n = Wi(ye.l, is.l, e);
    return this.setHSL(i, s, n), this;
  }
  setFromVector3(t) {
    return this.r = t.x, this.g = t.y, this.b = t.z, this;
  }
  applyMatrix3(t) {
    const e = this.r, i = this.g, s = this.b, n = t.elements;
    return this.r = n[0] * e + n[3] * i + n[6] * s, this.g = n[1] * e + n[4] * i + n[7] * s, this.b = n[2] * e + n[5] * i + n[8] * s, this;
  }
  equals(t) {
    return t.r === this.r && t.g === this.g && t.b === this.b;
  }
  fromArray(t, e = 0) {
    return this.r = t[e], this.g = t[e + 1], this.b = t[e + 2], this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this.r, t[e + 1] = this.g, t[e + 2] = this.b, t;
  }
  fromBufferAttribute(t, e) {
    return this.r = t.getX(e), this.g = t.getY(e), this.b = t.getZ(e), this;
  }
  toJSON() {
    return this.getHex();
  }
  *[Symbol.iterator]() {
    yield this.r, yield this.g, yield this.b;
  }
}
const pt = new U();
U.NAMES = Bo;
class dr {
  constructor(t, e = 25e-5) {
    this.isFogExp2 = true, this.name = "", this.color = new U(t), this.density = e;
  }
  clone() {
    return new dr(this.color, this.density);
  }
  toJSON() {
    return { type: "FogExp2", name: this.name, color: this.color.getHex(), density: this.density };
  }
}
class pr {
  constructor(t, e = 1, i = 1e3) {
    this.isFog = true, this.name = "", this.color = new U(t), this.near = e, this.far = i;
  }
  clone() {
    return new pr(this.color, this.near, this.far);
  }
  toJSON() {
    return { type: "Fog", name: this.name, color: this.color.getHex(), near: this.near, far: this.far };
  }
}
class Zl extends $ {
  constructor() {
    super(), this.isScene = true, this.type = "Scene", this.background = null, this.environment = null, this.fog = null, this.backgroundBlurriness = 0, this.backgroundIntensity = 1, this.backgroundRotation = new jt(), this.environmentIntensity = 1, this.environmentRotation = new jt(), this.overrideMaterial = null, typeof __THREE_DEVTOOLS__ < "u" && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
  }
  copy(t, e) {
    return super.copy(t, e), t.background !== null && (this.background = t.background.clone()), t.environment !== null && (this.environment = t.environment.clone()), t.fog !== null && (this.fog = t.fog.clone()), this.backgroundBlurriness = t.backgroundBlurriness, this.backgroundIntensity = t.backgroundIntensity, this.backgroundRotation.copy(t.backgroundRotation), this.environmentIntensity = t.environmentIntensity, this.environmentRotation.copy(t.environmentRotation), t.overrideMaterial !== null && (this.overrideMaterial = t.overrideMaterial.clone()), this.matrixAutoUpdate = t.matrixAutoUpdate, this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return this.fog !== null && (e.object.fog = this.fog.toJSON()), this.backgroundBlurriness > 0 && (e.object.backgroundBlurriness = this.backgroundBlurriness), this.backgroundIntensity !== 1 && (e.object.backgroundIntensity = this.backgroundIntensity), e.object.backgroundRotation = this.backgroundRotation.toArray(), this.environmentIntensity !== 1 && (e.object.environmentIntensity = this.environmentIntensity), e.object.environmentRotation = this.environmentRotation.toArray(), e;
  }
}
const Ut = new w(), re = new w(), xn = new w(), ae = new w(), je = new w(), Qe = new w(), va = new w(), bn = new w(), Mn = new w(), wn = new w(), _n = new Nt(), vn = new Nt(), Sn = new Nt();
class It {
  constructor(t = new w(), e = new w(), i = new w()) {
    this.a = t, this.b = e, this.c = i;
  }
  static getNormal(t, e, i, s) {
    s.subVectors(i, e), Ut.subVectors(t, e), s.cross(Ut);
    const n = s.lengthSq();
    return n > 0 ? s.multiplyScalar(1 / Math.sqrt(n)) : s.set(0, 0, 0);
  }
  static getBarycoord(t, e, i, s, n) {
    Ut.subVectors(s, e), re.subVectors(i, e), xn.subVectors(t, e);
    const r = Ut.dot(Ut), a = Ut.dot(re), o = Ut.dot(xn), h = re.dot(re), c = re.dot(xn), u = r * h - a * a;
    if (u === 0) return n.set(0, 0, 0), null;
    const d = 1 / u, p = (h * o - a * c) * d, f = (r * c - a * o) * d;
    return n.set(1 - p - f, f, p);
  }
  static containsPoint(t, e, i, s) {
    return this.getBarycoord(t, e, i, s, ae) === null ? false : ae.x >= 0 && ae.y >= 0 && ae.x + ae.y <= 1;
  }
  static getInterpolation(t, e, i, s, n, r, a, o) {
    return this.getBarycoord(t, e, i, s, ae) === null ? (o.x = 0, o.y = 0, "z" in o && (o.z = 0), "w" in o && (o.w = 0), null) : (o.setScalar(0), o.addScaledVector(n, ae.x), o.addScaledVector(r, ae.y), o.addScaledVector(a, ae.z), o);
  }
  static getInterpolatedAttribute(t, e, i, s, n, r) {
    return _n.setScalar(0), vn.setScalar(0), Sn.setScalar(0), _n.fromBufferAttribute(t, e), vn.fromBufferAttribute(t, i), Sn.fromBufferAttribute(t, s), r.setScalar(0), r.addScaledVector(_n, n.x), r.addScaledVector(vn, n.y), r.addScaledVector(Sn, n.z), r;
  }
  static isFrontFacing(t, e, i, s) {
    return Ut.subVectors(i, e), re.subVectors(t, e), Ut.cross(re).dot(s) < 0;
  }
  set(t, e, i) {
    return this.a.copy(t), this.b.copy(e), this.c.copy(i), this;
  }
  setFromPointsAndIndices(t, e, i, s) {
    return this.a.copy(t[e]), this.b.copy(t[i]), this.c.copy(t[s]), this;
  }
  setFromAttributeAndIndices(t, e, i, s) {
    return this.a.fromBufferAttribute(t, e), this.b.fromBufferAttribute(t, i), this.c.fromBufferAttribute(t, s), this;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    return this.a.copy(t.a), this.b.copy(t.b), this.c.copy(t.c), this;
  }
  getArea() {
    return Ut.subVectors(this.c, this.b), re.subVectors(this.a, this.b), Ut.cross(re).length() * 0.5;
  }
  getMidpoint(t) {
    return t.addVectors(this.a, this.b).add(this.c).multiplyScalar(1 / 3);
  }
  getNormal(t) {
    return It.getNormal(this.a, this.b, this.c, t);
  }
  getPlane(t) {
    return t.setFromCoplanarPoints(this.a, this.b, this.c);
  }
  getBarycoord(t, e) {
    return It.getBarycoord(t, this.a, this.b, this.c, e);
  }
  getInterpolation(t, e, i, s, n) {
    return It.getInterpolation(t, this.a, this.b, this.c, e, i, s, n);
  }
  containsPoint(t) {
    return It.containsPoint(t, this.a, this.b, this.c);
  }
  isFrontFacing(t) {
    return It.isFrontFacing(this.a, this.b, this.c, t);
  }
  intersectsBox(t) {
    return t.intersectsTriangle(this);
  }
  closestPointToPoint(t, e) {
    const i = this.a, s = this.b, n = this.c;
    let r, a;
    je.subVectors(s, i), Qe.subVectors(n, i), bn.subVectors(t, i);
    const o = je.dot(bn), h = Qe.dot(bn);
    if (o <= 0 && h <= 0) return e.copy(i);
    Mn.subVectors(t, s);
    const c = je.dot(Mn), u = Qe.dot(Mn);
    if (c >= 0 && u <= c) return e.copy(s);
    const d = o * u - c * h;
    if (d <= 0 && o >= 0 && c <= 0) return r = o / (o - c), e.copy(i).addScaledVector(je, r);
    wn.subVectors(t, n);
    const p = je.dot(wn), f = Qe.dot(wn);
    if (f >= 0 && p <= f) return e.copy(n);
    const m = p * h - o * f;
    if (m <= 0 && h >= 0 && f <= 0) return a = h / (h - f), e.copy(i).addScaledVector(Qe, a);
    const g = c * f - p * u;
    if (g <= 0 && u - c >= 0 && p - f >= 0) return va.subVectors(n, s), a = (u - c) / (u - c + (p - f)), e.copy(s).addScaledVector(va, a);
    const y = 1 / (g + m + d);
    return r = m * y, a = d * y, e.copy(i).addScaledVector(je, r).addScaledVector(Qe, a);
  }
  equals(t) {
    return t.a.equals(this.a) && t.b.equals(this.b) && t.c.equals(this.c);
  }
}
class xt {
  constructor(t = new w(1 / 0, 1 / 0, 1 / 0), e = new w(-1 / 0, -1 / 0, -1 / 0)) {
    this.isBox3 = true, this.min = t, this.max = e;
  }
  set(t, e) {
    return this.min.copy(t), this.max.copy(e), this;
  }
  setFromArray(t) {
    this.makeEmpty();
    for (let e = 0, i = t.length; e < i; e += 3) this.expandByPoint(Wt.fromArray(t, e));
    return this;
  }
  setFromBufferAttribute(t) {
    this.makeEmpty();
    for (let e = 0, i = t.count; e < i; e++) this.expandByPoint(Wt.fromBufferAttribute(t, e));
    return this;
  }
  setFromPoints(t) {
    this.makeEmpty();
    for (let e = 0, i = t.length; e < i; e++) this.expandByPoint(t[e]);
    return this;
  }
  setFromCenterAndSize(t, e) {
    const i = Wt.copy(e).multiplyScalar(0.5);
    return this.min.copy(t).sub(i), this.max.copy(t).add(i), this;
  }
  setFromObject(t, e = false) {
    return this.makeEmpty(), this.expandByObject(t, e);
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    return this.min.copy(t.min), this.max.copy(t.max), this;
  }
  makeEmpty() {
    return this.min.x = this.min.y = this.min.z = 1 / 0, this.max.x = this.max.y = this.max.z = -1 / 0, this;
  }
  isEmpty() {
    return this.max.x < this.min.x || this.max.y < this.min.y || this.max.z < this.min.z;
  }
  getCenter(t) {
    return this.isEmpty() ? t.set(0, 0, 0) : t.addVectors(this.min, this.max).multiplyScalar(0.5);
  }
  getSize(t) {
    return this.isEmpty() ? t.set(0, 0, 0) : t.subVectors(this.max, this.min);
  }
  expandByPoint(t) {
    return this.min.min(t), this.max.max(t), this;
  }
  expandByVector(t) {
    return this.min.sub(t), this.max.add(t), this;
  }
  expandByScalar(t) {
    return this.min.addScalar(-t), this.max.addScalar(t), this;
  }
  expandByObject(t, e = false) {
    t.updateWorldMatrix(false, false);
    const i = t.geometry;
    if (i !== void 0) {
      const n = i.getAttribute("position");
      if (e === true && n !== void 0 && t.isInstancedMesh !== true) for (let r = 0, a = n.count; r < a; r++) t.isMesh === true ? t.getVertexPosition(r, Wt) : Wt.fromBufferAttribute(n, r), Wt.applyMatrix4(t.matrixWorld), this.expandByPoint(Wt);
      else t.boundingBox !== void 0 ? (t.boundingBox === null && t.computeBoundingBox(), ss.copy(t.boundingBox)) : (i.boundingBox === null && i.computeBoundingBox(), ss.copy(i.boundingBox)), ss.applyMatrix4(t.matrixWorld), this.union(ss);
    }
    const s = t.children;
    for (let n = 0, r = s.length; n < r; n++) this.expandByObject(s[n], e);
    return this;
  }
  containsPoint(t) {
    return t.x >= this.min.x && t.x <= this.max.x && t.y >= this.min.y && t.y <= this.max.y && t.z >= this.min.z && t.z <= this.max.z;
  }
  containsBox(t) {
    return this.min.x <= t.min.x && t.max.x <= this.max.x && this.min.y <= t.min.y && t.max.y <= this.max.y && this.min.z <= t.min.z && t.max.z <= this.max.z;
  }
  getParameter(t, e) {
    return e.set((t.x - this.min.x) / (this.max.x - this.min.x), (t.y - this.min.y) / (this.max.y - this.min.y), (t.z - this.min.z) / (this.max.z - this.min.z));
  }
  intersectsBox(t) {
    return t.max.x >= this.min.x && t.min.x <= this.max.x && t.max.y >= this.min.y && t.min.y <= this.max.y && t.max.z >= this.min.z && t.min.z <= this.max.z;
  }
  intersectsSphere(t) {
    return this.clampPoint(t.center, Wt), Wt.distanceToSquared(t.center) <= t.radius * t.radius;
  }
  intersectsPlane(t) {
    let e, i;
    return t.normal.x > 0 ? (e = t.normal.x * this.min.x, i = t.normal.x * this.max.x) : (e = t.normal.x * this.max.x, i = t.normal.x * this.min.x), t.normal.y > 0 ? (e += t.normal.y * this.min.y, i += t.normal.y * this.max.y) : (e += t.normal.y * this.max.y, i += t.normal.y * this.min.y), t.normal.z > 0 ? (e += t.normal.z * this.min.z, i += t.normal.z * this.max.z) : (e += t.normal.z * this.max.z, i += t.normal.z * this.min.z), e <= -t.constant && i >= -t.constant;
  }
  intersectsTriangle(t) {
    if (this.isEmpty()) return false;
    this.getCenter(zi), ns.subVectors(this.max, zi), Ke.subVectors(t.a, zi), ti.subVectors(t.b, zi), ei.subVectors(t.c, zi), ge.subVectors(ti, Ke), xe.subVectors(ei, ti), Te.subVectors(Ke, ei);
    let e = [0, -ge.z, ge.y, 0, -xe.z, xe.y, 0, -Te.z, Te.y, ge.z, 0, -ge.x, xe.z, 0, -xe.x, Te.z, 0, -Te.x, -ge.y, ge.x, 0, -xe.y, xe.x, 0, -Te.y, Te.x, 0];
    return !An(e, Ke, ti, ei, ns) || (e = [1, 0, 0, 0, 1, 0, 0, 0, 1], !An(e, Ke, ti, ei, ns)) ? false : (rs.crossVectors(ge, xe), e = [rs.x, rs.y, rs.z], An(e, Ke, ti, ei, ns));
  }
  clampPoint(t, e) {
    return e.copy(t).clamp(this.min, this.max);
  }
  distanceToPoint(t) {
    return this.clampPoint(t, Wt).distanceTo(t);
  }
  getBoundingSphere(t) {
    return this.isEmpty() ? t.makeEmpty() : (this.getCenter(t.center), t.radius = this.getSize(Wt).length() * 0.5), t;
  }
  intersect(t) {
    return this.min.max(t.min), this.max.min(t.max), this.isEmpty() && this.makeEmpty(), this;
  }
  union(t) {
    return this.min.min(t.min), this.max.max(t.max), this;
  }
  applyMatrix4(t) {
    return this.isEmpty() ? this : (oe[0].set(this.min.x, this.min.y, this.min.z).applyMatrix4(t), oe[1].set(this.min.x, this.min.y, this.max.z).applyMatrix4(t), oe[2].set(this.min.x, this.max.y, this.min.z).applyMatrix4(t), oe[3].set(this.min.x, this.max.y, this.max.z).applyMatrix4(t), oe[4].set(this.max.x, this.min.y, this.min.z).applyMatrix4(t), oe[5].set(this.max.x, this.min.y, this.max.z).applyMatrix4(t), oe[6].set(this.max.x, this.max.y, this.min.z).applyMatrix4(t), oe[7].set(this.max.x, this.max.y, this.max.z).applyMatrix4(t), this.setFromPoints(oe), this);
  }
  translate(t) {
    return this.min.add(t), this.max.add(t), this;
  }
  equals(t) {
    return t.min.equals(this.min) && t.max.equals(this.max);
  }
  toJSON() {
    return { min: this.min.toArray(), max: this.max.toArray() };
  }
  fromJSON(t) {
    return this.min.fromArray(t.min), this.max.fromArray(t.max), this;
  }
}
const oe = [new w(), new w(), new w(), new w(), new w(), new w(), new w(), new w()], Wt = new w(), ss = new xt(), Ke = new w(), ti = new w(), ei = new w(), ge = new w(), xe = new w(), Te = new w(), zi = new w(), ns = new w(), rs = new w(), Ce = new w();
function An(l, t, e, i, s) {
  for (let n = 0, r = l.length - 3; n <= r; n += 3) {
    Ce.fromArray(l, n);
    const a = s.x * Math.abs(Ce.x) + s.y * Math.abs(Ce.y) + s.z * Math.abs(Ce.z), o = t.dot(Ce), h = e.dot(Ce), c = i.dot(Ce);
    if (Math.max(-Math.max(o, h, c), Math.min(o, h, c)) > a) return false;
  }
  return true;
}
const ce = Yl();
function Yl() {
  const l = new ArrayBuffer(4), t = new Float32Array(l), e = new Uint32Array(l), i = new Uint32Array(512), s = new Uint32Array(512);
  for (let o = 0; o < 256; ++o) {
    const h = o - 127;
    h < -27 ? (i[o] = 0, i[o | 256] = 32768, s[o] = 24, s[o | 256] = 24) : h < -14 ? (i[o] = 1024 >> -h - 14, i[o | 256] = 1024 >> -h - 14 | 32768, s[o] = -h - 1, s[o | 256] = -h - 1) : h <= 15 ? (i[o] = h + 15 << 10, i[o | 256] = h + 15 << 10 | 32768, s[o] = 13, s[o | 256] = 13) : h < 128 ? (i[o] = 31744, i[o | 256] = 64512, s[o] = 24, s[o | 256] = 24) : (i[o] = 31744, i[o | 256] = 64512, s[o] = 13, s[o | 256] = 13);
  }
  const n = new Uint32Array(2048), r = new Uint32Array(64), a = new Uint32Array(64);
  for (let o = 1; o < 1024; ++o) {
    let h = o << 13, c = 0;
    for (; (h & 8388608) === 0; ) h <<= 1, c -= 8388608;
    h &= -8388609, c += 947912704, n[o] = h | c;
  }
  for (let o = 1024; o < 2048; ++o) n[o] = 939524096 + (o - 1024 << 13);
  for (let o = 1; o < 31; ++o) r[o] = o << 23;
  r[31] = 1199570944, r[32] = 2147483648;
  for (let o = 33; o < 63; ++o) r[o] = 2147483648 + (o - 32 << 23);
  r[63] = 3347054592;
  for (let o = 1; o < 64; ++o) o !== 32 && (a[o] = 1024);
  return { floatView: t, uint32View: e, baseTable: i, shiftTable: s, mantissaTable: n, exponentTable: r, offsetTable: a };
}
function wt(l) {
  Math.abs(l) > 65504 && N("DataUtils.toHalfFloat(): Value out of range."), l = L(l, -65504, 65504), ce.floatView[0] = l;
  const t = ce.uint32View[0], e = t >> 23 & 511;
  return ce.baseTable[e] + ((t & 8388607) >> ce.shiftTable[e]);
}
function Vi(l) {
  const t = l >> 10;
  return ce.uint32View[0] = ce.mantissaTable[ce.offsetTable[t] + (l & 1023)] + ce.exponentTable[t], ce.floatView[0];
}
class ff {
  static toHalfFloat(t) {
    return wt(t);
  }
  static fromHalfFloat(t) {
    return Vi(t);
  }
}
const ht = new w(), as = new I();
let $l = 0;
class tt {
  constructor(t, e, i = false) {
    if (Array.isArray(t)) throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");
    this.isBufferAttribute = true, Object.defineProperty(this, "id", { value: $l++ }), this.name = "", this.array = t, this.itemSize = e, this.count = t !== void 0 ? t.length / e : 0, this.normalized = i, this.usage = Xs, this.updateRanges = [], this.gpuType = bi, this.version = 0;
  }
  onUploadCallback() {
  }
  set needsUpdate(t) {
    t === true && this.version++;
  }
  setUsage(t) {
    return this.usage = t, this;
  }
  addUpdateRange(t, e) {
    this.updateRanges.push({ start: t, count: e });
  }
  clearUpdateRanges() {
    this.updateRanges.length = 0;
  }
  copy(t) {
    return this.name = t.name, this.array = new t.array.constructor(t.array), this.itemSize = t.itemSize, this.count = t.count, this.normalized = t.normalized, this.usage = t.usage, this.gpuType = t.gpuType, this;
  }
  copyAt(t, e, i) {
    t *= this.itemSize, i *= e.itemSize;
    for (let s = 0, n = this.itemSize; s < n; s++) this.array[t + s] = e.array[i + s];
    return this;
  }
  copyArray(t) {
    return this.array.set(t), this;
  }
  applyMatrix3(t) {
    if (this.itemSize === 2) for (let e = 0, i = this.count; e < i; e++) as.fromBufferAttribute(this, e), as.applyMatrix3(t), this.setXY(e, as.x, as.y);
    else if (this.itemSize === 3) for (let e = 0, i = this.count; e < i; e++) ht.fromBufferAttribute(this, e), ht.applyMatrix3(t), this.setXYZ(e, ht.x, ht.y, ht.z);
    return this;
  }
  applyMatrix4(t) {
    for (let e = 0, i = this.count; e < i; e++) ht.fromBufferAttribute(this, e), ht.applyMatrix4(t), this.setXYZ(e, ht.x, ht.y, ht.z);
    return this;
  }
  applyNormalMatrix(t) {
    for (let e = 0, i = this.count; e < i; e++) ht.fromBufferAttribute(this, e), ht.applyNormalMatrix(t), this.setXYZ(e, ht.x, ht.y, ht.z);
    return this;
  }
  transformDirection(t) {
    for (let e = 0, i = this.count; e < i; e++) ht.fromBufferAttribute(this, e), ht.transformDirection(t), this.setXYZ(e, ht.x, ht.y, ht.z);
    return this;
  }
  set(t, e = 0) {
    return this.array.set(t, e), this;
  }
  getComponent(t, e) {
    let i = this.array[t * this.itemSize + e];
    return this.normalized && (i = gt(i, this.array)), i;
  }
  setComponent(t, e, i) {
    return this.normalized && (i = W(i, this.array)), this.array[t * this.itemSize + e] = i, this;
  }
  getX(t) {
    let e = this.array[t * this.itemSize];
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setX(t, e) {
    return this.normalized && (e = W(e, this.array)), this.array[t * this.itemSize] = e, this;
  }
  getY(t) {
    let e = this.array[t * this.itemSize + 1];
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setY(t, e) {
    return this.normalized && (e = W(e, this.array)), this.array[t * this.itemSize + 1] = e, this;
  }
  getZ(t) {
    let e = this.array[t * this.itemSize + 2];
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setZ(t, e) {
    return this.normalized && (e = W(e, this.array)), this.array[t * this.itemSize + 2] = e, this;
  }
  getW(t) {
    let e = this.array[t * this.itemSize + 3];
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setW(t, e) {
    return this.normalized && (e = W(e, this.array)), this.array[t * this.itemSize + 3] = e, this;
  }
  setXY(t, e, i) {
    return t *= this.itemSize, this.normalized && (e = W(e, this.array), i = W(i, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this;
  }
  setXYZ(t, e, i, s) {
    return t *= this.itemSize, this.normalized && (e = W(e, this.array), i = W(i, this.array), s = W(s, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this.array[t + 2] = s, this;
  }
  setXYZW(t, e, i, s, n) {
    return t *= this.itemSize, this.normalized && (e = W(e, this.array), i = W(i, this.array), s = W(s, this.array), n = W(n, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this.array[t + 2] = s, this.array[t + 3] = n, this;
  }
  onUpload(t) {
    return this.onUploadCallback = t, this;
  }
  clone() {
    return new this.constructor(this.array, this.itemSize).copy(this);
  }
  toJSON() {
    const t = { itemSize: this.itemSize, type: this.array.constructor.name, array: Array.from(this.array), normalized: this.normalized };
    return this.name !== "" && (t.name = this.name), this.usage !== Xs && (t.usage = this.usage), t;
  }
}
class mf extends tt {
  constructor(t, e, i) {
    super(new Int8Array(t), e, i);
  }
}
class yf extends tt {
  constructor(t, e, i) {
    super(new Uint8Array(t), e, i);
  }
}
class gf extends tt {
  constructor(t, e, i) {
    super(new Uint8ClampedArray(t), e, i);
  }
}
class xf extends tt {
  constructor(t, e, i) {
    super(new Int16Array(t), e, i);
  }
}
class jl extends tt {
  constructor(t, e, i) {
    super(new Uint16Array(t), e, i);
  }
}
class bf extends tt {
  constructor(t, e, i) {
    super(new Int32Array(t), e, i);
  }
}
class Ql extends tt {
  constructor(t, e, i) {
    super(new Uint32Array(t), e, i);
  }
}
class Mf extends tt {
  constructor(t, e, i) {
    super(new Uint16Array(t), e, i), this.isFloat16BufferAttribute = true;
  }
  getX(t) {
    let e = Vi(this.array[t * this.itemSize]);
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setX(t, e) {
    return this.normalized && (e = W(e, this.array)), this.array[t * this.itemSize] = wt(e), this;
  }
  getY(t) {
    let e = Vi(this.array[t * this.itemSize + 1]);
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setY(t, e) {
    return this.normalized && (e = W(e, this.array)), this.array[t * this.itemSize + 1] = wt(e), this;
  }
  getZ(t) {
    let e = Vi(this.array[t * this.itemSize + 2]);
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setZ(t, e) {
    return this.normalized && (e = W(e, this.array)), this.array[t * this.itemSize + 2] = wt(e), this;
  }
  getW(t) {
    let e = Vi(this.array[t * this.itemSize + 3]);
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setW(t, e) {
    return this.normalized && (e = W(e, this.array)), this.array[t * this.itemSize + 3] = wt(e), this;
  }
  setXY(t, e, i) {
    return t *= this.itemSize, this.normalized && (e = W(e, this.array), i = W(i, this.array)), this.array[t + 0] = wt(e), this.array[t + 1] = wt(i), this;
  }
  setXYZ(t, e, i, s) {
    return t *= this.itemSize, this.normalized && (e = W(e, this.array), i = W(i, this.array), s = W(s, this.array)), this.array[t + 0] = wt(e), this.array[t + 1] = wt(i), this.array[t + 2] = wt(s), this;
  }
  setXYZW(t, e, i, s, n) {
    return t *= this.itemSize, this.normalized && (e = W(e, this.array), i = W(i, this.array), s = W(s, this.array), n = W(n, this.array)), this.array[t + 0] = wt(e), this.array[t + 1] = wt(i), this.array[t + 2] = wt(s), this.array[t + 3] = wt(n), this;
  }
}
class P extends tt {
  constructor(t, e, i) {
    super(new Float32Array(t), e, i);
  }
}
const Kl = new xt(), Bi = new w(), Tn = new w();
class mt {
  constructor(t = new w(), e = -1) {
    this.isSphere = true, this.center = t, this.radius = e;
  }
  set(t, e) {
    return this.center.copy(t), this.radius = e, this;
  }
  setFromPoints(t, e) {
    const i = this.center;
    e !== void 0 ? i.copy(e) : Kl.setFromPoints(t).getCenter(i);
    let s = 0;
    for (let n = 0, r = t.length; n < r; n++) s = Math.max(s, i.distanceToSquared(t[n]));
    return this.radius = Math.sqrt(s), this;
  }
  copy(t) {
    return this.center.copy(t.center), this.radius = t.radius, this;
  }
  isEmpty() {
    return this.radius < 0;
  }
  makeEmpty() {
    return this.center.set(0, 0, 0), this.radius = -1, this;
  }
  containsPoint(t) {
    return t.distanceToSquared(this.center) <= this.radius * this.radius;
  }
  distanceToPoint(t) {
    return t.distanceTo(this.center) - this.radius;
  }
  intersectsSphere(t) {
    const e = this.radius + t.radius;
    return t.center.distanceToSquared(this.center) <= e * e;
  }
  intersectsBox(t) {
    return t.intersectsSphere(this);
  }
  intersectsPlane(t) {
    return Math.abs(t.distanceToPoint(this.center)) <= this.radius;
  }
  clampPoint(t, e) {
    const i = this.center.distanceToSquared(t);
    return e.copy(t), i > this.radius * this.radius && (e.sub(this.center).normalize(), e.multiplyScalar(this.radius).add(this.center)), e;
  }
  getBoundingBox(t) {
    return this.isEmpty() ? (t.makeEmpty(), t) : (t.set(this.center, this.center), t.expandByScalar(this.radius), t);
  }
  applyMatrix4(t) {
    return this.center.applyMatrix4(t), this.radius = this.radius * t.getMaxScaleOnAxis(), this;
  }
  translate(t) {
    return this.center.add(t), this;
  }
  expandByPoint(t) {
    if (this.isEmpty()) return this.center.copy(t), this.radius = 0, this;
    Bi.subVectors(t, this.center);
    const e = Bi.lengthSq();
    if (e > this.radius * this.radius) {
      const i = Math.sqrt(e), s = (i - this.radius) * 0.5;
      this.center.addScaledVector(Bi, s / i), this.radius += s;
    }
    return this;
  }
  union(t) {
    return t.isEmpty() ? this : this.isEmpty() ? (this.copy(t), this) : (this.center.equals(t.center) === true ? this.radius = Math.max(this.radius, t.radius) : (Tn.subVectors(t.center, this.center).setLength(t.radius), this.expandByPoint(Bi.copy(t.center).add(Tn)), this.expandByPoint(Bi.copy(t.center).sub(Tn))), this);
  }
  equals(t) {
    return t.center.equals(this.center) && t.radius === this.radius;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  toJSON() {
    return { radius: this.radius, center: this.center.toArray() };
  }
  fromJSON(t) {
    return this.radius = t.radius, this.center.fromArray(t.center), this;
  }
}
let tc = 0;
const Pt = new G(), Cn = new $(), ii = new w(), Ct = new xt(), Fi = new xt(), ut = new w();
class H extends Se {
  constructor() {
    super(), this.isBufferGeometry = true, Object.defineProperty(this, "id", { value: tc++ }), this.uuid = zt(), this.name = "", this.type = "BufferGeometry", this.index = null, this.indirect = null, this.indirectOffset = 0, this.attributes = {}, this.morphAttributes = {}, this.morphTargetsRelative = false, this.groups = [], this.boundingBox = null, this.boundingSphere = null, this.drawRange = { start: 0, count: 1 / 0 }, this.userData = {};
  }
  getIndex() {
    return this.index;
  }
  setIndex(t) {
    return Array.isArray(t) ? this.index = new (xl(t) ? Ql : jl)(t, 1) : this.index = t, this;
  }
  setIndirect(t, e = 0) {
    return this.indirect = t, this.indirectOffset = e, this;
  }
  getIndirect() {
    return this.indirect;
  }
  getAttribute(t) {
    return this.attributes[t];
  }
  setAttribute(t, e) {
    return this.attributes[t] = e, this;
  }
  deleteAttribute(t) {
    return delete this.attributes[t], this;
  }
  hasAttribute(t) {
    return this.attributes[t] !== void 0;
  }
  addGroup(t, e, i = 0) {
    this.groups.push({ start: t, count: e, materialIndex: i });
  }
  clearGroups() {
    this.groups = [];
  }
  setDrawRange(t, e) {
    this.drawRange.start = t, this.drawRange.count = e;
  }
  applyMatrix4(t) {
    const e = this.attributes.position;
    e !== void 0 && (e.applyMatrix4(t), e.needsUpdate = true);
    const i = this.attributes.normal;
    if (i !== void 0) {
      const n = new Qt().getNormalMatrix(t);
      i.applyNormalMatrix(n), i.needsUpdate = true;
    }
    const s = this.attributes.tangent;
    return s !== void 0 && (s.transformDirection(t), s.needsUpdate = true), this.boundingBox !== null && this.computeBoundingBox(), this.boundingSphere !== null && this.computeBoundingSphere(), this;
  }
  applyQuaternion(t) {
    return Pt.makeRotationFromQuaternion(t), this.applyMatrix4(Pt), this;
  }
  rotateX(t) {
    return Pt.makeRotationX(t), this.applyMatrix4(Pt), this;
  }
  rotateY(t) {
    return Pt.makeRotationY(t), this.applyMatrix4(Pt), this;
  }
  rotateZ(t) {
    return Pt.makeRotationZ(t), this.applyMatrix4(Pt), this;
  }
  translate(t, e, i) {
    return Pt.makeTranslation(t, e, i), this.applyMatrix4(Pt), this;
  }
  scale(t, e, i) {
    return Pt.makeScale(t, e, i), this.applyMatrix4(Pt), this;
  }
  lookAt(t) {
    return Cn.lookAt(t), Cn.updateMatrix(), this.applyMatrix4(Cn.matrix), this;
  }
  center() {
    return this.computeBoundingBox(), this.boundingBox.getCenter(ii).negate(), this.translate(ii.x, ii.y, ii.z), this;
  }
  setFromPoints(t) {
    const e = this.getAttribute("position");
    if (e === void 0) {
      const i = [];
      for (let s = 0, n = t.length; s < n; s++) {
        const r = t[s];
        i.push(r.x, r.y, r.z || 0);
      }
      this.setAttribute("position", new P(i, 3));
    } else {
      const i = Math.min(t.length, e.count);
      for (let s = 0; s < i; s++) {
        const n = t[s];
        e.setXYZ(s, n.x, n.y, n.z || 0);
      }
      t.length > e.count && N("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."), e.needsUpdate = true;
    }
    return this;
  }
  computeBoundingBox() {
    this.boundingBox === null && (this.boundingBox = new xt());
    const t = this.attributes.position, e = this.morphAttributes.position;
    if (t && t.isGLBufferAttribute) {
      Y("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.", this), this.boundingBox.set(new w(-1 / 0, -1 / 0, -1 / 0), new w(1 / 0, 1 / 0, 1 / 0));
      return;
    }
    if (t !== void 0) {
      if (this.boundingBox.setFromBufferAttribute(t), e) for (let i = 0, s = e.length; i < s; i++) {
        const n = e[i];
        Ct.setFromBufferAttribute(n), this.morphTargetsRelative ? (ut.addVectors(this.boundingBox.min, Ct.min), this.boundingBox.expandByPoint(ut), ut.addVectors(this.boundingBox.max, Ct.max), this.boundingBox.expandByPoint(ut)) : (this.boundingBox.expandByPoint(Ct.min), this.boundingBox.expandByPoint(Ct.max));
      }
    } else this.boundingBox.makeEmpty();
    (isNaN(this.boundingBox.min.x) || isNaN(this.boundingBox.min.y) || isNaN(this.boundingBox.min.z)) && Y('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.', this);
  }
  computeBoundingSphere() {
    this.boundingSphere === null && (this.boundingSphere = new mt());
    const t = this.attributes.position, e = this.morphAttributes.position;
    if (t && t.isGLBufferAttribute) {
      Y("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.", this), this.boundingSphere.set(new w(), 1 / 0);
      return;
    }
    if (t) {
      const i = this.boundingSphere.center;
      if (Ct.setFromBufferAttribute(t), e) for (let n = 0, r = e.length; n < r; n++) {
        const a = e[n];
        Fi.setFromBufferAttribute(a), this.morphTargetsRelative ? (ut.addVectors(Ct.min, Fi.min), Ct.expandByPoint(ut), ut.addVectors(Ct.max, Fi.max), Ct.expandByPoint(ut)) : (Ct.expandByPoint(Fi.min), Ct.expandByPoint(Fi.max));
      }
      Ct.getCenter(i);
      let s = 0;
      for (let n = 0, r = t.count; n < r; n++) ut.fromBufferAttribute(t, n), s = Math.max(s, i.distanceToSquared(ut));
      if (e) for (let n = 0, r = e.length; n < r; n++) {
        const a = e[n], o = this.morphTargetsRelative;
        for (let h = 0, c = a.count; h < c; h++) ut.fromBufferAttribute(a, h), o && (ii.fromBufferAttribute(t, h), ut.add(ii)), s = Math.max(s, i.distanceToSquared(ut));
      }
      this.boundingSphere.radius = Math.sqrt(s), isNaN(this.boundingSphere.radius) && Y('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.', this);
    }
  }
  computeTangents() {
    const t = this.index, e = this.attributes;
    if (t === null || e.position === void 0 || e.normal === void 0 || e.uv === void 0) {
      Y("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");
      return;
    }
    const i = e.position, s = e.normal, n = e.uv;
    this.hasAttribute("tangent") === false && this.setAttribute("tangent", new tt(new Float32Array(4 * i.count), 4));
    const r = this.getAttribute("tangent"), a = [], o = [];
    for (let S = 0; S < i.count; S++) a[S] = new w(), o[S] = new w();
    const h = new w(), c = new w(), u = new w(), d = new I(), p = new I(), f = new I(), m = new w(), g = new w();
    function y(S, T, C) {
      h.fromBufferAttribute(i, S), c.fromBufferAttribute(i, T), u.fromBufferAttribute(i, C), d.fromBufferAttribute(n, S), p.fromBufferAttribute(n, T), f.fromBufferAttribute(n, C), c.sub(h), u.sub(h), p.sub(d), f.sub(d);
      const B = 1 / (p.x * f.y - f.x * p.y);
      isFinite(B) && (m.copy(c).multiplyScalar(f.y).addScaledVector(u, -p.y).multiplyScalar(B), g.copy(u).multiplyScalar(p.x).addScaledVector(c, -f.x).multiplyScalar(B), a[S].add(m), a[T].add(m), a[C].add(m), o[S].add(g), o[T].add(g), o[C].add(g));
    }
    let x = this.groups;
    x.length === 0 && (x = [{ start: 0, count: t.count }]);
    for (let S = 0, T = x.length; S < T; ++S) {
      const C = x[S], B = C.start, O = C.count;
      for (let D = B, J = B + O; D < J; D += 3) y(t.getX(D + 0), t.getX(D + 1), t.getX(D + 2));
    }
    const b = new w(), M = new w(), _ = new w(), v = new w();
    function A(S) {
      _.fromBufferAttribute(s, S), v.copy(_);
      const T = a[S];
      b.copy(T), b.sub(_.multiplyScalar(_.dot(T))).normalize(), M.crossVectors(v, T);
      const B = M.dot(o[S]) < 0 ? -1 : 1;
      r.setXYZW(S, b.x, b.y, b.z, B);
    }
    for (let S = 0, T = x.length; S < T; ++S) {
      const C = x[S], B = C.start, O = C.count;
      for (let D = B, J = B + O; D < J; D += 3) A(t.getX(D + 0)), A(t.getX(D + 1)), A(t.getX(D + 2));
    }
  }
  computeVertexNormals() {
    const t = this.index, e = this.getAttribute("position");
    if (e !== void 0) {
      let i = this.getAttribute("normal");
      if (i === void 0) i = new tt(new Float32Array(e.count * 3), 3), this.setAttribute("normal", i);
      else for (let d = 0, p = i.count; d < p; d++) i.setXYZ(d, 0, 0, 0);
      const s = new w(), n = new w(), r = new w(), a = new w(), o = new w(), h = new w(), c = new w(), u = new w();
      if (t) for (let d = 0, p = t.count; d < p; d += 3) {
        const f = t.getX(d + 0), m = t.getX(d + 1), g = t.getX(d + 2);
        s.fromBufferAttribute(e, f), n.fromBufferAttribute(e, m), r.fromBufferAttribute(e, g), c.subVectors(r, n), u.subVectors(s, n), c.cross(u), a.fromBufferAttribute(i, f), o.fromBufferAttribute(i, m), h.fromBufferAttribute(i, g), a.add(c), o.add(c), h.add(c), i.setXYZ(f, a.x, a.y, a.z), i.setXYZ(m, o.x, o.y, o.z), i.setXYZ(g, h.x, h.y, h.z);
      }
      else for (let d = 0, p = e.count; d < p; d += 3) s.fromBufferAttribute(e, d + 0), n.fromBufferAttribute(e, d + 1), r.fromBufferAttribute(e, d + 2), c.subVectors(r, n), u.subVectors(s, n), c.cross(u), i.setXYZ(d + 0, c.x, c.y, c.z), i.setXYZ(d + 1, c.x, c.y, c.z), i.setXYZ(d + 2, c.x, c.y, c.z);
      this.normalizeNormals(), i.needsUpdate = true;
    }
  }
  normalizeNormals() {
    const t = this.attributes.normal;
    for (let e = 0, i = t.count; e < i; e++) ut.fromBufferAttribute(t, e), ut.normalize(), t.setXYZ(e, ut.x, ut.y, ut.z);
  }
  toNonIndexed() {
    function t(a, o) {
      const h = a.array, c = a.itemSize, u = a.normalized, d = new h.constructor(o.length * c);
      let p = 0, f = 0;
      for (let m = 0, g = o.length; m < g; m++) {
        a.isInterleavedBufferAttribute ? p = o[m] * a.data.stride + a.offset : p = o[m] * c;
        for (let y = 0; y < c; y++) d[f++] = h[p++];
      }
      return new tt(d, c, u);
    }
    if (this.index === null) return N("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."), this;
    const e = new H(), i = this.index.array, s = this.attributes;
    for (const a in s) {
      const o = s[a], h = t(o, i);
      e.setAttribute(a, h);
    }
    const n = this.morphAttributes;
    for (const a in n) {
      const o = [], h = n[a];
      for (let c = 0, u = h.length; c < u; c++) {
        const d = h[c], p = t(d, i);
        o.push(p);
      }
      e.morphAttributes[a] = o;
    }
    e.morphTargetsRelative = this.morphTargetsRelative;
    const r = this.groups;
    for (let a = 0, o = r.length; a < o; a++) {
      const h = r[a];
      e.addGroup(h.start, h.count, h.materialIndex);
    }
    return e;
  }
  toJSON() {
    const t = { metadata: { version: 4.7, type: "BufferGeometry", generator: "BufferGeometry.toJSON" } };
    if (t.uuid = this.uuid, t.type = this.type, this.name !== "" && (t.name = this.name), Object.keys(this.userData).length > 0 && (t.userData = this.userData), this.parameters !== void 0) {
      const o = this.parameters;
      for (const h in o) o[h] !== void 0 && (t[h] = o[h]);
      return t;
    }
    t.data = { attributes: {} };
    const e = this.index;
    e !== null && (t.data.index = { type: e.array.constructor.name, array: Array.prototype.slice.call(e.array) });
    const i = this.attributes;
    for (const o in i) {
      const h = i[o];
      t.data.attributes[o] = h.toJSON(t.data);
    }
    const s = {};
    let n = false;
    for (const o in this.morphAttributes) {
      const h = this.morphAttributes[o], c = [];
      for (let u = 0, d = h.length; u < d; u++) {
        const p = h[u];
        c.push(p.toJSON(t.data));
      }
      c.length > 0 && (s[o] = c, n = true);
    }
    n && (t.data.morphAttributes = s, t.data.morphTargetsRelative = this.morphTargetsRelative);
    const r = this.groups;
    r.length > 0 && (t.data.groups = JSON.parse(JSON.stringify(r)));
    const a = this.boundingSphere;
    return a !== null && (t.data.boundingSphere = a.toJSON()), t;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    this.index = null, this.attributes = {}, this.morphAttributes = {}, this.groups = [], this.boundingBox = null, this.boundingSphere = null;
    const e = {};
    this.name = t.name;
    const i = t.index;
    i !== null && this.setIndex(i.clone());
    const s = t.attributes;
    for (const h in s) {
      const c = s[h];
      this.setAttribute(h, c.clone(e));
    }
    const n = t.morphAttributes;
    for (const h in n) {
      const c = [], u = n[h];
      for (let d = 0, p = u.length; d < p; d++) c.push(u[d].clone(e));
      this.morphAttributes[h] = c;
    }
    this.morphTargetsRelative = t.morphTargetsRelative;
    const r = t.groups;
    for (let h = 0, c = r.length; h < c; h++) {
      const u = r[h];
      this.addGroup(u.start, u.count, u.materialIndex);
    }
    const a = t.boundingBox;
    a !== null && (this.boundingBox = a.clone());
    const o = t.boundingSphere;
    return o !== null && (this.boundingSphere = o.clone()), this.drawRange.start = t.drawRange.start, this.drawRange.count = t.drawRange.count, this.userData = t.userData, this;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
}
class fr {
  constructor(t, e) {
    this.isInterleavedBuffer = true, this.array = t, this.stride = e, this.count = t !== void 0 ? t.length / e : 0, this.usage = Xs, this.updateRanges = [], this.version = 0, this.uuid = zt();
  }
  onUploadCallback() {
  }
  set needsUpdate(t) {
    t === true && this.version++;
  }
  setUsage(t) {
    return this.usage = t, this;
  }
  addUpdateRange(t, e) {
    this.updateRanges.push({ start: t, count: e });
  }
  clearUpdateRanges() {
    this.updateRanges.length = 0;
  }
  copy(t) {
    return this.array = new t.array.constructor(t.array), this.count = t.count, this.stride = t.stride, this.usage = t.usage, this;
  }
  copyAt(t, e, i) {
    t *= this.stride, i *= e.stride;
    for (let s = 0, n = this.stride; s < n; s++) this.array[t + s] = e.array[i + s];
    return this;
  }
  set(t, e = 0) {
    return this.array.set(t, e), this;
  }
  clone(t) {
    t.arrayBuffers === void 0 && (t.arrayBuffers = {}), this.array.buffer._uuid === void 0 && (this.array.buffer._uuid = zt()), t.arrayBuffers[this.array.buffer._uuid] === void 0 && (t.arrayBuffers[this.array.buffer._uuid] = this.array.slice(0).buffer);
    const e = new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]), i = new this.constructor(e, this.stride);
    return i.setUsage(this.usage), i;
  }
  onUpload(t) {
    return this.onUploadCallback = t, this;
  }
  toJSON(t) {
    return t.arrayBuffers === void 0 && (t.arrayBuffers = {}), this.array.buffer._uuid === void 0 && (this.array.buffer._uuid = zt()), t.arrayBuffers[this.array.buffer._uuid] === void 0 && (t.arrayBuffers[this.array.buffer._uuid] = Array.from(new Uint32Array(this.array.buffer))), { uuid: this.uuid, buffer: this.array.buffer._uuid, type: this.array.constructor.name, stride: this.stride };
  }
}
const yt = new w();
class wi {
  constructor(t, e, i, s = false) {
    this.isInterleavedBufferAttribute = true, this.name = "", this.data = t, this.itemSize = e, this.offset = i, this.normalized = s;
  }
  get count() {
    return this.data.count;
  }
  get array() {
    return this.data.array;
  }
  set needsUpdate(t) {
    this.data.needsUpdate = t;
  }
  applyMatrix4(t) {
    for (let e = 0, i = this.data.count; e < i; e++) yt.fromBufferAttribute(this, e), yt.applyMatrix4(t), this.setXYZ(e, yt.x, yt.y, yt.z);
    return this;
  }
  applyNormalMatrix(t) {
    for (let e = 0, i = this.count; e < i; e++) yt.fromBufferAttribute(this, e), yt.applyNormalMatrix(t), this.setXYZ(e, yt.x, yt.y, yt.z);
    return this;
  }
  transformDirection(t) {
    for (let e = 0, i = this.count; e < i; e++) yt.fromBufferAttribute(this, e), yt.transformDirection(t), this.setXYZ(e, yt.x, yt.y, yt.z);
    return this;
  }
  getComponent(t, e) {
    let i = this.array[t * this.data.stride + this.offset + e];
    return this.normalized && (i = gt(i, this.array)), i;
  }
  setComponent(t, e, i) {
    return this.normalized && (i = W(i, this.array)), this.data.array[t * this.data.stride + this.offset + e] = i, this;
  }
  setX(t, e) {
    return this.normalized && (e = W(e, this.array)), this.data.array[t * this.data.stride + this.offset] = e, this;
  }
  setY(t, e) {
    return this.normalized && (e = W(e, this.array)), this.data.array[t * this.data.stride + this.offset + 1] = e, this;
  }
  setZ(t, e) {
    return this.normalized && (e = W(e, this.array)), this.data.array[t * this.data.stride + this.offset + 2] = e, this;
  }
  setW(t, e) {
    return this.normalized && (e = W(e, this.array)), this.data.array[t * this.data.stride + this.offset + 3] = e, this;
  }
  getX(t) {
    let e = this.data.array[t * this.data.stride + this.offset];
    return this.normalized && (e = gt(e, this.array)), e;
  }
  getY(t) {
    let e = this.data.array[t * this.data.stride + this.offset + 1];
    return this.normalized && (e = gt(e, this.array)), e;
  }
  getZ(t) {
    let e = this.data.array[t * this.data.stride + this.offset + 2];
    return this.normalized && (e = gt(e, this.array)), e;
  }
  getW(t) {
    let e = this.data.array[t * this.data.stride + this.offset + 3];
    return this.normalized && (e = gt(e, this.array)), e;
  }
  setXY(t, e, i) {
    return t = t * this.data.stride + this.offset, this.normalized && (e = W(e, this.array), i = W(i, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this;
  }
  setXYZ(t, e, i, s) {
    return t = t * this.data.stride + this.offset, this.normalized && (e = W(e, this.array), i = W(i, this.array), s = W(s, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this.data.array[t + 2] = s, this;
  }
  setXYZW(t, e, i, s, n) {
    return t = t * this.data.stride + this.offset, this.normalized && (e = W(e, this.array), i = W(i, this.array), s = W(s, this.array), n = W(n, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this.data.array[t + 2] = s, this.data.array[t + 3] = n, this;
  }
  clone(t) {
    if (t === void 0) {
      ca("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");
      const e = [];
      for (let i = 0; i < this.count; i++) {
        const s = i * this.data.stride + this.offset;
        for (let n = 0; n < this.itemSize; n++) e.push(this.data.array[s + n]);
      }
      return new tt(new this.array.constructor(e), this.itemSize, this.normalized);
    } else return t.interleavedBuffers === void 0 && (t.interleavedBuffers = {}), t.interleavedBuffers[this.data.uuid] === void 0 && (t.interleavedBuffers[this.data.uuid] = this.data.clone(t)), new wi(t.interleavedBuffers[this.data.uuid], this.itemSize, this.offset, this.normalized);
  }
  toJSON(t) {
    if (t === void 0) {
      ca("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");
      const e = [];
      for (let i = 0; i < this.count; i++) {
        const s = i * this.data.stride + this.offset;
        for (let n = 0; n < this.itemSize; n++) e.push(this.data.array[s + n]);
      }
      return { itemSize: this.itemSize, type: this.array.constructor.name, array: e, normalized: this.normalized };
    } else return t.interleavedBuffers === void 0 && (t.interleavedBuffers = {}), t.interleavedBuffers[this.data.uuid] === void 0 && (t.interleavedBuffers[this.data.uuid] = this.data.toJSON(t)), { isInterleavedBufferAttribute: true, itemSize: this.itemSize, data: this.data.uuid, offset: this.offset, normalized: this.normalized };
  }
}
let ec = 0;
class bt extends Se {
  constructor() {
    super(), this.isMaterial = true, Object.defineProperty(this, "id", { value: ec++ }), this.uuid = zt(), this.name = "", this.type = "Material", this.blending = Xr, this.side = Yn, this.vertexColors = false, this.opacity = 1, this.transparent = false, this.alphaHash = false, this.blendSrc = Yr, this.blendDst = $r, this.blendEquation = Zr, this.blendSrcAlpha = null, this.blendDstAlpha = null, this.blendEquationAlpha = null, this.blendColor = new U(0, 0, 0), this.blendAlpha = 0, this.depthFunc = qs, this.depthTest = true, this.depthWrite = true, this.stencilWriteMask = 255, this.stencilFunc = ha, this.stencilRef = 0, this.stencilFuncMask = 255, this.stencilFail = Je, this.stencilZFail = Je, this.stencilZPass = Je, this.stencilWrite = false, this.clippingPlanes = null, this.clipIntersection = false, this.clipShadows = false, this.shadowSide = null, this.colorWrite = true, this.precision = null, this.polygonOffset = false, this.polygonOffsetFactor = 0, this.polygonOffsetUnits = 0, this.dithering = false, this.alphaToCoverage = false, this.premultipliedAlpha = false, this.forceSinglePass = false, this.allowOverride = true, this.visible = true, this.toneMapped = true, this.userData = {}, this.version = 0, this._alphaTest = 0;
  }
  get alphaTest() {
    return this._alphaTest;
  }
  set alphaTest(t) {
    this._alphaTest > 0 != t > 0 && this.version++, this._alphaTest = t;
  }
  onBeforeRender() {
  }
  onBeforeCompile() {
  }
  customProgramCacheKey() {
    return this.onBeforeCompile.toString();
  }
  setValues(t) {
    if (t !== void 0) for (const e in t) {
      const i = t[e];
      if (i === void 0) {
        N(`Material: parameter '${e}' has value of undefined.`);
        continue;
      }
      const s = this[e];
      if (s === void 0) {
        N(`Material: '${e}' is not a property of THREE.${this.type}.`);
        continue;
      }
      s && s.isColor ? s.set(i) : s && s.isVector3 && i && i.isVector3 ? s.copy(i) : this[e] = i;
    }
  }
  toJSON(t) {
    const e = t === void 0 || typeof t == "string";
    e && (t = { textures: {}, images: {} });
    const i = { metadata: { version: 4.7, type: "Material", generator: "Material.toJSON" } };
    i.uuid = this.uuid, i.type = this.type, this.name !== "" && (i.name = this.name), this.color && this.color.isColor && (i.color = this.color.getHex()), this.roughness !== void 0 && (i.roughness = this.roughness), this.metalness !== void 0 && (i.metalness = this.metalness), this.sheen !== void 0 && (i.sheen = this.sheen), this.sheenColor && this.sheenColor.isColor && (i.sheenColor = this.sheenColor.getHex()), this.sheenRoughness !== void 0 && (i.sheenRoughness = this.sheenRoughness), this.emissive && this.emissive.isColor && (i.emissive = this.emissive.getHex()), this.emissiveIntensity !== void 0 && this.emissiveIntensity !== 1 && (i.emissiveIntensity = this.emissiveIntensity), this.specular && this.specular.isColor && (i.specular = this.specular.getHex()), this.specularIntensity !== void 0 && (i.specularIntensity = this.specularIntensity), this.specularColor && this.specularColor.isColor && (i.specularColor = this.specularColor.getHex()), this.shininess !== void 0 && (i.shininess = this.shininess), this.clearcoat !== void 0 && (i.clearcoat = this.clearcoat), this.clearcoatRoughness !== void 0 && (i.clearcoatRoughness = this.clearcoatRoughness), this.clearcoatMap && this.clearcoatMap.isTexture && (i.clearcoatMap = this.clearcoatMap.toJSON(t).uuid), this.clearcoatRoughnessMap && this.clearcoatRoughnessMap.isTexture && (i.clearcoatRoughnessMap = this.clearcoatRoughnessMap.toJSON(t).uuid), this.clearcoatNormalMap && this.clearcoatNormalMap.isTexture && (i.clearcoatNormalMap = this.clearcoatNormalMap.toJSON(t).uuid, i.clearcoatNormalScale = this.clearcoatNormalScale.toArray()), this.sheenColorMap && this.sheenColorMap.isTexture && (i.sheenColorMap = this.sheenColorMap.toJSON(t).uuid), this.sheenRoughnessMap && this.sheenRoughnessMap.isTexture && (i.sheenRoughnessMap = this.sheenRoughnessMap.toJSON(t).uuid), this.dispersion !== void 0 && (i.dispersion = this.dispersion), this.iridescence !== void 0 && (i.iridescence = this.iridescence), this.iridescenceIOR !== void 0 && (i.iridescenceIOR = this.iridescenceIOR), this.iridescenceThicknessRange !== void 0 && (i.iridescenceThicknessRange = this.iridescenceThicknessRange), this.iridescenceMap && this.iridescenceMap.isTexture && (i.iridescenceMap = this.iridescenceMap.toJSON(t).uuid), this.iridescenceThicknessMap && this.iridescenceThicknessMap.isTexture && (i.iridescenceThicknessMap = this.iridescenceThicknessMap.toJSON(t).uuid), this.anisotropy !== void 0 && (i.anisotropy = this.anisotropy), this.anisotropyRotation !== void 0 && (i.anisotropyRotation = this.anisotropyRotation), this.anisotropyMap && this.anisotropyMap.isTexture && (i.anisotropyMap = this.anisotropyMap.toJSON(t).uuid), this.map && this.map.isTexture && (i.map = this.map.toJSON(t).uuid), this.matcap && this.matcap.isTexture && (i.matcap = this.matcap.toJSON(t).uuid), this.alphaMap && this.alphaMap.isTexture && (i.alphaMap = this.alphaMap.toJSON(t).uuid), this.lightMap && this.lightMap.isTexture && (i.lightMap = this.lightMap.toJSON(t).uuid, i.lightMapIntensity = this.lightMapIntensity), this.aoMap && this.aoMap.isTexture && (i.aoMap = this.aoMap.toJSON(t).uuid, i.aoMapIntensity = this.aoMapIntensity), this.bumpMap && this.bumpMap.isTexture && (i.bumpMap = this.bumpMap.toJSON(t).uuid, i.bumpScale = this.bumpScale), this.normalMap && this.normalMap.isTexture && (i.normalMap = this.normalMap.toJSON(t).uuid, i.normalMapType = this.normalMapType, i.normalScale = this.normalScale.toArray()), this.displacementMap && this.displacementMap.isTexture && (i.displacementMap = this.displacementMap.toJSON(t).uuid, i.displacementScale = this.displacementScale, i.displacementBias = this.displacementBias), this.roughnessMap && this.roughnessMap.isTexture && (i.roughnessMap = this.roughnessMap.toJSON(t).uuid), this.metalnessMap && this.metalnessMap.isTexture && (i.metalnessMap = this.metalnessMap.toJSON(t).uuid), this.emissiveMap && this.emissiveMap.isTexture && (i.emissiveMap = this.emissiveMap.toJSON(t).uuid), this.specularMap && this.specularMap.isTexture && (i.specularMap = this.specularMap.toJSON(t).uuid), this.specularIntensityMap && this.specularIntensityMap.isTexture && (i.specularIntensityMap = this.specularIntensityMap.toJSON(t).uuid), this.specularColorMap && this.specularColorMap.isTexture && (i.specularColorMap = this.specularColorMap.toJSON(t).uuid), this.envMap && this.envMap.isTexture && (i.envMap = this.envMap.toJSON(t).uuid, this.combine !== void 0 && (i.combine = this.combine)), this.envMapRotation !== void 0 && (i.envMapRotation = this.envMapRotation.toArray()), this.envMapIntensity !== void 0 && (i.envMapIntensity = this.envMapIntensity), this.reflectivity !== void 0 && (i.reflectivity = this.reflectivity), this.refractionRatio !== void 0 && (i.refractionRatio = this.refractionRatio), this.gradientMap && this.gradientMap.isTexture && (i.gradientMap = this.gradientMap.toJSON(t).uuid), this.transmission !== void 0 && (i.transmission = this.transmission), this.transmissionMap && this.transmissionMap.isTexture && (i.transmissionMap = this.transmissionMap.toJSON(t).uuid), this.thickness !== void 0 && (i.thickness = this.thickness), this.thicknessMap && this.thicknessMap.isTexture && (i.thicknessMap = this.thicknessMap.toJSON(t).uuid), this.attenuationDistance !== void 0 && this.attenuationDistance !== 1 / 0 && (i.attenuationDistance = this.attenuationDistance), this.attenuationColor !== void 0 && (i.attenuationColor = this.attenuationColor.getHex()), this.size !== void 0 && (i.size = this.size), this.shadowSide !== null && (i.shadowSide = this.shadowSide), this.sizeAttenuation !== void 0 && (i.sizeAttenuation = this.sizeAttenuation), this.blending !== Xr && (i.blending = this.blending), this.side !== Yn && (i.side = this.side), this.vertexColors === true && (i.vertexColors = true), this.opacity < 1 && (i.opacity = this.opacity), this.transparent === true && (i.transparent = true), this.blendSrc !== Yr && (i.blendSrc = this.blendSrc), this.blendDst !== $r && (i.blendDst = this.blendDst), this.blendEquation !== Zr && (i.blendEquation = this.blendEquation), this.blendSrcAlpha !== null && (i.blendSrcAlpha = this.blendSrcAlpha), this.blendDstAlpha !== null && (i.blendDstAlpha = this.blendDstAlpha), this.blendEquationAlpha !== null && (i.blendEquationAlpha = this.blendEquationAlpha), this.blendColor && this.blendColor.isColor && (i.blendColor = this.blendColor.getHex()), this.blendAlpha !== 0 && (i.blendAlpha = this.blendAlpha), this.depthFunc !== qs && (i.depthFunc = this.depthFunc), this.depthTest === false && (i.depthTest = this.depthTest), this.depthWrite === false && (i.depthWrite = this.depthWrite), this.colorWrite === false && (i.colorWrite = this.colorWrite), this.stencilWriteMask !== 255 && (i.stencilWriteMask = this.stencilWriteMask), this.stencilFunc !== ha && (i.stencilFunc = this.stencilFunc), this.stencilRef !== 0 && (i.stencilRef = this.stencilRef), this.stencilFuncMask !== 255 && (i.stencilFuncMask = this.stencilFuncMask), this.stencilFail !== Je && (i.stencilFail = this.stencilFail), this.stencilZFail !== Je && (i.stencilZFail = this.stencilZFail), this.stencilZPass !== Je && (i.stencilZPass = this.stencilZPass), this.stencilWrite === true && (i.stencilWrite = this.stencilWrite), this.rotation !== void 0 && this.rotation !== 0 && (i.rotation = this.rotation), this.polygonOffset === true && (i.polygonOffset = true), this.polygonOffsetFactor !== 0 && (i.polygonOffsetFactor = this.polygonOffsetFactor), this.polygonOffsetUnits !== 0 && (i.polygonOffsetUnits = this.polygonOffsetUnits), this.linewidth !== void 0 && this.linewidth !== 1 && (i.linewidth = this.linewidth), this.dashSize !== void 0 && (i.dashSize = this.dashSize), this.gapSize !== void 0 && (i.gapSize = this.gapSize), this.scale !== void 0 && (i.scale = this.scale), this.dithering === true && (i.dithering = true), this.alphaTest > 0 && (i.alphaTest = this.alphaTest), this.alphaHash === true && (i.alphaHash = true), this.alphaToCoverage === true && (i.alphaToCoverage = true), this.premultipliedAlpha === true && (i.premultipliedAlpha = true), this.forceSinglePass === true && (i.forceSinglePass = true), this.allowOverride === false && (i.allowOverride = false), this.wireframe === true && (i.wireframe = true), this.wireframeLinewidth > 1 && (i.wireframeLinewidth = this.wireframeLinewidth), this.wireframeLinecap !== "round" && (i.wireframeLinecap = this.wireframeLinecap), this.wireframeLinejoin !== "round" && (i.wireframeLinejoin = this.wireframeLinejoin), this.flatShading === true && (i.flatShading = true), this.visible === false && (i.visible = false), this.toneMapped === false && (i.toneMapped = false), this.fog === false && (i.fog = false), Object.keys(this.userData).length > 0 && (i.userData = this.userData);
    function s(n) {
      const r = [];
      for (const a in n) {
        const o = n[a];
        delete o.metadata, r.push(o);
      }
      return r;
    }
    if (e) {
      const n = s(t.textures), r = s(t.images);
      n.length > 0 && (i.textures = n), r.length > 0 && (i.images = r);
    }
    return i;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    this.name = t.name, this.blending = t.blending, this.side = t.side, this.vertexColors = t.vertexColors, this.opacity = t.opacity, this.transparent = t.transparent, this.blendSrc = t.blendSrc, this.blendDst = t.blendDst, this.blendEquation = t.blendEquation, this.blendSrcAlpha = t.blendSrcAlpha, this.blendDstAlpha = t.blendDstAlpha, this.blendEquationAlpha = t.blendEquationAlpha, this.blendColor.copy(t.blendColor), this.blendAlpha = t.blendAlpha, this.depthFunc = t.depthFunc, this.depthTest = t.depthTest, this.depthWrite = t.depthWrite, this.stencilWriteMask = t.stencilWriteMask, this.stencilFunc = t.stencilFunc, this.stencilRef = t.stencilRef, this.stencilFuncMask = t.stencilFuncMask, this.stencilFail = t.stencilFail, this.stencilZFail = t.stencilZFail, this.stencilZPass = t.stencilZPass, this.stencilWrite = t.stencilWrite;
    const e = t.clippingPlanes;
    let i = null;
    if (e !== null) {
      const s = e.length;
      i = new Array(s);
      for (let n = 0; n !== s; ++n) i[n] = e[n].clone();
    }
    return this.clippingPlanes = i, this.clipIntersection = t.clipIntersection, this.clipShadows = t.clipShadows, this.shadowSide = t.shadowSide, this.colorWrite = t.colorWrite, this.precision = t.precision, this.polygonOffset = t.polygonOffset, this.polygonOffsetFactor = t.polygonOffsetFactor, this.polygonOffsetUnits = t.polygonOffsetUnits, this.dithering = t.dithering, this.alphaTest = t.alphaTest, this.alphaHash = t.alphaHash, this.alphaToCoverage = t.alphaToCoverage, this.premultipliedAlpha = t.premultipliedAlpha, this.forceSinglePass = t.forceSinglePass, this.allowOverride = t.allowOverride, this.visible = t.visible, this.toneMapped = t.toneMapped, this.userData = JSON.parse(JSON.stringify(t.userData)), this;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
  set needsUpdate(t) {
    t === true && this.version++;
  }
}
class Fo extends bt {
  constructor(t) {
    super(), this.isSpriteMaterial = true, this.type = "SpriteMaterial", this.color = new U(16777215), this.map = null, this.alphaMap = null, this.rotation = 0, this.sizeAttenuation = true, this.transparent = true, this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.alphaMap = t.alphaMap, this.rotation = t.rotation, this.sizeAttenuation = t.sizeAttenuation, this.fog = t.fog, this;
  }
}
let si;
const ki = new w(), ni = new w(), ri = new w(), ai = new I(), Pi = new I(), ko = new G(), os = new w(), Ri = new w(), hs = new w(), Sa = new I(), In = new I(), Aa = new I();
class ic extends $ {
  constructor(t = new Fo()) {
    if (super(), this.isSprite = true, this.type = "Sprite", si === void 0) {
      si = new H();
      const e = new Float32Array([-0.5, -0.5, 0, 0, 0, 0.5, -0.5, 0, 1, 0, 0.5, 0.5, 0, 1, 1, -0.5, 0.5, 0, 0, 1]), i = new fr(e, 5);
      si.setIndex([0, 1, 2, 0, 2, 3]), si.setAttribute("position", new wi(i, 3, 0, false)), si.setAttribute("uv", new wi(i, 2, 3, false));
    }
    this.geometry = si, this.material = t, this.center = new I(0.5, 0.5), this.count = 1;
  }
  raycast(t, e) {
    t.camera === null && Y('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'), ni.setFromMatrixScale(this.matrixWorld), ko.copy(t.camera.matrixWorld), this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse, this.matrixWorld), ri.setFromMatrixPosition(this.modelViewMatrix), t.camera.isPerspectiveCamera && this.material.sizeAttenuation === false && ni.multiplyScalar(-ri.z);
    const i = this.material.rotation;
    let s, n;
    i !== 0 && (n = Math.cos(i), s = Math.sin(i));
    const r = this.center;
    ls(os.set(-0.5, -0.5, 0), ri, r, ni, s, n), ls(Ri.set(0.5, -0.5, 0), ri, r, ni, s, n), ls(hs.set(0.5, 0.5, 0), ri, r, ni, s, n), Sa.set(0, 0), In.set(1, 0), Aa.set(1, 1);
    let a = t.ray.intersectTriangle(os, Ri, hs, false, ki);
    if (a === null && (ls(Ri.set(-0.5, 0.5, 0), ri, r, ni, s, n), In.set(0, 1), a = t.ray.intersectTriangle(os, hs, Ri, false, ki), a === null)) return;
    const o = t.ray.origin.distanceTo(ki);
    o < t.near || o > t.far || e.push({ distance: o, point: ki.clone(), uv: It.getInterpolation(ki, os, Ri, hs, Sa, In, Aa, new I()), face: null, object: this });
  }
  copy(t, e) {
    return super.copy(t, e), t.center !== void 0 && this.center.copy(t.center), this.material = t.material, this;
  }
}
function ls(l, t, e, i, s, n) {
  ai.subVectors(l, e).addScalar(0.5).multiply(i), s !== void 0 ? (Pi.x = n * ai.x - s * ai.y, Pi.y = s * ai.x + n * ai.y) : Pi.copy(ai), l.copy(t), l.x += Pi.x, l.y += Pi.y, l.applyMatrix4(ko);
}
const cs = new w(), Ta = new w();
class sc extends $ {
  constructor() {
    super(), this.isLOD = true, this._currentLevel = 0, this.type = "LOD", Object.defineProperties(this, { levels: { enumerable: true, value: [] } }), this.autoUpdate = true;
  }
  copy(t) {
    super.copy(t, false);
    const e = t.levels;
    for (let i = 0, s = e.length; i < s; i++) {
      const n = e[i];
      this.addLevel(n.object.clone(), n.distance, n.hysteresis);
    }
    return this.autoUpdate = t.autoUpdate, this;
  }
  addLevel(t, e = 0, i = 0) {
    e = Math.abs(e);
    const s = this.levels;
    let n;
    for (n = 0; n < s.length && !(e < s[n].distance); n++) ;
    return s.splice(n, 0, { distance: e, hysteresis: i, object: t }), this.add(t), this;
  }
  removeLevel(t) {
    const e = this.levels;
    for (let i = 0; i < e.length; i++) if (e[i].distance === t) {
      const s = e.splice(i, 1);
      return this.remove(s[0].object), true;
    }
    return false;
  }
  getCurrentLevel() {
    return this._currentLevel;
  }
  getObjectForDistance(t) {
    const e = this.levels;
    if (e.length > 0) {
      let i, s;
      for (i = 1, s = e.length; i < s; i++) {
        let n = e[i].distance;
        if (e[i].object.visible && (n -= n * e[i].hysteresis), t < n) break;
      }
      return e[i - 1].object;
    }
    return null;
  }
  raycast(t, e) {
    if (this.levels.length > 0) {
      cs.setFromMatrixPosition(this.matrixWorld);
      const s = t.ray.origin.distanceTo(cs);
      this.getObjectForDistance(s).raycast(t, e);
    }
  }
  update(t) {
    const e = this.levels;
    if (e.length > 1) {
      cs.setFromMatrixPosition(t.matrixWorld), Ta.setFromMatrixPosition(this.matrixWorld);
      const i = cs.distanceTo(Ta) / t.zoom;
      e[0].object.visible = true;
      let s, n;
      for (s = 1, n = e.length; s < n; s++) {
        let r = e[s].distance;
        if (e[s].object.visible && (r -= r * e[s].hysteresis), i >= r) e[s - 1].object.visible = false, e[s].object.visible = true;
        else break;
      }
      for (this._currentLevel = s - 1; s < n; s++) e[s].object.visible = false;
    }
  }
  toJSON(t) {
    const e = super.toJSON(t);
    this.autoUpdate === false && (e.object.autoUpdate = false), e.object.levels = [];
    const i = this.levels;
    for (let s = 0, n = i.length; s < n; s++) {
      const r = i[s];
      e.object.levels.push({ object: r.object.uuid, distance: r.distance, hysteresis: r.hysteresis });
    }
    return e;
  }
}
const he = new w(), zn = new w(), us = new w(), be = new w(), Bn = new w(), ds = new w(), Fn = new w();
class ji {
  constructor(t = new w(), e = new w(0, 0, -1)) {
    this.origin = t, this.direction = e;
  }
  set(t, e) {
    return this.origin.copy(t), this.direction.copy(e), this;
  }
  copy(t) {
    return this.origin.copy(t.origin), this.direction.copy(t.direction), this;
  }
  at(t, e) {
    return e.copy(this.origin).addScaledVector(this.direction, t);
  }
  lookAt(t) {
    return this.direction.copy(t).sub(this.origin).normalize(), this;
  }
  recast(t) {
    return this.origin.copy(this.at(t, he)), this;
  }
  closestPointToPoint(t, e) {
    e.subVectors(t, this.origin);
    const i = e.dot(this.direction);
    return i < 0 ? e.copy(this.origin) : e.copy(this.origin).addScaledVector(this.direction, i);
  }
  distanceToPoint(t) {
    return Math.sqrt(this.distanceSqToPoint(t));
  }
  distanceSqToPoint(t) {
    const e = he.subVectors(t, this.origin).dot(this.direction);
    return e < 0 ? this.origin.distanceToSquared(t) : (he.copy(this.origin).addScaledVector(this.direction, e), he.distanceToSquared(t));
  }
  distanceSqToSegment(t, e, i, s) {
    zn.copy(t).add(e).multiplyScalar(0.5), us.copy(e).sub(t).normalize(), be.copy(this.origin).sub(zn);
    const n = t.distanceTo(e) * 0.5, r = -this.direction.dot(us), a = be.dot(this.direction), o = -be.dot(us), h = be.lengthSq(), c = Math.abs(1 - r * r);
    let u, d, p, f;
    if (c > 0) if (u = r * o - a, d = r * a - o, f = n * c, u >= 0) if (d >= -f) if (d <= f) {
      const m = 1 / c;
      u *= m, d *= m, p = u * (u + r * d + 2 * a) + d * (r * u + d + 2 * o) + h;
    } else d = n, u = Math.max(0, -(r * d + a)), p = -u * u + d * (d + 2 * o) + h;
    else d = -n, u = Math.max(0, -(r * d + a)), p = -u * u + d * (d + 2 * o) + h;
    else d <= -f ? (u = Math.max(0, -(-r * n + a)), d = u > 0 ? -n : Math.min(Math.max(-n, -o), n), p = -u * u + d * (d + 2 * o) + h) : d <= f ? (u = 0, d = Math.min(Math.max(-n, -o), n), p = d * (d + 2 * o) + h) : (u = Math.max(0, -(r * n + a)), d = u > 0 ? n : Math.min(Math.max(-n, -o), n), p = -u * u + d * (d + 2 * o) + h);
    else d = r > 0 ? -n : n, u = Math.max(0, -(r * d + a)), p = -u * u + d * (d + 2 * o) + h;
    return i && i.copy(this.origin).addScaledVector(this.direction, u), s && s.copy(zn).addScaledVector(us, d), p;
  }
  intersectSphere(t, e) {
    he.subVectors(t.center, this.origin);
    const i = he.dot(this.direction), s = he.dot(he) - i * i, n = t.radius * t.radius;
    if (s > n) return null;
    const r = Math.sqrt(n - s), a = i - r, o = i + r;
    return o < 0 ? null : a < 0 ? this.at(o, e) : this.at(a, e);
  }
  intersectsSphere(t) {
    return t.radius < 0 ? false : this.distanceSqToPoint(t.center) <= t.radius * t.radius;
  }
  distanceToPlane(t) {
    const e = t.normal.dot(this.direction);
    if (e === 0) return t.distanceToPoint(this.origin) === 0 ? 0 : null;
    const i = -(this.origin.dot(t.normal) + t.constant) / e;
    return i >= 0 ? i : null;
  }
  intersectPlane(t, e) {
    const i = this.distanceToPlane(t);
    return i === null ? null : this.at(i, e);
  }
  intersectsPlane(t) {
    const e = t.distanceToPoint(this.origin);
    return e === 0 || t.normal.dot(this.direction) * e < 0;
  }
  intersectBox(t, e) {
    let i, s, n, r, a, o;
    const h = 1 / this.direction.x, c = 1 / this.direction.y, u = 1 / this.direction.z, d = this.origin;
    return h >= 0 ? (i = (t.min.x - d.x) * h, s = (t.max.x - d.x) * h) : (i = (t.max.x - d.x) * h, s = (t.min.x - d.x) * h), c >= 0 ? (n = (t.min.y - d.y) * c, r = (t.max.y - d.y) * c) : (n = (t.max.y - d.y) * c, r = (t.min.y - d.y) * c), i > r || n > s || ((n > i || isNaN(i)) && (i = n), (r < s || isNaN(s)) && (s = r), u >= 0 ? (a = (t.min.z - d.z) * u, o = (t.max.z - d.z) * u) : (a = (t.max.z - d.z) * u, o = (t.min.z - d.z) * u), i > o || a > s) || ((a > i || i !== i) && (i = a), (o < s || s !== s) && (s = o), s < 0) ? null : this.at(i >= 0 ? i : s, e);
  }
  intersectsBox(t) {
    return this.intersectBox(t, he) !== null;
  }
  intersectTriangle(t, e, i, s, n) {
    Bn.subVectors(e, t), ds.subVectors(i, t), Fn.crossVectors(Bn, ds);
    let r = this.direction.dot(Fn), a;
    if (r > 0) {
      if (s) return null;
      a = 1;
    } else if (r < 0) a = -1, r = -r;
    else return null;
    be.subVectors(this.origin, t);
    const o = a * this.direction.dot(ds.crossVectors(be, ds));
    if (o < 0) return null;
    const h = a * this.direction.dot(Bn.cross(be));
    if (h < 0 || o + h > r) return null;
    const c = -a * be.dot(Fn);
    return c < 0 ? null : this.at(c / r, n);
  }
  applyMatrix4(t) {
    return this.origin.applyMatrix4(t), this.direction.transformDirection(t), this;
  }
  equals(t) {
    return t.origin.equals(this.origin) && t.direction.equals(this.direction);
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
class Si extends bt {
  constructor(t) {
    super(), this.isMeshBasicMaterial = true, this.type = "MeshBasicMaterial", this.color = new U(16777215), this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new jt(), this.combine = ar, this.reflectivity = 1, this.refractionRatio = 0.98, this.wireframe = false, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.combine = t.combine, this.reflectivity = t.reflectivity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.fog = t.fog, this;
  }
}
const Ca = new G(), Ie = new ji(), ps = new mt(), Ia = new w(), fs = new w(), ms = new w(), ys = new w(), kn = new w(), gs = new w(), za = new w(), xs = new w();
class Kt extends $ {
  constructor(t = new H(), e = new Si()) {
    super(), this.isMesh = true, this.type = "Mesh", this.geometry = t, this.material = e, this.morphTargetDictionary = void 0, this.morphTargetInfluences = void 0, this.count = 1, this.updateMorphTargets();
  }
  copy(t, e) {
    return super.copy(t, e), t.morphTargetInfluences !== void 0 && (this.morphTargetInfluences = t.morphTargetInfluences.slice()), t.morphTargetDictionary !== void 0 && (this.morphTargetDictionary = Object.assign({}, t.morphTargetDictionary)), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
  }
  updateMorphTargets() {
    const e = this.geometry.morphAttributes, i = Object.keys(e);
    if (i.length > 0) {
      const s = e[i[0]];
      if (s !== void 0) {
        this.morphTargetInfluences = [], this.morphTargetDictionary = {};
        for (let n = 0, r = s.length; n < r; n++) {
          const a = s[n].name || String(n);
          this.morphTargetInfluences.push(0), this.morphTargetDictionary[a] = n;
        }
      }
    }
  }
  getVertexPosition(t, e) {
    const i = this.geometry, s = i.attributes.position, n = i.morphAttributes.position, r = i.morphTargetsRelative;
    e.fromBufferAttribute(s, t);
    const a = this.morphTargetInfluences;
    if (n && a) {
      gs.set(0, 0, 0);
      for (let o = 0, h = n.length; o < h; o++) {
        const c = a[o], u = n[o];
        c !== 0 && (kn.fromBufferAttribute(u, t), r ? gs.addScaledVector(kn, c) : gs.addScaledVector(kn.sub(e), c));
      }
      e.add(gs);
    }
    return e;
  }
  raycast(t, e) {
    const i = this.geometry, s = this.material, n = this.matrixWorld;
    s !== void 0 && (i.boundingSphere === null && i.computeBoundingSphere(), ps.copy(i.boundingSphere), ps.applyMatrix4(n), Ie.copy(t.ray).recast(t.near), !(ps.containsPoint(Ie.origin) === false && (Ie.intersectSphere(ps, Ia) === null || Ie.origin.distanceToSquared(Ia) > (t.far - t.near) ** 2)) && (Ca.copy(n).invert(), Ie.copy(t.ray).applyMatrix4(Ca), !(i.boundingBox !== null && Ie.intersectsBox(i.boundingBox) === false) && this._computeIntersections(t, e, Ie)));
  }
  _computeIntersections(t, e, i) {
    let s;
    const n = this.geometry, r = this.material, a = n.index, o = n.attributes.position, h = n.attributes.uv, c = n.attributes.uv1, u = n.attributes.normal, d = n.groups, p = n.drawRange;
    if (a !== null) if (Array.isArray(r)) for (let f = 0, m = d.length; f < m; f++) {
      const g = d[f], y = r[g.materialIndex], x = Math.max(g.start, p.start), b = Math.min(a.count, Math.min(g.start + g.count, p.start + p.count));
      for (let M = x, _ = b; M < _; M += 3) {
        const v = a.getX(M), A = a.getX(M + 1), S = a.getX(M + 2);
        s = bs(this, y, t, i, h, c, u, v, A, S), s && (s.faceIndex = Math.floor(M / 3), s.face.materialIndex = g.materialIndex, e.push(s));
      }
    }
    else {
      const f = Math.max(0, p.start), m = Math.min(a.count, p.start + p.count);
      for (let g = f, y = m; g < y; g += 3) {
        const x = a.getX(g), b = a.getX(g + 1), M = a.getX(g + 2);
        s = bs(this, r, t, i, h, c, u, x, b, M), s && (s.faceIndex = Math.floor(g / 3), e.push(s));
      }
    }
    else if (o !== void 0) if (Array.isArray(r)) for (let f = 0, m = d.length; f < m; f++) {
      const g = d[f], y = r[g.materialIndex], x = Math.max(g.start, p.start), b = Math.min(o.count, Math.min(g.start + g.count, p.start + p.count));
      for (let M = x, _ = b; M < _; M += 3) {
        const v = M, A = M + 1, S = M + 2;
        s = bs(this, y, t, i, h, c, u, v, A, S), s && (s.faceIndex = Math.floor(M / 3), s.face.materialIndex = g.materialIndex, e.push(s));
      }
    }
    else {
      const f = Math.max(0, p.start), m = Math.min(o.count, p.start + p.count);
      for (let g = f, y = m; g < y; g += 3) {
        const x = g, b = g + 1, M = g + 2;
        s = bs(this, r, t, i, h, c, u, x, b, M), s && (s.faceIndex = Math.floor(g / 3), e.push(s));
      }
    }
  }
}
function nc(l, t, e, i, s, n, r, a) {
  let o;
  if (t.side === hh ? o = i.intersectTriangle(r, n, s, true, a) : o = i.intersectTriangle(s, n, r, t.side === Yn, a), o === null) return null;
  xs.copy(a), xs.applyMatrix4(l.matrixWorld);
  const h = e.ray.origin.distanceTo(xs);
  return h < e.near || h > e.far ? null : { distance: h, point: xs.clone(), object: l };
}
function bs(l, t, e, i, s, n, r, a, o, h) {
  l.getVertexPosition(a, fs), l.getVertexPosition(o, ms), l.getVertexPosition(h, ys);
  const c = nc(l, t, e, i, fs, ms, ys, za);
  if (c) {
    const u = new w();
    It.getBarycoord(za, fs, ms, ys, u), s && (c.uv = It.getInterpolatedAttribute(s, a, o, h, u, new I())), n && (c.uv1 = It.getInterpolatedAttribute(n, a, o, h, u, new I())), r && (c.normal = It.getInterpolatedAttribute(r, a, o, h, u, new w()), c.normal.dot(i.direction) > 0 && c.normal.multiplyScalar(-1));
    const d = { a, b: o, c: h, normal: new w(), materialIndex: 0 };
    It.getNormal(fs, ms, ys, d.normal), c.face = d, c.barycoord = u;
  }
  return c;
}
const Ba = new w(), Fa = new Nt(), ka = new Nt(), rc = new w(), Pa = new G(), Ms = new w(), Pn = new mt(), Ra = new G(), Rn = new ji();
class ac extends Kt {
  constructor(t, e) {
    super(t, e), this.isSkinnedMesh = true, this.type = "SkinnedMesh", this.bindMode = na, this.bindMatrix = new G(), this.bindMatrixInverse = new G(), this.boundingBox = null, this.boundingSphere = null;
  }
  computeBoundingBox() {
    const t = this.geometry;
    this.boundingBox === null && (this.boundingBox = new xt()), this.boundingBox.makeEmpty();
    const e = t.getAttribute("position");
    for (let i = 0; i < e.count; i++) this.getVertexPosition(i, Ms), this.boundingBox.expandByPoint(Ms);
  }
  computeBoundingSphere() {
    const t = this.geometry;
    this.boundingSphere === null && (this.boundingSphere = new mt()), this.boundingSphere.makeEmpty();
    const e = t.getAttribute("position");
    for (let i = 0; i < e.count; i++) this.getVertexPosition(i, Ms), this.boundingSphere.expandByPoint(Ms);
  }
  copy(t, e) {
    return super.copy(t, e), this.bindMode = t.bindMode, this.bindMatrix.copy(t.bindMatrix), this.bindMatrixInverse.copy(t.bindMatrixInverse), this.skeleton = t.skeleton, t.boundingBox !== null && (this.boundingBox = t.boundingBox.clone()), t.boundingSphere !== null && (this.boundingSphere = t.boundingSphere.clone()), this;
  }
  raycast(t, e) {
    const i = this.material, s = this.matrixWorld;
    i !== void 0 && (this.boundingSphere === null && this.computeBoundingSphere(), Pn.copy(this.boundingSphere), Pn.applyMatrix4(s), t.ray.intersectsSphere(Pn) !== false && (Ra.copy(s).invert(), Rn.copy(t.ray).applyMatrix4(Ra), !(this.boundingBox !== null && Rn.intersectsBox(this.boundingBox) === false) && this._computeIntersections(t, e, Rn)));
  }
  getVertexPosition(t, e) {
    return super.getVertexPosition(t, e), this.applyBoneTransform(t, e), e;
  }
  bind(t, e) {
    this.skeleton = t, e === void 0 && (this.updateMatrixWorld(true), this.skeleton.calculateInverses(), e = this.matrixWorld), this.bindMatrix.copy(e), this.bindMatrixInverse.copy(e).invert();
  }
  pose() {
    this.skeleton.pose();
  }
  normalizeSkinWeights() {
    const t = new Nt(), e = this.geometry.attributes.skinWeight;
    for (let i = 0, s = e.count; i < s; i++) {
      t.fromBufferAttribute(e, i);
      const n = 1 / t.manhattanLength();
      n !== 1 / 0 ? t.multiplyScalar(n) : t.set(1, 0, 0, 0), e.setXYZW(i, t.x, t.y, t.z, t.w);
    }
  }
  updateMatrixWorld(t) {
    super.updateMatrixWorld(t), this.bindMode === na ? this.bindMatrixInverse.copy(this.matrixWorld).invert() : this.bindMode === lh ? this.bindMatrixInverse.copy(this.bindMatrix).invert() : N("SkinnedMesh: Unrecognized bindMode: " + this.bindMode);
  }
  applyBoneTransform(t, e) {
    const i = this.skeleton, s = this.geometry;
    Fa.fromBufferAttribute(s.attributes.skinIndex, t), ka.fromBufferAttribute(s.attributes.skinWeight, t), Ba.copy(e).applyMatrix4(this.bindMatrix), e.set(0, 0, 0);
    for (let n = 0; n < 4; n++) {
      const r = ka.getComponent(n);
      if (r !== 0) {
        const a = Fa.getComponent(n);
        Pa.multiplyMatrices(i.bones[a].matrixWorld, i.boneInverses[a]), e.addScaledVector(rc.copy(Ba).applyMatrix4(Pa), r);
      }
    }
    return e.applyMatrix4(this.bindMatrixInverse);
  }
}
class Po extends $ {
  constructor() {
    super(), this.isBone = true, this.type = "Bone";
  }
}
class pe extends lt {
  constructor(t = null, e = 1, i = 1, s, n, r, a, o, h = Bt, c = Bt, u, d) {
    super(null, r, a, o, h, c, s, n, u, d), this.isDataTexture = true, this.image = { data: t, width: e, height: i }, this.generateMipmaps = false, this.flipY = false, this.unpackAlignment = 1;
  }
}
const Oa = new G(), oc = new G();
class mr {
  constructor(t = [], e = []) {
    this.uuid = zt(), this.bones = t.slice(0), this.boneInverses = e, this.boneMatrices = null, this.previousBoneMatrices = null, this.boneTexture = null, this.init();
  }
  init() {
    const t = this.bones, e = this.boneInverses;
    if (this.boneMatrices = new Float32Array(t.length * 16), e.length === 0) this.calculateInverses();
    else if (t.length !== e.length) {
      N("Skeleton: Number of inverse bone matrices does not match amount of bones."), this.boneInverses = [];
      for (let i = 0, s = this.bones.length; i < s; i++) this.boneInverses.push(new G());
    }
  }
  calculateInverses() {
    this.boneInverses.length = 0;
    for (let t = 0, e = this.bones.length; t < e; t++) {
      const i = new G();
      this.bones[t] && i.copy(this.bones[t].matrixWorld).invert(), this.boneInverses.push(i);
    }
  }
  pose() {
    for (let t = 0, e = this.bones.length; t < e; t++) {
      const i = this.bones[t];
      i && i.matrixWorld.copy(this.boneInverses[t]).invert();
    }
    for (let t = 0, e = this.bones.length; t < e; t++) {
      const i = this.bones[t];
      i && (i.parent && i.parent.isBone ? (i.matrix.copy(i.parent.matrixWorld).invert(), i.matrix.multiply(i.matrixWorld)) : i.matrix.copy(i.matrixWorld), i.matrix.decompose(i.position, i.quaternion, i.scale));
    }
  }
  update() {
    const t = this.bones, e = this.boneInverses, i = this.boneMatrices, s = this.boneTexture;
    for (let n = 0, r = t.length; n < r; n++) {
      const a = t[n] ? t[n].matrixWorld : oc;
      Oa.multiplyMatrices(a, e[n]), Oa.toArray(i, n * 16);
    }
    s !== null && (s.needsUpdate = true);
  }
  clone() {
    return new mr(this.bones, this.boneInverses);
  }
  computeBoneTexture() {
    let t = Math.sqrt(this.bones.length * 4);
    t = Math.ceil(t / 4) * 4, t = Math.max(t, 4);
    const e = new Float32Array(t * t * 4);
    e.set(this.boneMatrices);
    const i = new pe(e, t, t, Hi, bi);
    return i.needsUpdate = true, this.boneMatrices = e, this.boneTexture = i, this;
  }
  getBoneByName(t) {
    for (let e = 0, i = this.bones.length; e < i; e++) {
      const s = this.bones[e];
      if (s.name === t) return s;
    }
  }
  dispose() {
    this.boneTexture !== null && (this.boneTexture.dispose(), this.boneTexture = null);
  }
  fromJSON(t, e) {
    this.uuid = t.uuid;
    for (let i = 0, s = t.bones.length; i < s; i++) {
      const n = t.bones[i];
      let r = e[n];
      r === void 0 && (N("Skeleton: No bone found with UUID:", n), r = new Po()), this.bones.push(r), this.boneInverses.push(new G().fromArray(t.boneInverses[i]));
    }
    return this.init(), this;
  }
  toJSON() {
    const t = { metadata: { version: 4.7, type: "Skeleton", generator: "Skeleton.toJSON" }, bones: [], boneInverses: [] };
    t.uuid = this.uuid;
    const e = this.bones, i = this.boneInverses;
    for (let s = 0, n = e.length; s < n; s++) {
      const r = e[s];
      t.bones.push(r.uuid);
      const a = i[s];
      t.boneInverses.push(a.toArray());
    }
    return t;
  }
}
class Xi extends tt {
  constructor(t, e, i, s = 1) {
    super(t, e, i), this.isInstancedBufferAttribute = true, this.meshPerAttribute = s;
  }
  copy(t) {
    return super.copy(t), this.meshPerAttribute = t.meshPerAttribute, this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.meshPerAttribute = this.meshPerAttribute, t.isInstancedBufferAttribute = true, t;
  }
}
const oi = new G(), Ea = new G(), ws = [], Na = new xt(), hc = new G(), Oi = new Kt(), Ei = new mt();
class lc extends Kt {
  constructor(t, e, i) {
    super(t, e), this.isInstancedMesh = true, this.instanceMatrix = new Xi(new Float32Array(i * 16), 16), this.previousInstanceMatrix = null, this.instanceColor = null, this.morphTexture = null, this.count = i, this.boundingBox = null, this.boundingSphere = null;
    for (let s = 0; s < i; s++) this.setMatrixAt(s, hc);
  }
  computeBoundingBox() {
    const t = this.geometry, e = this.count;
    this.boundingBox === null && (this.boundingBox = new xt()), t.boundingBox === null && t.computeBoundingBox(), this.boundingBox.makeEmpty();
    for (let i = 0; i < e; i++) this.getMatrixAt(i, oi), Na.copy(t.boundingBox).applyMatrix4(oi), this.boundingBox.union(Na);
  }
  computeBoundingSphere() {
    const t = this.geometry, e = this.count;
    this.boundingSphere === null && (this.boundingSphere = new mt()), t.boundingSphere === null && t.computeBoundingSphere(), this.boundingSphere.makeEmpty();
    for (let i = 0; i < e; i++) this.getMatrixAt(i, oi), Ei.copy(t.boundingSphere).applyMatrix4(oi), this.boundingSphere.union(Ei);
  }
  copy(t, e) {
    return super.copy(t, e), this.instanceMatrix.copy(t.instanceMatrix), t.previousInstanceMatrix !== null && (this.previousInstanceMatrix = t.previousInstanceMatrix.clone()), t.morphTexture !== null && (this.morphTexture = t.morphTexture.clone()), t.instanceColor !== null && (this.instanceColor = t.instanceColor.clone()), this.count = t.count, t.boundingBox !== null && (this.boundingBox = t.boundingBox.clone()), t.boundingSphere !== null && (this.boundingSphere = t.boundingSphere.clone()), this;
  }
  getColorAt(t, e) {
    e.fromArray(this.instanceColor.array, t * 3);
  }
  getMatrixAt(t, e) {
    e.fromArray(this.instanceMatrix.array, t * 16);
  }
  getMorphAt(t, e) {
    const i = e.morphTargetInfluences, s = this.morphTexture.source.data.data, n = i.length + 1, r = t * n + 1;
    for (let a = 0; a < i.length; a++) i[a] = s[r + a];
  }
  raycast(t, e) {
    const i = this.matrixWorld, s = this.count;
    if (Oi.geometry = this.geometry, Oi.material = this.material, Oi.material !== void 0 && (this.boundingSphere === null && this.computeBoundingSphere(), Ei.copy(this.boundingSphere), Ei.applyMatrix4(i), t.ray.intersectsSphere(Ei) !== false)) for (let n = 0; n < s; n++) {
      this.getMatrixAt(n, oi), Ea.multiplyMatrices(i, oi), Oi.matrixWorld = Ea, Oi.raycast(t, ws);
      for (let r = 0, a = ws.length; r < a; r++) {
        const o = ws[r];
        o.instanceId = n, o.object = this, e.push(o);
      }
      ws.length = 0;
    }
  }
  setColorAt(t, e) {
    this.instanceColor === null && (this.instanceColor = new Xi(new Float32Array(this.instanceMatrix.count * 3).fill(1), 3)), e.toArray(this.instanceColor.array, t * 3);
  }
  setMatrixAt(t, e) {
    e.toArray(this.instanceMatrix.array, t * 16);
  }
  setMorphAt(t, e) {
    const i = e.morphTargetInfluences, s = i.length + 1;
    this.morphTexture === null && (this.morphTexture = new pe(new Float32Array(s * this.count), s, this.count, Mo, bi));
    const n = this.morphTexture.source.data.data;
    let r = 0;
    for (let h = 0; h < i.length; h++) r += i[h];
    const a = this.geometry.morphTargetsRelative ? 1 : 1 - r, o = s * t;
    n[o] = a, n.set(i, o + 1);
  }
  updateMorphTargets() {
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" }), this.morphTexture !== null && (this.morphTexture.dispose(), this.morphTexture = null);
  }
}
const On = new w(), cc = new w(), uc = new Qt();
class hi {
  constructor(t = new w(1, 0, 0), e = 0) {
    this.isPlane = true, this.normal = t, this.constant = e;
  }
  set(t, e) {
    return this.normal.copy(t), this.constant = e, this;
  }
  setComponents(t, e, i, s) {
    return this.normal.set(t, e, i), this.constant = s, this;
  }
  setFromNormalAndCoplanarPoint(t, e) {
    return this.normal.copy(t), this.constant = -e.dot(this.normal), this;
  }
  setFromCoplanarPoints(t, e, i) {
    const s = On.subVectors(i, e).cross(cc.subVectors(t, e)).normalize();
    return this.setFromNormalAndCoplanarPoint(s, t), this;
  }
  copy(t) {
    return this.normal.copy(t.normal), this.constant = t.constant, this;
  }
  normalize() {
    const t = 1 / this.normal.length();
    return this.normal.multiplyScalar(t), this.constant *= t, this;
  }
  negate() {
    return this.constant *= -1, this.normal.negate(), this;
  }
  distanceToPoint(t) {
    return this.normal.dot(t) + this.constant;
  }
  distanceToSphere(t) {
    return this.distanceToPoint(t.center) - t.radius;
  }
  projectPoint(t, e) {
    return e.copy(t).addScaledVector(this.normal, -this.distanceToPoint(t));
  }
  intersectLine(t, e) {
    const i = t.delta(On), s = this.normal.dot(i);
    if (s === 0) return this.distanceToPoint(t.start) === 0 ? e.copy(t.start) : null;
    const n = -(t.start.dot(this.normal) + this.constant) / s;
    return n < 0 || n > 1 ? null : e.copy(t.start).addScaledVector(i, n);
  }
  intersectsLine(t) {
    const e = this.distanceToPoint(t.start), i = this.distanceToPoint(t.end);
    return e < 0 && i > 0 || i < 0 && e > 0;
  }
  intersectsBox(t) {
    return t.intersectsPlane(this);
  }
  intersectsSphere(t) {
    return t.intersectsPlane(this);
  }
  coplanarPoint(t) {
    return t.copy(this.normal).multiplyScalar(-this.constant);
  }
  applyMatrix4(t, e) {
    const i = e || uc.getNormalMatrix(t), s = this.coplanarPoint(On).applyMatrix4(t), n = this.normal.applyMatrix3(i).normalize();
    return this.constant = -s.dot(n), this;
  }
  translate(t) {
    return this.constant -= t.dot(this.normal), this;
  }
  equals(t) {
    return t.normal.equals(this.normal) && t.constant === this.constant;
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
const ze = new mt(), dc = new I(0.5, 0.5), _s = new w();
class yr {
  constructor(t = new hi(), e = new hi(), i = new hi(), s = new hi(), n = new hi(), r = new hi()) {
    this.planes = [t, e, i, s, n, r];
  }
  set(t, e, i, s, n, r) {
    const a = this.planes;
    return a[0].copy(t), a[1].copy(e), a[2].copy(i), a[3].copy(s), a[4].copy(n), a[5].copy(r), this;
  }
  copy(t) {
    const e = this.planes;
    for (let i = 0; i < 6; i++) e[i].copy(t.planes[i]);
    return this;
  }
  setFromProjectionMatrix(t, e = Yt, i = false) {
    const s = this.planes, n = t.elements, r = n[0], a = n[1], o = n[2], h = n[3], c = n[4], u = n[5], d = n[6], p = n[7], f = n[8], m = n[9], g = n[10], y = n[11], x = n[12], b = n[13], M = n[14], _ = n[15];
    if (s[0].setComponents(h - r, p - c, y - f, _ - x).normalize(), s[1].setComponents(h + r, p + c, y + f, _ + x).normalize(), s[2].setComponents(h + a, p + u, y + m, _ + b).normalize(), s[3].setComponents(h - a, p - u, y - m, _ - b).normalize(), i) s[4].setComponents(o, d, g, M).normalize(), s[5].setComponents(h - o, p - d, y - g, _ - M).normalize();
    else if (s[4].setComponents(h - o, p - d, y - g, _ - M).normalize(), e === Yt) s[5].setComponents(h + o, p + d, y + g, _ + M).normalize();
    else if (e === Mi) s[5].setComponents(o, d, g, M).normalize();
    else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: " + e);
    return this;
  }
  intersectsObject(t) {
    if (t.boundingSphere !== void 0) t.boundingSphere === null && t.computeBoundingSphere(), ze.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);
    else {
      const e = t.geometry;
      e.boundingSphere === null && e.computeBoundingSphere(), ze.copy(e.boundingSphere).applyMatrix4(t.matrixWorld);
    }
    return this.intersectsSphere(ze);
  }
  intersectsSprite(t) {
    ze.center.set(0, 0, 0);
    const e = dc.distanceTo(t.center);
    return ze.radius = 0.7071067811865476 + e, ze.applyMatrix4(t.matrixWorld), this.intersectsSphere(ze);
  }
  intersectsSphere(t) {
    const e = this.planes, i = t.center, s = -t.radius;
    for (let n = 0; n < 6; n++) if (e[n].distanceToPoint(i) < s) return false;
    return true;
  }
  intersectsBox(t) {
    const e = this.planes;
    for (let i = 0; i < 6; i++) {
      const s = e[i];
      if (_s.x = s.normal.x > 0 ? t.max.x : t.min.x, _s.y = s.normal.y > 0 ? t.max.y : t.min.y, _s.z = s.normal.z > 0 ? t.max.z : t.min.z, s.distanceToPoint(_s) < 0) return false;
    }
    return true;
  }
  containsPoint(t) {
    const e = this.planes;
    for (let i = 0; i < 6; i++) if (e[i].distanceToPoint(t) < 0) return false;
    return true;
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
const Ht = new G(), Jt = new yr();
class gr {
  constructor() {
    this.coordinateSystem = Yt;
  }
  intersectsObject(t, e) {
    if (!e.isArrayCamera || e.cameras.length === 0) return false;
    for (let i = 0; i < e.cameras.length; i++) {
      const s = e.cameras[i];
      if (Ht.multiplyMatrices(s.projectionMatrix, s.matrixWorldInverse), Jt.setFromProjectionMatrix(Ht, s.coordinateSystem, s.reversedDepth), Jt.intersectsObject(t)) return true;
    }
    return false;
  }
  intersectsSprite(t, e) {
    if (!e || !e.cameras || e.cameras.length === 0) return false;
    for (let i = 0; i < e.cameras.length; i++) {
      const s = e.cameras[i];
      if (Ht.multiplyMatrices(s.projectionMatrix, s.matrixWorldInverse), Jt.setFromProjectionMatrix(Ht, s.coordinateSystem, s.reversedDepth), Jt.intersectsSprite(t)) return true;
    }
    return false;
  }
  intersectsSphere(t, e) {
    if (!e || !e.cameras || e.cameras.length === 0) return false;
    for (let i = 0; i < e.cameras.length; i++) {
      const s = e.cameras[i];
      if (Ht.multiplyMatrices(s.projectionMatrix, s.matrixWorldInverse), Jt.setFromProjectionMatrix(Ht, s.coordinateSystem, s.reversedDepth), Jt.intersectsSphere(t)) return true;
    }
    return false;
  }
  intersectsBox(t, e) {
    if (!e || !e.cameras || e.cameras.length === 0) return false;
    for (let i = 0; i < e.cameras.length; i++) {
      const s = e.cameras[i];
      if (Ht.multiplyMatrices(s.projectionMatrix, s.matrixWorldInverse), Jt.setFromProjectionMatrix(Ht, s.coordinateSystem, s.reversedDepth), Jt.intersectsBox(t)) return true;
    }
    return false;
  }
  containsPoint(t, e) {
    if (!e || !e.cameras || e.cameras.length === 0) return false;
    for (let i = 0; i < e.cameras.length; i++) {
      const s = e.cameras[i];
      if (Ht.multiplyMatrices(s.projectionMatrix, s.matrixWorldInverse), Jt.setFromProjectionMatrix(Ht, s.coordinateSystem, s.reversedDepth), Jt.containsPoint(t)) return true;
    }
    return false;
  }
  clone() {
    return new gr();
  }
}
function En(l, t) {
  return l - t;
}
function pc(l, t) {
  return l.z - t.z;
}
function fc(l, t) {
  return t.z - l.z;
}
class mc {
  constructor() {
    this.index = 0, this.pool = [], this.list = [];
  }
  push(t, e, i, s) {
    const n = this.pool, r = this.list;
    this.index >= n.length && n.push({ start: -1, count: -1, z: -1, index: -1 });
    const a = n[this.index];
    r.push(a), this.index++, a.start = t, a.count = e, a.z = i, a.index = s;
  }
  reset() {
    this.list.length = 0, this.index = 0;
  }
}
const Mt = new G(), yc = new U(1, 1, 1), La = new yr(), gc = new gr(), vs = new xt(), Be = new mt(), Ni = new w(), Da = new w(), xc = new w(), Nn = new mc(), ft = new Kt(), Ss = [];
function bc(l, t, e = 0) {
  const i = t.itemSize;
  if (l.isInterleavedBufferAttribute || l.array.constructor !== t.array.constructor) {
    const s = l.count;
    for (let n = 0; n < s; n++) for (let r = 0; r < i; r++) t.setComponent(n + e, r, l.getComponent(n, r));
  } else t.array.set(l.array, e * i);
  t.needsUpdate = true;
}
function Fe(l, t) {
  if (l.constructor !== t.constructor) {
    const e = Math.min(l.length, t.length);
    for (let i = 0; i < e; i++) t[i] = l[i];
  } else {
    const e = Math.min(l.length, t.length);
    t.set(new l.constructor(l.buffer, 0, e));
  }
}
class Mc extends Kt {
  constructor(t, e, i = e * 2, s) {
    super(new H(), s), this.isBatchedMesh = true, this.perObjectFrustumCulled = true, this.sortObjects = true, this.boundingBox = null, this.boundingSphere = null, this.customSort = null, this._instanceInfo = [], this._geometryInfo = [], this._availableInstanceIds = [], this._availableGeometryIds = [], this._nextIndexStart = 0, this._nextVertexStart = 0, this._geometryCount = 0, this._visibilityChanged = true, this._geometryInitialized = false, this._maxInstanceCount = t, this._maxVertexCount = e, this._maxIndexCount = i, this._multiDrawCounts = new Int32Array(t), this._multiDrawStarts = new Int32Array(t), this._multiDrawCount = 0, this._multiDrawInstances = null, this._matricesTexture = null, this._indirectTexture = null, this._colorsTexture = null, this._initMatricesTexture(), this._initIndirectTexture();
  }
  get maxInstanceCount() {
    return this._maxInstanceCount;
  }
  get instanceCount() {
    return this._instanceInfo.length - this._availableInstanceIds.length;
  }
  get unusedVertexCount() {
    return this._maxVertexCount - this._nextVertexStart;
  }
  get unusedIndexCount() {
    return this._maxIndexCount - this._nextIndexStart;
  }
  _initMatricesTexture() {
    let t = Math.sqrt(this._maxInstanceCount * 4);
    t = Math.ceil(t / 4) * 4, t = Math.max(t, 4);
    const e = new Float32Array(t * t * 4), i = new pe(e, t, t, Hi, bi);
    this._matricesTexture = i;
  }
  _initIndirectTexture() {
    let t = Math.sqrt(this._maxInstanceCount);
    t = Math.ceil(t);
    const e = new Uint32Array(t * t), i = new pe(e, t, t, wo, nn);
    this._indirectTexture = i;
  }
  _initColorsTexture() {
    let t = Math.sqrt(this._maxInstanceCount);
    t = Math.ceil(t);
    const e = new Float32Array(t * t * 4).fill(1), i = new pe(e, t, t, Hi, bi);
    i.colorSpace = Rt.workingColorSpace, this._colorsTexture = i;
  }
  _initializeGeometry(t) {
    const e = this.geometry, i = this._maxVertexCount, s = this._maxIndexCount;
    if (this._geometryInitialized === false) {
      for (const n in t.attributes) {
        const r = t.getAttribute(n), { array: a, itemSize: o, normalized: h } = r, c = new a.constructor(i * o), u = new tt(c, o, h);
        e.setAttribute(n, u);
      }
      if (t.getIndex() !== null) {
        const n = i > 65535 ? new Uint32Array(s) : new Uint16Array(s);
        e.setIndex(new tt(n, 1));
      }
      this._geometryInitialized = true;
    }
  }
  _validateGeometry(t) {
    const e = this.geometry;
    if (!!t.getIndex() != !!e.getIndex()) throw new Error('THREE.BatchedMesh: All geometries must consistently have "index".');
    for (const i in e.attributes) {
      if (!t.hasAttribute(i)) throw new Error(`THREE.BatchedMesh: Added geometry missing "${i}". All geometries must have consistent attributes.`);
      const s = t.getAttribute(i), n = e.getAttribute(i);
      if (s.itemSize !== n.itemSize || s.normalized !== n.normalized) throw new Error("THREE.BatchedMesh: All attributes must have a consistent itemSize and normalized value.");
    }
  }
  validateInstanceId(t) {
    const e = this._instanceInfo;
    if (t < 0 || t >= e.length || e[t].active === false) throw new Error(`THREE.BatchedMesh: Invalid instanceId ${t}. Instance is either out of range or has been deleted.`);
  }
  validateGeometryId(t) {
    const e = this._geometryInfo;
    if (t < 0 || t >= e.length || e[t].active === false) throw new Error(`THREE.BatchedMesh: Invalid geometryId ${t}. Geometry is either out of range or has been deleted.`);
  }
  setCustomSort(t) {
    return this.customSort = t, this;
  }
  computeBoundingBox() {
    this.boundingBox === null && (this.boundingBox = new xt());
    const t = this.boundingBox, e = this._instanceInfo;
    t.makeEmpty();
    for (let i = 0, s = e.length; i < s; i++) {
      if (e[i].active === false) continue;
      const n = e[i].geometryIndex;
      this.getMatrixAt(i, Mt), this.getBoundingBoxAt(n, vs).applyMatrix4(Mt), t.union(vs);
    }
  }
  computeBoundingSphere() {
    this.boundingSphere === null && (this.boundingSphere = new mt());
    const t = this.boundingSphere, e = this._instanceInfo;
    t.makeEmpty();
    for (let i = 0, s = e.length; i < s; i++) {
      if (e[i].active === false) continue;
      const n = e[i].geometryIndex;
      this.getMatrixAt(i, Mt), this.getBoundingSphereAt(n, Be).applyMatrix4(Mt), t.union(Be);
    }
  }
  addInstance(t) {
    if (this._instanceInfo.length >= this.maxInstanceCount && this._availableInstanceIds.length === 0) throw new Error("THREE.BatchedMesh: Maximum item count reached.");
    const i = { visible: true, active: true, geometryIndex: t };
    let s = null;
    this._availableInstanceIds.length > 0 ? (this._availableInstanceIds.sort(En), s = this._availableInstanceIds.shift(), this._instanceInfo[s] = i) : (s = this._instanceInfo.length, this._instanceInfo.push(i));
    const n = this._matricesTexture;
    Mt.identity().toArray(n.image.data, s * 16), n.needsUpdate = true;
    const r = this._colorsTexture;
    return r && (yc.toArray(r.image.data, s * 4), r.needsUpdate = true), this._visibilityChanged = true, s;
  }
  addGeometry(t, e = -1, i = -1) {
    this._initializeGeometry(t), this._validateGeometry(t);
    const s = { vertexStart: -1, vertexCount: -1, reservedVertexCount: -1, indexStart: -1, indexCount: -1, reservedIndexCount: -1, start: -1, count: -1, boundingBox: null, boundingSphere: null, active: true }, n = this._geometryInfo;
    s.vertexStart = this._nextVertexStart, s.reservedVertexCount = e === -1 ? t.getAttribute("position").count : e;
    const r = t.getIndex();
    if (r !== null && (s.indexStart = this._nextIndexStart, s.reservedIndexCount = i === -1 ? r.count : i), s.indexStart !== -1 && s.indexStart + s.reservedIndexCount > this._maxIndexCount || s.vertexStart + s.reservedVertexCount > this._maxVertexCount) throw new Error("THREE.BatchedMesh: Reserved space request exceeds the maximum buffer size.");
    let o;
    return this._availableGeometryIds.length > 0 ? (this._availableGeometryIds.sort(En), o = this._availableGeometryIds.shift(), n[o] = s) : (o = this._geometryCount, this._geometryCount++, n.push(s)), this.setGeometryAt(o, t), this._nextIndexStart = s.indexStart + s.reservedIndexCount, this._nextVertexStart = s.vertexStart + s.reservedVertexCount, o;
  }
  setGeometryAt(t, e) {
    if (t >= this._geometryCount) throw new Error("THREE.BatchedMesh: Maximum geometry count reached.");
    this._validateGeometry(e);
    const i = this.geometry, s = i.getIndex() !== null, n = i.getIndex(), r = e.getIndex(), a = this._geometryInfo[t];
    if (s && r.count > a.reservedIndexCount || e.attributes.position.count > a.reservedVertexCount) throw new Error("THREE.BatchedMesh: Reserved space not large enough for provided geometry.");
    const o = a.vertexStart, h = a.reservedVertexCount;
    a.vertexCount = e.getAttribute("position").count;
    for (const c in i.attributes) {
      const u = e.getAttribute(c), d = i.getAttribute(c);
      bc(u, d, o);
      const p = u.itemSize;
      for (let f = u.count, m = h; f < m; f++) {
        const g = o + f;
        for (let y = 0; y < p; y++) d.setComponent(g, y, 0);
      }
      d.needsUpdate = true, d.addUpdateRange(o * p, h * p);
    }
    if (s) {
      const c = a.indexStart, u = a.reservedIndexCount;
      a.indexCount = e.getIndex().count;
      for (let d = 0; d < r.count; d++) n.setX(c + d, o + r.getX(d));
      for (let d = r.count, p = u; d < p; d++) n.setX(c + d, o);
      n.needsUpdate = true, n.addUpdateRange(c, a.reservedIndexCount);
    }
    return a.start = s ? a.indexStart : a.vertexStart, a.count = s ? a.indexCount : a.vertexCount, a.boundingBox = null, e.boundingBox !== null && (a.boundingBox = e.boundingBox.clone()), a.boundingSphere = null, e.boundingSphere !== null && (a.boundingSphere = e.boundingSphere.clone()), this._visibilityChanged = true, t;
  }
  deleteGeometry(t) {
    const e = this._geometryInfo;
    if (t >= e.length || e[t].active === false) return this;
    const i = this._instanceInfo;
    for (let s = 0, n = i.length; s < n; s++) i[s].active && i[s].geometryIndex === t && this.deleteInstance(s);
    return e[t].active = false, this._availableGeometryIds.push(t), this._visibilityChanged = true, this;
  }
  deleteInstance(t) {
    return this.validateInstanceId(t), this._instanceInfo[t].active = false, this._availableInstanceIds.push(t), this._visibilityChanged = true, this;
  }
  optimize() {
    let t = 0, e = 0;
    const i = this._geometryInfo, s = i.map((r, a) => a).sort((r, a) => i[r].vertexStart - i[a].vertexStart), n = this.geometry;
    for (let r = 0, a = i.length; r < a; r++) {
      const o = s[r], h = i[o];
      if (h.active !== false) {
        if (n.index !== null) {
          if (h.indexStart !== e) {
            const { indexStart: c, vertexStart: u, reservedIndexCount: d } = h, p = n.index, f = p.array, m = t - u;
            for (let g = c; g < c + d; g++) f[g] = f[g] + m;
            p.array.copyWithin(e, c, c + d), p.addUpdateRange(e, d), p.needsUpdate = true, h.indexStart = e;
          }
          e += h.reservedIndexCount;
        }
        if (h.vertexStart !== t) {
          const { vertexStart: c, reservedVertexCount: u } = h, d = n.attributes;
          for (const p in d) {
            const f = d[p], { array: m, itemSize: g } = f;
            m.copyWithin(t * g, c * g, (c + u) * g), f.addUpdateRange(t * g, u * g), f.needsUpdate = true;
          }
          h.vertexStart = t;
        }
        t += h.reservedVertexCount, h.start = n.index ? h.indexStart : h.vertexStart;
      }
    }
    return this._nextIndexStart = e, this._nextVertexStart = t, this._visibilityChanged = true, this;
  }
  getBoundingBoxAt(t, e) {
    if (t >= this._geometryCount) return null;
    const i = this.geometry, s = this._geometryInfo[t];
    if (s.boundingBox === null) {
      const n = new xt(), r = i.index, a = i.attributes.position;
      for (let o = s.start, h = s.start + s.count; o < h; o++) {
        let c = o;
        r && (c = r.getX(c)), n.expandByPoint(Ni.fromBufferAttribute(a, c));
      }
      s.boundingBox = n;
    }
    return e.copy(s.boundingBox), e;
  }
  getBoundingSphereAt(t, e) {
    if (t >= this._geometryCount) return null;
    const i = this.geometry, s = this._geometryInfo[t];
    if (s.boundingSphere === null) {
      const n = new mt();
      this.getBoundingBoxAt(t, vs), vs.getCenter(n.center);
      const r = i.index, a = i.attributes.position;
      let o = 0;
      for (let h = s.start, c = s.start + s.count; h < c; h++) {
        let u = h;
        r && (u = r.getX(u)), Ni.fromBufferAttribute(a, u), o = Math.max(o, n.center.distanceToSquared(Ni));
      }
      n.radius = Math.sqrt(o), s.boundingSphere = n;
    }
    return e.copy(s.boundingSphere), e;
  }
  setMatrixAt(t, e) {
    this.validateInstanceId(t);
    const i = this._matricesTexture, s = this._matricesTexture.image.data;
    return e.toArray(s, t * 16), i.needsUpdate = true, this;
  }
  getMatrixAt(t, e) {
    return this.validateInstanceId(t), e.fromArray(this._matricesTexture.image.data, t * 16);
  }
  setColorAt(t, e) {
    return this.validateInstanceId(t), this._colorsTexture === null && this._initColorsTexture(), e.toArray(this._colorsTexture.image.data, t * 4), this._colorsTexture.needsUpdate = true, this;
  }
  getColorAt(t, e) {
    return this.validateInstanceId(t), e.fromArray(this._colorsTexture.image.data, t * 4);
  }
  setVisibleAt(t, e) {
    return this.validateInstanceId(t), this._instanceInfo[t].visible === e ? this : (this._instanceInfo[t].visible = e, this._visibilityChanged = true, this);
  }
  getVisibleAt(t) {
    return this.validateInstanceId(t), this._instanceInfo[t].visible;
  }
  setGeometryIdAt(t, e) {
    return this.validateInstanceId(t), this.validateGeometryId(e), this._instanceInfo[t].geometryIndex = e, this;
  }
  getGeometryIdAt(t) {
    return this.validateInstanceId(t), this._instanceInfo[t].geometryIndex;
  }
  getGeometryRangeAt(t, e = {}) {
    this.validateGeometryId(t);
    const i = this._geometryInfo[t];
    return e.vertexStart = i.vertexStart, e.vertexCount = i.vertexCount, e.reservedVertexCount = i.reservedVertexCount, e.indexStart = i.indexStart, e.indexCount = i.indexCount, e.reservedIndexCount = i.reservedIndexCount, e.start = i.start, e.count = i.count, e;
  }
  setInstanceCount(t) {
    const e = this._availableInstanceIds, i = this._instanceInfo;
    for (e.sort(En); e[e.length - 1] === i.length - 1; ) i.pop(), e.pop();
    if (t < i.length) throw new Error(`BatchedMesh: Instance ids outside the range ${t} are being used. Cannot shrink instance count.`);
    const s = new Int32Array(t), n = new Int32Array(t);
    Fe(this._multiDrawCounts, s), Fe(this._multiDrawStarts, n), this._multiDrawCounts = s, this._multiDrawStarts = n, this._maxInstanceCount = t;
    const r = this._indirectTexture, a = this._matricesTexture, o = this._colorsTexture;
    r.dispose(), this._initIndirectTexture(), Fe(r.image.data, this._indirectTexture.image.data), a.dispose(), this._initMatricesTexture(), Fe(a.image.data, this._matricesTexture.image.data), o && (o.dispose(), this._initColorsTexture(), Fe(o.image.data, this._colorsTexture.image.data));
  }
  setGeometrySize(t, e) {
    const i = [...this._geometryInfo].filter((a) => a.active);
    if (Math.max(...i.map((a) => a.vertexStart + a.reservedVertexCount)) > t) throw new Error(`BatchedMesh: Geometry vertex values are being used outside the range ${e}. Cannot shrink further.`);
    if (this.geometry.index && Math.max(...i.map((o) => o.indexStart + o.reservedIndexCount)) > e) throw new Error(`BatchedMesh: Geometry index values are being used outside the range ${e}. Cannot shrink further.`);
    const n = this.geometry;
    n.dispose(), this._maxVertexCount = t, this._maxIndexCount = e, this._geometryInitialized && (this._geometryInitialized = false, this.geometry = new H(), this._initializeGeometry(n));
    const r = this.geometry;
    n.index && Fe(n.index.array, r.index.array);
    for (const a in n.attributes) Fe(n.attributes[a].array, r.attributes[a].array);
  }
  raycast(t, e) {
    const i = this._instanceInfo, s = this._geometryInfo, n = this.matrixWorld, r = this.geometry;
    ft.material = this.material, ft.geometry.index = r.index, ft.geometry.attributes = r.attributes, ft.geometry.boundingBox === null && (ft.geometry.boundingBox = new xt()), ft.geometry.boundingSphere === null && (ft.geometry.boundingSphere = new mt());
    for (let a = 0, o = i.length; a < o; a++) {
      if (!i[a].visible || !i[a].active) continue;
      const h = i[a].geometryIndex, c = s[h];
      ft.geometry.setDrawRange(c.start, c.count), this.getMatrixAt(a, ft.matrixWorld).premultiply(n), this.getBoundingBoxAt(h, ft.geometry.boundingBox), this.getBoundingSphereAt(h, ft.geometry.boundingSphere), ft.raycast(t, Ss);
      for (let u = 0, d = Ss.length; u < d; u++) {
        const p = Ss[u];
        p.object = this, p.batchId = a, e.push(p);
      }
      Ss.length = 0;
    }
    ft.material = null, ft.geometry.index = null, ft.geometry.attributes = {}, ft.geometry.setDrawRange(0, 1 / 0);
  }
  copy(t) {
    return super.copy(t), this.geometry = t.geometry.clone(), this.perObjectFrustumCulled = t.perObjectFrustumCulled, this.sortObjects = t.sortObjects, this.boundingBox = t.boundingBox !== null ? t.boundingBox.clone() : null, this.boundingSphere = t.boundingSphere !== null ? t.boundingSphere.clone() : null, this._geometryInfo = t._geometryInfo.map((e) => ({ ...e, boundingBox: e.boundingBox !== null ? e.boundingBox.clone() : null, boundingSphere: e.boundingSphere !== null ? e.boundingSphere.clone() : null })), this._instanceInfo = t._instanceInfo.map((e) => ({ ...e })), this._availableInstanceIds = t._availableInstanceIds.slice(), this._availableGeometryIds = t._availableGeometryIds.slice(), this._nextIndexStart = t._nextIndexStart, this._nextVertexStart = t._nextVertexStart, this._geometryCount = t._geometryCount, this._maxInstanceCount = t._maxInstanceCount, this._maxVertexCount = t._maxVertexCount, this._maxIndexCount = t._maxIndexCount, this._geometryInitialized = t._geometryInitialized, this._multiDrawCounts = t._multiDrawCounts.slice(), this._multiDrawStarts = t._multiDrawStarts.slice(), this._indirectTexture = t._indirectTexture.clone(), this._indirectTexture.image.data = this._indirectTexture.image.data.slice(), this._matricesTexture = t._matricesTexture.clone(), this._matricesTexture.image.data = this._matricesTexture.image.data.slice(), this._colorsTexture !== null && (this._colorsTexture = t._colorsTexture.clone(), this._colorsTexture.image.data = this._colorsTexture.image.data.slice()), this;
  }
  dispose() {
    this.geometry.dispose(), this._matricesTexture.dispose(), this._matricesTexture = null, this._indirectTexture.dispose(), this._indirectTexture = null, this._colorsTexture !== null && (this._colorsTexture.dispose(), this._colorsTexture = null);
  }
  onBeforeRender(t, e, i, s, n) {
    if (!this._visibilityChanged && !this.perObjectFrustumCulled && !this.sortObjects) return;
    const r = s.getIndex();
    let a = r === null ? 1 : r.array.BYTES_PER_ELEMENT, o = 1;
    n.wireframe && (o = 2, a = s.attributes.position.count > 65535 ? 4 : 2);
    const h = this._instanceInfo, c = this._multiDrawStarts, u = this._multiDrawCounts, d = this._geometryInfo, p = this.perObjectFrustumCulled, f = this._indirectTexture, m = f.image.data, g = i.isArrayCamera ? gc : La;
    p && !i.isArrayCamera && (Mt.multiplyMatrices(i.projectionMatrix, i.matrixWorldInverse).multiply(this.matrixWorld), La.setFromProjectionMatrix(Mt, i.coordinateSystem, i.reversedDepth));
    let y = 0;
    if (this.sortObjects) {
      Mt.copy(this.matrixWorld).invert(), Ni.setFromMatrixPosition(i.matrixWorld).applyMatrix4(Mt), Da.set(0, 0, -1).transformDirection(i.matrixWorld).transformDirection(Mt);
      for (let M = 0, _ = h.length; M < _; M++) if (h[M].visible && h[M].active) {
        const v = h[M].geometryIndex;
        this.getMatrixAt(M, Mt), this.getBoundingSphereAt(v, Be).applyMatrix4(Mt);
        let A = false;
        if (p && (A = !g.intersectsSphere(Be, i)), !A) {
          const S = d[v], T = xc.subVectors(Be.center, Ni).dot(Da);
          Nn.push(S.start, S.count, T, M);
        }
      }
      const x = Nn.list, b = this.customSort;
      b === null ? x.sort(n.transparent ? fc : pc) : b.call(this, x, i);
      for (let M = 0, _ = x.length; M < _; M++) {
        const v = x[M];
        c[y] = v.start * a * o, u[y] = v.count * o, m[y] = v.index, y++;
      }
      Nn.reset();
    } else for (let x = 0, b = h.length; x < b; x++) if (h[x].visible && h[x].active) {
      const M = h[x].geometryIndex;
      let _ = false;
      if (p && (this.getMatrixAt(x, Mt), this.getBoundingSphereAt(M, Be).applyMatrix4(Mt), _ = !g.intersectsSphere(Be, i)), !_) {
        const v = d[M];
        c[y] = v.start * a * o, u[y] = v.count * o, m[y] = x, y++;
      }
    }
    f.needsUpdate = true, this._multiDrawCount = y, this._visibilityChanged = false;
  }
  onBeforeShadow(t, e, i, s, n, r) {
    this.onBeforeRender(t, null, s, n, r);
  }
}
class vt extends bt {
  constructor(t) {
    super(), this.isLineBasicMaterial = true, this.type = "LineBasicMaterial", this.color = new U(16777215), this.map = null, this.linewidth = 1, this.linecap = "round", this.linejoin = "round", this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.linewidth = t.linewidth, this.linecap = t.linecap, this.linejoin = t.linejoin, this.fog = t.fog, this;
  }
}
const Ys = new w(), $s = new w(), Va = new G(), Li = new ji(), As = new mt(), Ln = new w(), Ua = new w();
class Ue extends $ {
  constructor(t = new H(), e = new vt()) {
    super(), this.isLine = true, this.type = "Line", this.geometry = t, this.material = e, this.morphTargetDictionary = void 0, this.morphTargetInfluences = void 0, this.updateMorphTargets();
  }
  copy(t, e) {
    return super.copy(t, e), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
  }
  computeLineDistances() {
    const t = this.geometry;
    if (t.index === null) {
      const e = t.attributes.position, i = [0];
      for (let s = 1, n = e.count; s < n; s++) Ys.fromBufferAttribute(e, s - 1), $s.fromBufferAttribute(e, s), i[s] = i[s - 1], i[s] += Ys.distanceTo($s);
      t.setAttribute("lineDistance", new P(i, 1));
    } else N("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
    return this;
  }
  raycast(t, e) {
    const i = this.geometry, s = this.matrixWorld, n = t.params.Line.threshold, r = i.drawRange;
    if (i.boundingSphere === null && i.computeBoundingSphere(), As.copy(i.boundingSphere), As.applyMatrix4(s), As.radius += n, t.ray.intersectsSphere(As) === false) return;
    Va.copy(s).invert(), Li.copy(t.ray).applyMatrix4(Va);
    const a = n / ((this.scale.x + this.scale.y + this.scale.z) / 3), o = a * a, h = this.isLineSegments ? 2 : 1, c = i.index, d = i.attributes.position;
    if (c !== null) {
      const p = Math.max(0, r.start), f = Math.min(c.count, r.start + r.count);
      for (let m = p, g = f - 1; m < g; m += h) {
        const y = c.getX(m), x = c.getX(m + 1), b = Ts(this, t, Li, o, y, x, m);
        b && e.push(b);
      }
      if (this.isLineLoop) {
        const m = c.getX(f - 1), g = c.getX(p), y = Ts(this, t, Li, o, m, g, f - 1);
        y && e.push(y);
      }
    } else {
      const p = Math.max(0, r.start), f = Math.min(d.count, r.start + r.count);
      for (let m = p, g = f - 1; m < g; m += h) {
        const y = Ts(this, t, Li, o, m, m + 1, m);
        y && e.push(y);
      }
      if (this.isLineLoop) {
        const m = Ts(this, t, Li, o, f - 1, p, f - 1);
        m && e.push(m);
      }
    }
  }
  updateMorphTargets() {
    const e = this.geometry.morphAttributes, i = Object.keys(e);
    if (i.length > 0) {
      const s = e[i[0]];
      if (s !== void 0) {
        this.morphTargetInfluences = [], this.morphTargetDictionary = {};
        for (let n = 0, r = s.length; n < r; n++) {
          const a = s[n].name || String(n);
          this.morphTargetInfluences.push(0), this.morphTargetDictionary[a] = n;
        }
      }
    }
  }
}
function Ts(l, t, e, i, s, n, r) {
  const a = l.geometry.attributes.position;
  if (Ys.fromBufferAttribute(a, s), $s.fromBufferAttribute(a, n), e.distanceSqToSegment(Ys, $s, Ln, Ua) > i) return;
  Ln.applyMatrix4(l.matrixWorld);
  const h = t.ray.origin.distanceTo(Ln);
  if (!(h < t.near || h > t.far)) return { distance: h, point: Ua.clone().applyMatrix4(l.matrixWorld), index: r, face: null, faceIndex: null, barycoord: null, object: l };
}
const Wa = new w(), Ga = new w();
class fe extends Ue {
  constructor(t, e) {
    super(t, e), this.isLineSegments = true, this.type = "LineSegments";
  }
  computeLineDistances() {
    const t = this.geometry;
    if (t.index === null) {
      const e = t.attributes.position, i = [];
      for (let s = 0, n = e.count; s < n; s += 2) Wa.fromBufferAttribute(e, s), Ga.fromBufferAttribute(e, s + 1), i[s] = s === 0 ? 0 : i[s - 1], i[s + 1] = i[s] + Wa.distanceTo(Ga);
      t.setAttribute("lineDistance", new P(i, 1));
    } else N("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
    return this;
  }
}
class wc extends Ue {
  constructor(t, e) {
    super(t, e), this.isLineLoop = true, this.type = "LineLoop";
  }
}
class Ro extends bt {
  constructor(t) {
    super(), this.isPointsMaterial = true, this.type = "PointsMaterial", this.color = new U(16777215), this.map = null, this.alphaMap = null, this.size = 1, this.sizeAttenuation = true, this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.alphaMap = t.alphaMap, this.size = t.size, this.sizeAttenuation = t.sizeAttenuation, this.fog = t.fog, this;
  }
}
const qa = new G(), tr = new ji(), Cs = new mt(), Is = new w();
class _c extends $ {
  constructor(t = new H(), e = new Ro()) {
    super(), this.isPoints = true, this.type = "Points", this.geometry = t, this.material = e, this.morphTargetDictionary = void 0, this.morphTargetInfluences = void 0, this.updateMorphTargets();
  }
  copy(t, e) {
    return super.copy(t, e), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
  }
  raycast(t, e) {
    const i = this.geometry, s = this.matrixWorld, n = t.params.Points.threshold, r = i.drawRange;
    if (i.boundingSphere === null && i.computeBoundingSphere(), Cs.copy(i.boundingSphere), Cs.applyMatrix4(s), Cs.radius += n, t.ray.intersectsSphere(Cs) === false) return;
    qa.copy(s).invert(), tr.copy(t.ray).applyMatrix4(qa);
    const a = n / ((this.scale.x + this.scale.y + this.scale.z) / 3), o = a * a, h = i.index, u = i.attributes.position;
    if (h !== null) {
      const d = Math.max(0, r.start), p = Math.min(h.count, r.start + r.count);
      for (let f = d, m = p; f < m; f++) {
        const g = h.getX(f);
        Is.fromBufferAttribute(u, g), Ha(Is, g, o, s, t, e, this);
      }
    } else {
      const d = Math.max(0, r.start), p = Math.min(u.count, r.start + r.count);
      for (let f = d, m = p; f < m; f++) Is.fromBufferAttribute(u, f), Ha(Is, f, o, s, t, e, this);
    }
  }
  updateMorphTargets() {
    const e = this.geometry.morphAttributes, i = Object.keys(e);
    if (i.length > 0) {
      const s = e[i[0]];
      if (s !== void 0) {
        this.morphTargetInfluences = [], this.morphTargetDictionary = {};
        for (let n = 0, r = s.length; n < r; n++) {
          const a = s[n].name || String(n);
          this.morphTargetInfluences.push(0), this.morphTargetDictionary[a] = n;
        }
      }
    }
  }
}
function Ha(l, t, e, i, s, n, r) {
  const a = tr.distanceSqToPoint(l);
  if (a < e) {
    const o = new w();
    tr.closestPointToPoint(l, o), o.applyMatrix4(i);
    const h = s.ray.origin.distanceTo(o);
    if (h < s.near || h > s.far) return;
    n.push({ distance: h, distanceToRay: Math.sqrt(a), point: o, index: t, face: null, faceIndex: null, barycoord: null, object: r });
  }
}
class vc extends lt {
  constructor(t, e, i, s, n = Gt, r = Gt, a, o, h) {
    super(t, e, i, s, n, r, a, o, h), this.isVideoTexture = true, this.generateMipmaps = false, this._requestVideoFrameCallbackId = 0;
    const c = this;
    function u() {
      c.needsUpdate = true, c._requestVideoFrameCallbackId = t.requestVideoFrameCallback(u);
    }
    "requestVideoFrameCallback" in t && (this._requestVideoFrameCallbackId = t.requestVideoFrameCallback(u));
  }
  clone() {
    return new this.constructor(this.image).copy(this);
  }
  update() {
    const t = this.image;
    "requestVideoFrameCallback" in t === false && t.readyState >= t.HAVE_CURRENT_DATA && (this.needsUpdate = true);
  }
  dispose() {
    this._requestVideoFrameCallbackId !== 0 && (this.source.data.cancelVideoFrameCallback(this._requestVideoFrameCallbackId), this._requestVideoFrameCallbackId = 0), super.dispose();
  }
}
class wf extends vc {
  constructor(t, e, i, s, n, r, a, o) {
    super({}, t, e, i, s, n, r, a, o), this.isVideoFrameTexture = true;
  }
  update() {
  }
  clone() {
    return new this.constructor().copy(this);
  }
  setFrame(t) {
    this.image = t, this.needsUpdate = true;
  }
}
class _f extends lt {
  constructor(t, e) {
    super({ width: t, height: e }), this.isFramebufferTexture = true, this.magFilter = Bt, this.minFilter = Bt, this.generateMipmaps = false, this.needsUpdate = true;
  }
}
class xr extends lt {
  constructor(t, e, i, s, n, r, a, o, h, c, u, d) {
    super(null, r, a, o, h, c, s, n, u, d), this.isCompressedTexture = true, this.image = { width: e, height: i }, this.mipmaps = t, this.flipY = false, this.generateMipmaps = false;
  }
}
class vf extends xr {
  constructor(t, e, i, s, n, r) {
    super(t, e, i, n, r), this.isCompressedArrayTexture = true, this.image.depth = s, this.wrapR = Zt, this.layerUpdates = /* @__PURE__ */ new Set();
  }
  addLayerUpdate(t) {
    this.layerUpdates.add(t);
  }
  clearLayerUpdates() {
    this.layerUpdates.clear();
  }
}
class Sf extends xr {
  constructor(t, e, i) {
    super(void 0, t[0].width, t[0].height, e, i, sn), this.isCompressedCubeTexture = true, this.isCubeTexture = true, this.image = t;
  }
}
class Oo extends lt {
  constructor(t = [], e = sn, i, s, n, r, a, o, h, c) {
    super(t, e, i, s, n, r, a, o, h, c), this.isCubeTexture = true, this.flipY = false;
  }
  get images() {
    return this.image;
  }
  set images(t) {
    this.image = t;
  }
}
class Af extends lt {
  constructor(t, e, i, s, n, r, a, o, h) {
    super(t, e, i, s, n, r, a, o, h), this.isCanvasTexture = true, this.needsUpdate = true;
  }
}
class Sc extends lt {
  constructor(t, e, i = nn, s, n, r, a = Bt, o = Bt, h, c = Qn, u = 1) {
    if (c !== Qn && c !== Ih) throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");
    const d = { width: t, height: e, depth: u };
    super(d, s, n, r, a, o, c, i, h), this.isDepthTexture = true, this.flipY = false, this.generateMipmaps = false, this.compareFunction = null;
  }
  copy(t) {
    return super.copy(t), this.source = new Le(Object.assign({}, t.image)), this.compareFunction = t.compareFunction, this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return this.compareFunction !== null && (e.compareFunction = this.compareFunction), e;
  }
}
class Tf extends Sc {
  constructor(t, e = nn, i = sn, s, n, r = Bt, a = Bt, o, h = Qn) {
    const c = { width: t, height: t, depth: 1 }, u = [c, c, c, c, c, c];
    super(t, t, e, i, s, n, r, a, o, h), this.image = u, this.isCubeDepthTexture = true, this.isCubeTexture = true;
  }
  get images() {
    return this.image;
  }
  set images(t) {
    this.image = t;
  }
}
class Cf extends lt {
  constructor(t = null) {
    super(), this.sourceTexture = t, this.isExternalTexture = true;
  }
  copy(t) {
    return super.copy(t), this.sourceTexture = t.sourceTexture, this;
  }
}
class br extends H {
  constructor(t = 1, e = 1, i = 1, s = 1, n = 1, r = 1) {
    super(), this.type = "BoxGeometry", this.parameters = { width: t, height: e, depth: i, widthSegments: s, heightSegments: n, depthSegments: r };
    const a = this;
    s = Math.floor(s), n = Math.floor(n), r = Math.floor(r);
    const o = [], h = [], c = [], u = [];
    let d = 0, p = 0;
    f("z", "y", "x", -1, -1, i, e, t, r, n, 0), f("z", "y", "x", 1, -1, i, e, -t, r, n, 1), f("x", "z", "y", 1, 1, t, i, e, s, r, 2), f("x", "z", "y", 1, -1, t, i, -e, s, r, 3), f("x", "y", "z", 1, -1, t, e, i, s, n, 4), f("x", "y", "z", -1, -1, t, e, -i, s, n, 5), this.setIndex(o), this.setAttribute("position", new P(h, 3)), this.setAttribute("normal", new P(c, 3)), this.setAttribute("uv", new P(u, 2));
    function f(m, g, y, x, b, M, _, v, A, S, T) {
      const C = M / A, B = _ / S, O = M / 2, D = _ / 2, J = v / 2, V = A + 1, et = S + 1;
      let at = 0, Lt = 0;
      const it = new w();
      for (let ot = 0; ot < et; ot++) {
        const st = ot * B - D;
        for (let Dt = 0; Dt < V; Dt++) {
          const kt = Dt * C - O;
          it[m] = kt * x, it[g] = st * b, it[y] = J, h.push(it.x, it.y, it.z), it[m] = 0, it[g] = 0, it[y] = v > 0 ? 1 : -1, c.push(it.x, it.y, it.z), u.push(Dt / A), u.push(1 - ot / S), at += 1;
        }
      }
      for (let ot = 0; ot < S; ot++) for (let st = 0; st < A; st++) {
        const Dt = d + st + V * ot, kt = d + st + V * (ot + 1), He = d + (st + 1) + V * (ot + 1), Ci = d + (st + 1) + V * ot;
        o.push(Dt, kt, Ci), o.push(kt, He, Ci), Lt += 6;
      }
      a.addGroup(p, Lt, T), p += Lt, d += at;
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new br(t.width, t.height, t.depth, t.widthSegments, t.heightSegments, t.depthSegments);
  }
}
class Mr extends H {
  constructor(t = 1, e = 1, i = 4, s = 8, n = 1) {
    super(), this.type = "CapsuleGeometry", this.parameters = { radius: t, height: e, capSegments: i, radialSegments: s, heightSegments: n }, e = Math.max(0, e), i = Math.max(1, Math.floor(i)), s = Math.max(3, Math.floor(s)), n = Math.max(1, Math.floor(n));
    const r = [], a = [], o = [], h = [], c = e / 2, u = Math.PI / 2 * t, d = e, p = 2 * u + d, f = i * 2 + n, m = s + 1, g = new w(), y = new w();
    for (let x = 0; x <= f; x++) {
      let b = 0, M = 0, _ = 0, v = 0;
      if (x <= i) {
        const T = x / i, C = T * Math.PI / 2;
        M = -c - t * Math.cos(C), _ = t * Math.sin(C), v = -t * Math.cos(C), b = T * u;
      } else if (x <= i + n) {
        const T = (x - i) / n;
        M = -c + T * e, _ = t, v = 0, b = u + T * d;
      } else {
        const T = (x - i - n) / i, C = T * Math.PI / 2;
        M = c + t * Math.sin(C), _ = t * Math.cos(C), v = t * Math.sin(C), b = u + d + T * u;
      }
      const A = Math.max(0, Math.min(1, b / p));
      let S = 0;
      x === 0 ? S = 0.5 / s : x === f && (S = -0.5 / s);
      for (let T = 0; T <= s; T++) {
        const C = T / s, B = C * Math.PI * 2, O = Math.sin(B), D = Math.cos(B);
        y.x = -_ * D, y.y = M, y.z = _ * O, a.push(y.x, y.y, y.z), g.set(-_ * D, v, _ * O), g.normalize(), o.push(g.x, g.y, g.z), h.push(C + S, A);
      }
      if (x > 0) {
        const T = (x - 1) * m;
        for (let C = 0; C < s; C++) {
          const B = T + C, O = T + C + 1, D = x * m + C, J = x * m + C + 1;
          r.push(B, O, D), r.push(O, J, D);
        }
      }
    }
    this.setIndex(r), this.setAttribute("position", new P(a, 3)), this.setAttribute("normal", new P(o, 3)), this.setAttribute("uv", new P(h, 2));
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new Mr(t.radius, t.height, t.capSegments, t.radialSegments, t.heightSegments);
  }
}
class wr extends H {
  constructor(t = 1, e = 32, i = 0, s = Math.PI * 2) {
    super(), this.type = "CircleGeometry", this.parameters = { radius: t, segments: e, thetaStart: i, thetaLength: s }, e = Math.max(3, e);
    const n = [], r = [], a = [], o = [], h = new w(), c = new I();
    r.push(0, 0, 0), a.push(0, 0, 1), o.push(0.5, 0.5);
    for (let u = 0, d = 3; u <= e; u++, d += 3) {
      const p = i + u / e * s;
      h.x = t * Math.cos(p), h.y = t * Math.sin(p), r.push(h.x, h.y, h.z), a.push(0, 0, 1), c.x = (r[d] / t + 1) / 2, c.y = (r[d + 1] / t + 1) / 2, o.push(c.x, c.y);
    }
    for (let u = 1; u <= e; u++) n.push(u, u + 1, 0);
    this.setIndex(n), this.setAttribute("position", new P(r, 3)), this.setAttribute("normal", new P(a, 3)), this.setAttribute("uv", new P(o, 2));
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new wr(t.radius, t.segments, t.thetaStart, t.thetaLength);
  }
}
class rn extends H {
  constructor(t = 1, e = 1, i = 1, s = 32, n = 1, r = false, a = 0, o = Math.PI * 2) {
    super(), this.type = "CylinderGeometry", this.parameters = { radiusTop: t, radiusBottom: e, height: i, radialSegments: s, heightSegments: n, openEnded: r, thetaStart: a, thetaLength: o };
    const h = this;
    s = Math.floor(s), n = Math.floor(n);
    const c = [], u = [], d = [], p = [];
    let f = 0;
    const m = [], g = i / 2;
    let y = 0;
    x(), r === false && (t > 0 && b(true), e > 0 && b(false)), this.setIndex(c), this.setAttribute("position", new P(u, 3)), this.setAttribute("normal", new P(d, 3)), this.setAttribute("uv", new P(p, 2));
    function x() {
      const M = new w(), _ = new w();
      let v = 0;
      const A = (e - t) / i;
      for (let S = 0; S <= n; S++) {
        const T = [], C = S / n, B = C * (e - t) + t;
        for (let O = 0; O <= s; O++) {
          const D = O / s, J = D * o + a, V = Math.sin(J), et = Math.cos(J);
          _.x = B * V, _.y = -C * i + g, _.z = B * et, u.push(_.x, _.y, _.z), M.set(V, A, et).normalize(), d.push(M.x, M.y, M.z), p.push(D, 1 - C), T.push(f++);
        }
        m.push(T);
      }
      for (let S = 0; S < s; S++) for (let T = 0; T < n; T++) {
        const C = m[T][S], B = m[T + 1][S], O = m[T + 1][S + 1], D = m[T][S + 1];
        (t > 0 || T !== 0) && (c.push(C, B, D), v += 3), (e > 0 || T !== n - 1) && (c.push(B, O, D), v += 3);
      }
      h.addGroup(y, v, 0), y += v;
    }
    function b(M) {
      const _ = f, v = new I(), A = new w();
      let S = 0;
      const T = M === true ? t : e, C = M === true ? 1 : -1;
      for (let O = 1; O <= s; O++) u.push(0, g * C, 0), d.push(0, C, 0), p.push(0.5, 0.5), f++;
      const B = f;
      for (let O = 0; O <= s; O++) {
        const J = O / s * o + a, V = Math.cos(J), et = Math.sin(J);
        A.x = T * et, A.y = g * C, A.z = T * V, u.push(A.x, A.y, A.z), d.push(0, C, 0), v.x = V * 0.5 + 0.5, v.y = et * 0.5 * C + 0.5, p.push(v.x, v.y), f++;
      }
      for (let O = 0; O < s; O++) {
        const D = _ + O, J = B + O;
        M === true ? c.push(J, J + 1, D) : c.push(J + 1, J, D), S += 3;
      }
      h.addGroup(y, S, M === true ? 1 : 2), y += S;
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new rn(t.radiusTop, t.radiusBottom, t.height, t.radialSegments, t.heightSegments, t.openEnded, t.thetaStart, t.thetaLength);
  }
}
class an extends rn {
  constructor(t = 1, e = 1, i = 32, s = 1, n = false, r = 0, a = Math.PI * 2) {
    super(0, t, e, i, s, n, r, a), this.type = "ConeGeometry", this.parameters = { radius: t, height: e, radialSegments: i, heightSegments: s, openEnded: n, thetaStart: r, thetaLength: a };
  }
  static fromJSON(t) {
    return new an(t.radius, t.height, t.radialSegments, t.heightSegments, t.openEnded, t.thetaStart, t.thetaLength);
  }
}
class Ge extends H {
  constructor(t = [], e = [], i = 1, s = 0) {
    super(), this.type = "PolyhedronGeometry", this.parameters = { vertices: t, indices: e, radius: i, detail: s };
    const n = [], r = [];
    a(s), h(i), c(), this.setAttribute("position", new P(n, 3)), this.setAttribute("normal", new P(n.slice(), 3)), this.setAttribute("uv", new P(r, 2)), s === 0 ? this.computeVertexNormals() : this.normalizeNormals();
    function a(x) {
      const b = new w(), M = new w(), _ = new w();
      for (let v = 0; v < e.length; v += 3) p(e[v + 0], b), p(e[v + 1], M), p(e[v + 2], _), o(b, M, _, x);
    }
    function o(x, b, M, _) {
      const v = _ + 1, A = [];
      for (let S = 0; S <= v; S++) {
        A[S] = [];
        const T = x.clone().lerp(M, S / v), C = b.clone().lerp(M, S / v), B = v - S;
        for (let O = 0; O <= B; O++) O === 0 && S === v ? A[S][O] = T : A[S][O] = T.clone().lerp(C, O / B);
      }
      for (let S = 0; S < v; S++) for (let T = 0; T < 2 * (v - S) - 1; T++) {
        const C = Math.floor(T / 2);
        T % 2 === 0 ? (d(A[S][C + 1]), d(A[S + 1][C]), d(A[S][C])) : (d(A[S][C + 1]), d(A[S + 1][C + 1]), d(A[S + 1][C]));
      }
    }
    function h(x) {
      const b = new w();
      for (let M = 0; M < n.length; M += 3) b.x = n[M + 0], b.y = n[M + 1], b.z = n[M + 2], b.normalize().multiplyScalar(x), n[M + 0] = b.x, n[M + 1] = b.y, n[M + 2] = b.z;
    }
    function c() {
      const x = new w();
      for (let b = 0; b < n.length; b += 3) {
        x.x = n[b + 0], x.y = n[b + 1], x.z = n[b + 2];
        const M = g(x) / 2 / Math.PI + 0.5, _ = y(x) / Math.PI + 0.5;
        r.push(M, 1 - _);
      }
      f(), u();
    }
    function u() {
      for (let x = 0; x < r.length; x += 6) {
        const b = r[x + 0], M = r[x + 2], _ = r[x + 4], v = Math.max(b, M, _), A = Math.min(b, M, _);
        v > 0.9 && A < 0.1 && (b < 0.2 && (r[x + 0] += 1), M < 0.2 && (r[x + 2] += 1), _ < 0.2 && (r[x + 4] += 1));
      }
    }
    function d(x) {
      n.push(x.x, x.y, x.z);
    }
    function p(x, b) {
      const M = x * 3;
      b.x = t[M + 0], b.y = t[M + 1], b.z = t[M + 2];
    }
    function f() {
      const x = new w(), b = new w(), M = new w(), _ = new w(), v = new I(), A = new I(), S = new I();
      for (let T = 0, C = 0; T < n.length; T += 9, C += 6) {
        x.set(n[T + 0], n[T + 1], n[T + 2]), b.set(n[T + 3], n[T + 4], n[T + 5]), M.set(n[T + 6], n[T + 7], n[T + 8]), v.set(r[C + 0], r[C + 1]), A.set(r[C + 2], r[C + 3]), S.set(r[C + 4], r[C + 5]), _.copy(x).add(b).add(M).divideScalar(3);
        const B = g(_);
        m(v, C + 0, x, B), m(A, C + 2, b, B), m(S, C + 4, M, B);
      }
    }
    function m(x, b, M, _) {
      _ < 0 && x.x === 1 && (r[b] = x.x - 1), M.x === 0 && M.z === 0 && (r[b] = _ / 2 / Math.PI + 0.5);
    }
    function g(x) {
      return Math.atan2(x.z, -x.x);
    }
    function y(x) {
      return Math.atan2(-x.y, Math.sqrt(x.x * x.x + x.z * x.z));
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new Ge(t.vertices, t.indices, t.radius, t.detail);
  }
}
class _r extends Ge {
  constructor(t = 1, e = 0) {
    const i = (1 + Math.sqrt(5)) / 2, s = 1 / i, n = [-1, -1, -1, -1, -1, 1, -1, 1, -1, -1, 1, 1, 1, -1, -1, 1, -1, 1, 1, 1, -1, 1, 1, 1, 0, -s, -i, 0, -s, i, 0, s, -i, 0, s, i, -s, -i, 0, -s, i, 0, s, -i, 0, s, i, 0, -i, 0, -s, i, 0, -s, -i, 0, s, i, 0, s], r = [3, 11, 7, 3, 7, 15, 3, 15, 13, 7, 19, 17, 7, 17, 6, 7, 6, 15, 17, 4, 8, 17, 8, 10, 17, 10, 6, 8, 0, 16, 8, 16, 2, 8, 2, 10, 0, 12, 1, 0, 1, 18, 0, 18, 16, 6, 10, 2, 6, 2, 13, 6, 13, 15, 2, 16, 18, 2, 18, 3, 2, 3, 13, 18, 1, 9, 18, 9, 11, 18, 11, 3, 4, 14, 12, 4, 12, 0, 4, 0, 8, 11, 9, 5, 11, 5, 19, 11, 19, 7, 19, 5, 14, 19, 14, 4, 19, 4, 17, 1, 12, 14, 1, 14, 5, 1, 5, 9];
    super(n, r, t, e), this.type = "DodecahedronGeometry", this.parameters = { radius: t, detail: e };
  }
  static fromJSON(t) {
    return new _r(t.radius, t.detail);
  }
}
const zs = new w(), Bs = new w(), Dn = new w(), Fs = new It();
class Ac extends H {
  constructor(t = null, e = 1) {
    if (super(), this.type = "EdgesGeometry", this.parameters = { geometry: t, thresholdAngle: e }, t !== null) {
      const s = Math.pow(10, 4), n = Math.cos(Ve * e), r = t.getIndex(), a = t.getAttribute("position"), o = r ? r.count : a.count, h = [0, 0, 0], c = ["a", "b", "c"], u = new Array(3), d = {}, p = [];
      for (let f = 0; f < o; f += 3) {
        r ? (h[0] = r.getX(f), h[1] = r.getX(f + 1), h[2] = r.getX(f + 2)) : (h[0] = f, h[1] = f + 1, h[2] = f + 2);
        const { a: m, b: g, c: y } = Fs;
        if (m.fromBufferAttribute(a, h[0]), g.fromBufferAttribute(a, h[1]), y.fromBufferAttribute(a, h[2]), Fs.getNormal(Dn), u[0] = `${Math.round(m.x * s)},${Math.round(m.y * s)},${Math.round(m.z * s)}`, u[1] = `${Math.round(g.x * s)},${Math.round(g.y * s)},${Math.round(g.z * s)}`, u[2] = `${Math.round(y.x * s)},${Math.round(y.y * s)},${Math.round(y.z * s)}`, !(u[0] === u[1] || u[1] === u[2] || u[2] === u[0])) for (let x = 0; x < 3; x++) {
          const b = (x + 1) % 3, M = u[x], _ = u[b], v = Fs[c[x]], A = Fs[c[b]], S = `${M}_${_}`, T = `${_}_${M}`;
          T in d && d[T] ? (Dn.dot(d[T].normal) <= n && (p.push(v.x, v.y, v.z), p.push(A.x, A.y, A.z)), d[T] = null) : S in d || (d[S] = { index0: h[x], index1: h[b], normal: Dn.clone() });
        }
      }
      for (const f in d) if (d[f]) {
        const { index0: m, index1: g } = d[f];
        zs.fromBufferAttribute(a, m), Bs.fromBufferAttribute(a, g), p.push(zs.x, zs.y, zs.z), p.push(Bs.x, Bs.y, Bs.z);
      }
      this.setAttribute("position", new P(p, 3));
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
}
class te {
  constructor() {
    this.type = "Curve", this.arcLengthDivisions = 200, this.needsUpdate = false, this.cacheArcLengths = null;
  }
  getPoint() {
    N("Curve: .getPoint() not implemented.");
  }
  getPointAt(t, e) {
    const i = this.getUtoTmapping(t);
    return this.getPoint(i, e);
  }
  getPoints(t = 5) {
    const e = [];
    for (let i = 0; i <= t; i++) e.push(this.getPoint(i / t));
    return e;
  }
  getSpacedPoints(t = 5) {
    const e = [];
    for (let i = 0; i <= t; i++) e.push(this.getPointAt(i / t));
    return e;
  }
  getLength() {
    const t = this.getLengths();
    return t[t.length - 1];
  }
  getLengths(t = this.arcLengthDivisions) {
    if (this.cacheArcLengths && this.cacheArcLengths.length === t + 1 && !this.needsUpdate) return this.cacheArcLengths;
    this.needsUpdate = false;
    const e = [];
    let i, s = this.getPoint(0), n = 0;
    e.push(0);
    for (let r = 1; r <= t; r++) i = this.getPoint(r / t), n += i.distanceTo(s), e.push(n), s = i;
    return this.cacheArcLengths = e, e;
  }
  updateArcLengths() {
    this.needsUpdate = true, this.getLengths();
  }
  getUtoTmapping(t, e = null) {
    const i = this.getLengths();
    let s = 0;
    const n = i.length;
    let r;
    e ? r = e : r = t * i[n - 1];
    let a = 0, o = n - 1, h;
    for (; a <= o; ) if (s = Math.floor(a + (o - a) / 2), h = i[s] - r, h < 0) a = s + 1;
    else if (h > 0) o = s - 1;
    else {
      o = s;
      break;
    }
    if (s = o, i[s] === r) return s / (n - 1);
    const c = i[s], d = i[s + 1] - c, p = (r - c) / d;
    return (s + p) / (n - 1);
  }
  getTangent(t, e) {
    let s = t - 1e-4, n = t + 1e-4;
    s < 0 && (s = 0), n > 1 && (n = 1);
    const r = this.getPoint(s), a = this.getPoint(n), o = e || (r.isVector2 ? new I() : new w());
    return o.copy(a).sub(r).normalize(), o;
  }
  getTangentAt(t, e) {
    const i = this.getUtoTmapping(t);
    return this.getTangent(i, e);
  }
  computeFrenetFrames(t, e = false) {
    const i = new w(), s = [], n = [], r = [], a = new w(), o = new G();
    for (let p = 0; p <= t; p++) {
      const f = p / t;
      s[p] = this.getTangentAt(f, new w());
    }
    n[0] = new w(), r[0] = new w();
    let h = Number.MAX_VALUE;
    const c = Math.abs(s[0].x), u = Math.abs(s[0].y), d = Math.abs(s[0].z);
    c <= h && (h = c, i.set(1, 0, 0)), u <= h && (h = u, i.set(0, 1, 0)), d <= h && i.set(0, 0, 1), a.crossVectors(s[0], i).normalize(), n[0].crossVectors(s[0], a), r[0].crossVectors(s[0], n[0]);
    for (let p = 1; p <= t; p++) {
      if (n[p] = n[p - 1].clone(), r[p] = r[p - 1].clone(), a.crossVectors(s[p - 1], s[p]), a.length() > Number.EPSILON) {
        a.normalize();
        const f = Math.acos(L(s[p - 1].dot(s[p]), -1, 1));
        n[p].applyMatrix4(o.makeRotationAxis(a, f));
      }
      r[p].crossVectors(s[p], n[p]);
    }
    if (e === true) {
      let p = Math.acos(L(n[0].dot(n[t]), -1, 1));
      p /= t, s[0].dot(a.crossVectors(n[0], n[t])) > 0 && (p = -p);
      for (let f = 1; f <= t; f++) n[f].applyMatrix4(o.makeRotationAxis(s[f], p * f)), r[f].crossVectors(s[f], n[f]);
    }
    return { tangents: s, normals: n, binormals: r };
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    return this.arcLengthDivisions = t.arcLengthDivisions, this;
  }
  toJSON() {
    const t = { metadata: { version: 4.7, type: "Curve", generator: "Curve.toJSON" } };
    return t.arcLengthDivisions = this.arcLengthDivisions, t.type = this.type, t;
  }
  fromJSON(t) {
    return this.arcLengthDivisions = t.arcLengthDivisions, this;
  }
}
class vr extends te {
  constructor(t = 0, e = 0, i = 1, s = 1, n = 0, r = Math.PI * 2, a = false, o = 0) {
    super(), this.isEllipseCurve = true, this.type = "EllipseCurve", this.aX = t, this.aY = e, this.xRadius = i, this.yRadius = s, this.aStartAngle = n, this.aEndAngle = r, this.aClockwise = a, this.aRotation = o;
  }
  getPoint(t, e = new I()) {
    const i = e, s = Math.PI * 2;
    let n = this.aEndAngle - this.aStartAngle;
    const r = Math.abs(n) < Number.EPSILON;
    for (; n < 0; ) n += s;
    for (; n > s; ) n -= s;
    n < Number.EPSILON && (r ? n = 0 : n = s), this.aClockwise === true && !r && (n === s ? n = -s : n = n - s);
    const a = this.aStartAngle + t * n;
    let o = this.aX + this.xRadius * Math.cos(a), h = this.aY + this.yRadius * Math.sin(a);
    if (this.aRotation !== 0) {
      const c = Math.cos(this.aRotation), u = Math.sin(this.aRotation), d = o - this.aX, p = h - this.aY;
      o = d * c - p * u + this.aX, h = d * u + p * c + this.aY;
    }
    return i.set(o, h);
  }
  copy(t) {
    return super.copy(t), this.aX = t.aX, this.aY = t.aY, this.xRadius = t.xRadius, this.yRadius = t.yRadius, this.aStartAngle = t.aStartAngle, this.aEndAngle = t.aEndAngle, this.aClockwise = t.aClockwise, this.aRotation = t.aRotation, this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.aX = this.aX, t.aY = this.aY, t.xRadius = this.xRadius, t.yRadius = this.yRadius, t.aStartAngle = this.aStartAngle, t.aEndAngle = this.aEndAngle, t.aClockwise = this.aClockwise, t.aRotation = this.aRotation, t;
  }
  fromJSON(t) {
    return super.fromJSON(t), this.aX = t.aX, this.aY = t.aY, this.xRadius = t.xRadius, this.yRadius = t.yRadius, this.aStartAngle = t.aStartAngle, this.aEndAngle = t.aEndAngle, this.aClockwise = t.aClockwise, this.aRotation = t.aRotation, this;
  }
}
class Tc extends vr {
  constructor(t, e, i, s, n, r) {
    super(t, e, i, i, s, n, r), this.isArcCurve = true, this.type = "ArcCurve";
  }
}
function Sr() {
  let l = 0, t = 0, e = 0, i = 0;
  function s(n, r, a, o) {
    l = n, t = a, e = -3 * n + 3 * r - 2 * a - o, i = 2 * n - 2 * r + a + o;
  }
  return { initCatmullRom: function(n, r, a, o, h) {
    s(r, a, h * (a - n), h * (o - r));
  }, initNonuniformCatmullRom: function(n, r, a, o, h, c, u) {
    let d = (r - n) / h - (a - n) / (h + c) + (a - r) / c, p = (a - r) / c - (o - r) / (c + u) + (o - a) / u;
    d *= c, p *= c, s(r, a, d, p);
  }, calc: function(n) {
    const r = n * n, a = r * n;
    return l + t * n + e * r + i * a;
  } };
}
const ks = new w(), Vn = new Sr(), Un = new Sr(), Wn = new Sr();
class Cc extends te {
  constructor(t = [], e = false, i = "centripetal", s = 0.5) {
    super(), this.isCatmullRomCurve3 = true, this.type = "CatmullRomCurve3", this.points = t, this.closed = e, this.curveType = i, this.tension = s;
  }
  getPoint(t, e = new w()) {
    const i = e, s = this.points, n = s.length, r = (n - (this.closed ? 0 : 1)) * t;
    let a = Math.floor(r), o = r - a;
    this.closed ? a += a > 0 ? 0 : (Math.floor(Math.abs(a) / n) + 1) * n : o === 0 && a === n - 1 && (a = n - 2, o = 1);
    let h, c;
    this.closed || a > 0 ? h = s[(a - 1) % n] : (ks.subVectors(s[0], s[1]).add(s[0]), h = ks);
    const u = s[a % n], d = s[(a + 1) % n];
    if (this.closed || a + 2 < n ? c = s[(a + 2) % n] : (ks.subVectors(s[n - 1], s[n - 2]).add(s[n - 1]), c = ks), this.curveType === "centripetal" || this.curveType === "chordal") {
      const p = this.curveType === "chordal" ? 0.5 : 0.25;
      let f = Math.pow(h.distanceToSquared(u), p), m = Math.pow(u.distanceToSquared(d), p), g = Math.pow(d.distanceToSquared(c), p);
      m < 1e-4 && (m = 1), f < 1e-4 && (f = m), g < 1e-4 && (g = m), Vn.initNonuniformCatmullRom(h.x, u.x, d.x, c.x, f, m, g), Un.initNonuniformCatmullRom(h.y, u.y, d.y, c.y, f, m, g), Wn.initNonuniformCatmullRom(h.z, u.z, d.z, c.z, f, m, g);
    } else this.curveType === "catmullrom" && (Vn.initCatmullRom(h.x, u.x, d.x, c.x, this.tension), Un.initCatmullRom(h.y, u.y, d.y, c.y, this.tension), Wn.initCatmullRom(h.z, u.z, d.z, c.z, this.tension));
    return i.set(Vn.calc(o), Un.calc(o), Wn.calc(o)), i;
  }
  copy(t) {
    super.copy(t), this.points = [];
    for (let e = 0, i = t.points.length; e < i; e++) {
      const s = t.points[e];
      this.points.push(s.clone());
    }
    return this.closed = t.closed, this.curveType = t.curveType, this.tension = t.tension, this;
  }
  toJSON() {
    const t = super.toJSON();
    t.points = [];
    for (let e = 0, i = this.points.length; e < i; e++) {
      const s = this.points[e];
      t.points.push(s.toArray());
    }
    return t.closed = this.closed, t.curveType = this.curveType, t.tension = this.tension, t;
  }
  fromJSON(t) {
    super.fromJSON(t), this.points = [];
    for (let e = 0, i = t.points.length; e < i; e++) {
      const s = t.points[e];
      this.points.push(new w().fromArray(s));
    }
    return this.closed = t.closed, this.curveType = t.curveType, this.tension = t.tension, this;
  }
}
function Ja(l, t, e, i, s) {
  const n = (i - t) * 0.5, r = (s - e) * 0.5, a = l * l, o = l * a;
  return (2 * e - 2 * i + n + r) * o + (-3 * e + 3 * i - 2 * n - r) * a + n * l + e;
}
function Ic(l, t) {
  const e = 1 - l;
  return e * e * t;
}
function zc(l, t) {
  return 2 * (1 - l) * l * t;
}
function Bc(l, t) {
  return l * l * t;
}
function Gi(l, t, e, i) {
  return Ic(l, t) + zc(l, e) + Bc(l, i);
}
function Fc(l, t) {
  const e = 1 - l;
  return e * e * e * t;
}
function kc(l, t) {
  const e = 1 - l;
  return 3 * e * e * l * t;
}
function Pc(l, t) {
  return 3 * (1 - l) * l * l * t;
}
function Rc(l, t) {
  return l * l * l * t;
}
function qi(l, t, e, i, s) {
  return Fc(l, t) + kc(l, e) + Pc(l, i) + Rc(l, s);
}
class Eo extends te {
  constructor(t = new I(), e = new I(), i = new I(), s = new I()) {
    super(), this.isCubicBezierCurve = true, this.type = "CubicBezierCurve", this.v0 = t, this.v1 = e, this.v2 = i, this.v3 = s;
  }
  getPoint(t, e = new I()) {
    const i = e, s = this.v0, n = this.v1, r = this.v2, a = this.v3;
    return i.set(qi(t, s.x, n.x, r.x, a.x), qi(t, s.y, n.y, r.y, a.y)), i;
  }
  copy(t) {
    return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this.v3.copy(t.v3), this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t.v3 = this.v3.toArray(), t;
  }
  fromJSON(t) {
    return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this.v3.fromArray(t.v3), this;
  }
}
class Oc extends te {
  constructor(t = new w(), e = new w(), i = new w(), s = new w()) {
    super(), this.isCubicBezierCurve3 = true, this.type = "CubicBezierCurve3", this.v0 = t, this.v1 = e, this.v2 = i, this.v3 = s;
  }
  getPoint(t, e = new w()) {
    const i = e, s = this.v0, n = this.v1, r = this.v2, a = this.v3;
    return i.set(qi(t, s.x, n.x, r.x, a.x), qi(t, s.y, n.y, r.y, a.y), qi(t, s.z, n.z, r.z, a.z)), i;
  }
  copy(t) {
    return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this.v3.copy(t.v3), this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t.v3 = this.v3.toArray(), t;
  }
  fromJSON(t) {
    return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this.v3.fromArray(t.v3), this;
  }
}
class No extends te {
  constructor(t = new I(), e = new I()) {
    super(), this.isLineCurve = true, this.type = "LineCurve", this.v1 = t, this.v2 = e;
  }
  getPoint(t, e = new I()) {
    const i = e;
    return t === 1 ? i.copy(this.v2) : (i.copy(this.v2).sub(this.v1), i.multiplyScalar(t).add(this.v1)), i;
  }
  getPointAt(t, e) {
    return this.getPoint(t, e);
  }
  getTangent(t, e = new I()) {
    return e.subVectors(this.v2, this.v1).normalize();
  }
  getTangentAt(t, e) {
    return this.getTangent(t, e);
  }
  copy(t) {
    return super.copy(t), this.v1.copy(t.v1), this.v2.copy(t.v2), this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t;
  }
  fromJSON(t) {
    return super.fromJSON(t), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this;
  }
}
class Ec extends te {
  constructor(t = new w(), e = new w()) {
    super(), this.isLineCurve3 = true, this.type = "LineCurve3", this.v1 = t, this.v2 = e;
  }
  getPoint(t, e = new w()) {
    const i = e;
    return t === 1 ? i.copy(this.v2) : (i.copy(this.v2).sub(this.v1), i.multiplyScalar(t).add(this.v1)), i;
  }
  getPointAt(t, e) {
    return this.getPoint(t, e);
  }
  getTangent(t, e = new w()) {
    return e.subVectors(this.v2, this.v1).normalize();
  }
  getTangentAt(t, e) {
    return this.getTangent(t, e);
  }
  copy(t) {
    return super.copy(t), this.v1.copy(t.v1), this.v2.copy(t.v2), this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t;
  }
  fromJSON(t) {
    return super.fromJSON(t), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this;
  }
}
class Lo extends te {
  constructor(t = new I(), e = new I(), i = new I()) {
    super(), this.isQuadraticBezierCurve = true, this.type = "QuadraticBezierCurve", this.v0 = t, this.v1 = e, this.v2 = i;
  }
  getPoint(t, e = new I()) {
    const i = e, s = this.v0, n = this.v1, r = this.v2;
    return i.set(Gi(t, s.x, n.x, r.x), Gi(t, s.y, n.y, r.y)), i;
  }
  copy(t) {
    return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t;
  }
  fromJSON(t) {
    return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this;
  }
}
class Do extends te {
  constructor(t = new w(), e = new w(), i = new w()) {
    super(), this.isQuadraticBezierCurve3 = true, this.type = "QuadraticBezierCurve3", this.v0 = t, this.v1 = e, this.v2 = i;
  }
  getPoint(t, e = new w()) {
    const i = e, s = this.v0, n = this.v1, r = this.v2;
    return i.set(Gi(t, s.x, n.x, r.x), Gi(t, s.y, n.y, r.y), Gi(t, s.z, n.z, r.z)), i;
  }
  copy(t) {
    return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t;
  }
  fromJSON(t) {
    return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this;
  }
}
class Vo extends te {
  constructor(t = []) {
    super(), this.isSplineCurve = true, this.type = "SplineCurve", this.points = t;
  }
  getPoint(t, e = new I()) {
    const i = e, s = this.points, n = (s.length - 1) * t, r = Math.floor(n), a = n - r, o = s[r === 0 ? r : r - 1], h = s[r], c = s[r > s.length - 2 ? s.length - 1 : r + 1], u = s[r > s.length - 3 ? s.length - 1 : r + 2];
    return i.set(Ja(a, o.x, h.x, c.x, u.x), Ja(a, o.y, h.y, c.y, u.y)), i;
  }
  copy(t) {
    super.copy(t), this.points = [];
    for (let e = 0, i = t.points.length; e < i; e++) {
      const s = t.points[e];
      this.points.push(s.clone());
    }
    return this;
  }
  toJSON() {
    const t = super.toJSON();
    t.points = [];
    for (let e = 0, i = this.points.length; e < i; e++) {
      const s = this.points[e];
      t.points.push(s.toArray());
    }
    return t;
  }
  fromJSON(t) {
    super.fromJSON(t), this.points = [];
    for (let e = 0, i = t.points.length; e < i; e++) {
      const s = t.points[e];
      this.points.push(new I().fromArray(s));
    }
    return this;
  }
}
var js = Object.freeze({ __proto__: null, ArcCurve: Tc, CatmullRomCurve3: Cc, CubicBezierCurve: Eo, CubicBezierCurve3: Oc, EllipseCurve: vr, LineCurve: No, LineCurve3: Ec, QuadraticBezierCurve: Lo, QuadraticBezierCurve3: Do, SplineCurve: Vo });
class Nc extends te {
  constructor() {
    super(), this.type = "CurvePath", this.curves = [], this.autoClose = false;
  }
  add(t) {
    this.curves.push(t);
  }
  closePath() {
    const t = this.curves[0].getPoint(0), e = this.curves[this.curves.length - 1].getPoint(1);
    if (!t.equals(e)) {
      const i = t.isVector2 === true ? "LineCurve" : "LineCurve3";
      this.curves.push(new js[i](e, t));
    }
    return this;
  }
  getPoint(t, e) {
    const i = t * this.getLength(), s = this.getCurveLengths();
    let n = 0;
    for (; n < s.length; ) {
      if (s[n] >= i) {
        const r = s[n] - i, a = this.curves[n], o = a.getLength(), h = o === 0 ? 0 : 1 - r / o;
        return a.getPointAt(h, e);
      }
      n++;
    }
    return null;
  }
  getLength() {
    const t = this.getCurveLengths();
    return t[t.length - 1];
  }
  updateArcLengths() {
    this.needsUpdate = true, this.cacheLengths = null, this.getCurveLengths();
  }
  getCurveLengths() {
    if (this.cacheLengths && this.cacheLengths.length === this.curves.length) return this.cacheLengths;
    const t = [];
    let e = 0;
    for (let i = 0, s = this.curves.length; i < s; i++) e += this.curves[i].getLength(), t.push(e);
    return this.cacheLengths = t, t;
  }
  getSpacedPoints(t = 40) {
    const e = [];
    for (let i = 0; i <= t; i++) e.push(this.getPoint(i / t));
    return this.autoClose && e.push(e[0]), e;
  }
  getPoints(t = 12) {
    const e = [];
    let i;
    for (let s = 0, n = this.curves; s < n.length; s++) {
      const r = n[s], a = r.isEllipseCurve ? t * 2 : r.isLineCurve || r.isLineCurve3 ? 1 : r.isSplineCurve ? t * r.points.length : t, o = r.getPoints(a);
      for (let h = 0; h < o.length; h++) {
        const c = o[h];
        i && i.equals(c) || (e.push(c), i = c);
      }
    }
    return this.autoClose && e.length > 1 && !e[e.length - 1].equals(e[0]) && e.push(e[0]), e;
  }
  copy(t) {
    super.copy(t), this.curves = [];
    for (let e = 0, i = t.curves.length; e < i; e++) {
      const s = t.curves[e];
      this.curves.push(s.clone());
    }
    return this.autoClose = t.autoClose, this;
  }
  toJSON() {
    const t = super.toJSON();
    t.autoClose = this.autoClose, t.curves = [];
    for (let e = 0, i = this.curves.length; e < i; e++) {
      const s = this.curves[e];
      t.curves.push(s.toJSON());
    }
    return t;
  }
  fromJSON(t) {
    super.fromJSON(t), this.autoClose = t.autoClose, this.curves = [];
    for (let e = 0, i = t.curves.length; e < i; e++) {
      const s = t.curves[e];
      this.curves.push(new js[s.type]().fromJSON(s));
    }
    return this;
  }
}
class er extends Nc {
  constructor(t) {
    super(), this.type = "Path", this.currentPoint = new I(), t && this.setFromPoints(t);
  }
  setFromPoints(t) {
    this.moveTo(t[0].x, t[0].y);
    for (let e = 1, i = t.length; e < i; e++) this.lineTo(t[e].x, t[e].y);
    return this;
  }
  moveTo(t, e) {
    return this.currentPoint.set(t, e), this;
  }
  lineTo(t, e) {
    const i = new No(this.currentPoint.clone(), new I(t, e));
    return this.curves.push(i), this.currentPoint.set(t, e), this;
  }
  quadraticCurveTo(t, e, i, s) {
    const n = new Lo(this.currentPoint.clone(), new I(t, e), new I(i, s));
    return this.curves.push(n), this.currentPoint.set(i, s), this;
  }
  bezierCurveTo(t, e, i, s, n, r) {
    const a = new Eo(this.currentPoint.clone(), new I(t, e), new I(i, s), new I(n, r));
    return this.curves.push(a), this.currentPoint.set(n, r), this;
  }
  splineThru(t) {
    const e = [this.currentPoint.clone()].concat(t), i = new Vo(e);
    return this.curves.push(i), this.currentPoint.copy(t[t.length - 1]), this;
  }
  arc(t, e, i, s, n, r) {
    const a = this.currentPoint.x, o = this.currentPoint.y;
    return this.absarc(t + a, e + o, i, s, n, r), this;
  }
  absarc(t, e, i, s, n, r) {
    return this.absellipse(t, e, i, i, s, n, r), this;
  }
  ellipse(t, e, i, s, n, r, a, o) {
    const h = this.currentPoint.x, c = this.currentPoint.y;
    return this.absellipse(t + h, e + c, i, s, n, r, a, o), this;
  }
  absellipse(t, e, i, s, n, r, a, o) {
    const h = new vr(t, e, i, s, n, r, a, o);
    if (this.curves.length > 0) {
      const u = h.getPoint(0);
      u.equals(this.currentPoint) || this.lineTo(u.x, u.y);
    }
    this.curves.push(h);
    const c = h.getPoint(1);
    return this.currentPoint.copy(c), this;
  }
  copy(t) {
    return super.copy(t), this.currentPoint.copy(t.currentPoint), this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.currentPoint = this.currentPoint.toArray(), t;
  }
  fromJSON(t) {
    return super.fromJSON(t), this.currentPoint.fromArray(t.currentPoint), this;
  }
}
class xi extends er {
  constructor(t) {
    super(t), this.uuid = zt(), this.type = "Shape", this.holes = [];
  }
  getPointsHoles(t) {
    const e = [];
    for (let i = 0, s = this.holes.length; i < s; i++) e[i] = this.holes[i].getPoints(t);
    return e;
  }
  extractPoints(t) {
    return { shape: this.getPoints(t), holes: this.getPointsHoles(t) };
  }
  copy(t) {
    super.copy(t), this.holes = [];
    for (let e = 0, i = t.holes.length; e < i; e++) {
      const s = t.holes[e];
      this.holes.push(s.clone());
    }
    return this;
  }
  toJSON() {
    const t = super.toJSON();
    t.uuid = this.uuid, t.holes = [];
    for (let e = 0, i = this.holes.length; e < i; e++) {
      const s = this.holes[e];
      t.holes.push(s.toJSON());
    }
    return t;
  }
  fromJSON(t) {
    super.fromJSON(t), this.uuid = t.uuid, this.holes = [];
    for (let e = 0, i = t.holes.length; e < i; e++) {
      const s = t.holes[e];
      this.holes.push(new er().fromJSON(s));
    }
    return this;
  }
}
function Lc(l, t, e = 2) {
  const i = t && t.length, s = i ? t[0] * e : l.length;
  let n = Uo(l, 0, s, e, true);
  const r = [];
  if (!n || n.next === n.prev) return r;
  let a, o, h;
  if (i && (n = Gc(l, t, n, e)), l.length > 80 * e) {
    a = l[0], o = l[1];
    let c = a, u = o;
    for (let d = e; d < s; d += e) {
      const p = l[d], f = l[d + 1];
      p < a && (a = p), f < o && (o = f), p > c && (c = p), f > u && (u = f);
    }
    h = Math.max(c - a, u - o), h = h !== 0 ? 32767 / h : 0;
  }
  return Zi(n, r, e, a, o, h, 0), r;
}
function Uo(l, t, e, i, s) {
  let n;
  if (s === tu(l, t, e, i) > 0) for (let r = t; r < e; r += i) n = Xa(r / i | 0, l[r], l[r + 1], n);
  else for (let r = e - i; r >= t; r -= i) n = Xa(r / i | 0, l[r], l[r + 1], n);
  return n && _i(n, n.next) && ($i(n), n = n.next), n;
}
function We(l, t) {
  if (!l) return l;
  t || (t = l);
  let e = l, i;
  do
    if (i = false, !e.steiner && (_i(e, e.next) || K(e.prev, e, e.next) === 0)) {
      if ($i(e), e = t = e.prev, e === e.next) break;
      i = true;
    } else e = e.next;
  while (i || e !== t);
  return t;
}
function Zi(l, t, e, i, s, n, r) {
  if (!l) return;
  !r && n && Zc(l, i, s, n);
  let a = l;
  for (; l.prev !== l.next; ) {
    const o = l.prev, h = l.next;
    if (n ? Vc(l, i, s, n) : Dc(l)) {
      t.push(o.i, l.i, h.i), $i(l), l = h.next, a = h.next;
      continue;
    }
    if (l = h, l === a) {
      r ? r === 1 ? (l = Uc(We(l), t), Zi(l, t, e, i, s, n, 2)) : r === 2 && Wc(l, t, e, i, s, n) : Zi(We(l), t, e, i, s, n, 1);
      break;
    }
  }
}
function Dc(l) {
  const t = l.prev, e = l, i = l.next;
  if (K(t, e, i) >= 0) return false;
  const s = t.x, n = e.x, r = i.x, a = t.y, o = e.y, h = i.y, c = Math.min(s, n, r), u = Math.min(a, o, h), d = Math.max(s, n, r), p = Math.max(a, o, h);
  let f = i.next;
  for (; f !== t; ) {
    if (f.x >= c && f.x <= d && f.y >= u && f.y <= p && Ui(s, a, n, o, r, h, f.x, f.y) && K(f.prev, f, f.next) >= 0) return false;
    f = f.next;
  }
  return true;
}
function Vc(l, t, e, i) {
  const s = l.prev, n = l, r = l.next;
  if (K(s, n, r) >= 0) return false;
  const a = s.x, o = n.x, h = r.x, c = s.y, u = n.y, d = r.y, p = Math.min(a, o, h), f = Math.min(c, u, d), m = Math.max(a, o, h), g = Math.max(c, u, d), y = ir(p, f, t, e, i), x = ir(m, g, t, e, i);
  let b = l.prevZ, M = l.nextZ;
  for (; b && b.z >= y && M && M.z <= x; ) {
    if (b.x >= p && b.x <= m && b.y >= f && b.y <= g && b !== s && b !== r && Ui(a, c, o, u, h, d, b.x, b.y) && K(b.prev, b, b.next) >= 0 || (b = b.prevZ, M.x >= p && M.x <= m && M.y >= f && M.y <= g && M !== s && M !== r && Ui(a, c, o, u, h, d, M.x, M.y) && K(M.prev, M, M.next) >= 0)) return false;
    M = M.nextZ;
  }
  for (; b && b.z >= y; ) {
    if (b.x >= p && b.x <= m && b.y >= f && b.y <= g && b !== s && b !== r && Ui(a, c, o, u, h, d, b.x, b.y) && K(b.prev, b, b.next) >= 0) return false;
    b = b.prevZ;
  }
  for (; M && M.z <= x; ) {
    if (M.x >= p && M.x <= m && M.y >= f && M.y <= g && M !== s && M !== r && Ui(a, c, o, u, h, d, M.x, M.y) && K(M.prev, M, M.next) >= 0) return false;
    M = M.nextZ;
  }
  return true;
}
function Uc(l, t) {
  let e = l;
  do {
    const i = e.prev, s = e.next.next;
    !_i(i, s) && Go(i, e, e.next, s) && Yi(i, s) && Yi(s, i) && (t.push(i.i, e.i, s.i), $i(e), $i(e.next), e = l = s), e = e.next;
  } while (e !== l);
  return We(e);
}
function Wc(l, t, e, i, s, n) {
  let r = l;
  do {
    let a = r.next.next;
    for (; a !== r.prev; ) {
      if (r.i !== a.i && jc(r, a)) {
        let o = qo(r, a);
        r = We(r, r.next), o = We(o, o.next), Zi(r, t, e, i, s, n, 0), Zi(o, t, e, i, s, n, 0);
        return;
      }
      a = a.next;
    }
    r = r.next;
  } while (r !== l);
}
function Gc(l, t, e, i) {
  const s = [];
  for (let n = 0, r = t.length; n < r; n++) {
    const a = t[n] * i, o = n < r - 1 ? t[n + 1] * i : l.length, h = Uo(l, a, o, i, false);
    h === h.next && (h.steiner = true), s.push($c(h));
  }
  s.sort(qc);
  for (let n = 0; n < s.length; n++) e = Hc(s[n], e);
  return e;
}
function qc(l, t) {
  let e = l.x - t.x;
  if (e === 0 && (e = l.y - t.y, e === 0)) {
    const i = (l.next.y - l.y) / (l.next.x - l.x), s = (t.next.y - t.y) / (t.next.x - t.x);
    e = i - s;
  }
  return e;
}
function Hc(l, t) {
  const e = Jc(l, t);
  if (!e) return t;
  const i = qo(e, l);
  return We(i, i.next), We(e, e.next);
}
function Jc(l, t) {
  let e = t;
  const i = l.x, s = l.y;
  let n = -1 / 0, r;
  if (_i(l, e)) return e;
  do {
    if (_i(l, e.next)) return e.next;
    if (s <= e.y && s >= e.next.y && e.next.y !== e.y) {
      const u = e.x + (s - e.y) * (e.next.x - e.x) / (e.next.y - e.y);
      if (u <= i && u > n && (n = u, r = e.x < e.next.x ? e : e.next, u === i)) return r;
    }
    e = e.next;
  } while (e !== t);
  if (!r) return null;
  const a = r, o = r.x, h = r.y;
  let c = 1 / 0;
  e = r;
  do {
    if (i >= e.x && e.x >= o && i !== e.x && Wo(s < h ? i : n, s, o, h, s < h ? n : i, s, e.x, e.y)) {
      const u = Math.abs(s - e.y) / (i - e.x);
      Yi(e, l) && (u < c || u === c && (e.x > r.x || e.x === r.x && Xc(r, e))) && (r = e, c = u);
    }
    e = e.next;
  } while (e !== a);
  return r;
}
function Xc(l, t) {
  return K(l.prev, l, t.prev) < 0 && K(t.next, l, l.next) < 0;
}
function Zc(l, t, e, i) {
  let s = l;
  do
    s.z === 0 && (s.z = ir(s.x, s.y, t, e, i)), s.prevZ = s.prev, s.nextZ = s.next, s = s.next;
  while (s !== l);
  s.prevZ.nextZ = null, s.prevZ = null, Yc(s);
}
function Yc(l) {
  let t, e = 1;
  do {
    let i = l, s;
    l = null;
    let n = null;
    for (t = 0; i; ) {
      t++;
      let r = i, a = 0;
      for (let h = 0; h < e && (a++, r = r.nextZ, !!r); h++) ;
      let o = e;
      for (; a > 0 || o > 0 && r; ) a !== 0 && (o === 0 || !r || i.z <= r.z) ? (s = i, i = i.nextZ, a--) : (s = r, r = r.nextZ, o--), n ? n.nextZ = s : l = s, s.prevZ = n, n = s;
      i = r;
    }
    n.nextZ = null, e *= 2;
  } while (t > 1);
  return l;
}
function ir(l, t, e, i, s) {
  return l = (l - e) * s | 0, t = (t - i) * s | 0, l = (l | l << 8) & 16711935, l = (l | l << 4) & 252645135, l = (l | l << 2) & 858993459, l = (l | l << 1) & 1431655765, t = (t | t << 8) & 16711935, t = (t | t << 4) & 252645135, t = (t | t << 2) & 858993459, t = (t | t << 1) & 1431655765, l | t << 1;
}
function $c(l) {
  let t = l, e = l;
  do
    (t.x < e.x || t.x === e.x && t.y < e.y) && (e = t), t = t.next;
  while (t !== l);
  return e;
}
function Wo(l, t, e, i, s, n, r, a) {
  return (s - r) * (t - a) >= (l - r) * (n - a) && (l - r) * (i - a) >= (e - r) * (t - a) && (e - r) * (n - a) >= (s - r) * (i - a);
}
function Ui(l, t, e, i, s, n, r, a) {
  return !(l === r && t === a) && Wo(l, t, e, i, s, n, r, a);
}
function jc(l, t) {
  return l.next.i !== t.i && l.prev.i !== t.i && !Qc(l, t) && (Yi(l, t) && Yi(t, l) && Kc(l, t) && (K(l.prev, l, t.prev) || K(l, t.prev, t)) || _i(l, t) && K(l.prev, l, l.next) > 0 && K(t.prev, t, t.next) > 0);
}
function K(l, t, e) {
  return (t.y - l.y) * (e.x - t.x) - (t.x - l.x) * (e.y - t.y);
}
function _i(l, t) {
  return l.x === t.x && l.y === t.y;
}
function Go(l, t, e, i) {
  const s = Rs(K(l, t, e)), n = Rs(K(l, t, i)), r = Rs(K(e, i, l)), a = Rs(K(e, i, t));
  return !!(s !== n && r !== a || s === 0 && Ps(l, e, t) || n === 0 && Ps(l, i, t) || r === 0 && Ps(e, l, i) || a === 0 && Ps(e, t, i));
}
function Ps(l, t, e) {
  return t.x <= Math.max(l.x, e.x) && t.x >= Math.min(l.x, e.x) && t.y <= Math.max(l.y, e.y) && t.y >= Math.min(l.y, e.y);
}
function Rs(l) {
  return l > 0 ? 1 : l < 0 ? -1 : 0;
}
function Qc(l, t) {
  let e = l;
  do {
    if (e.i !== l.i && e.next.i !== l.i && e.i !== t.i && e.next.i !== t.i && Go(e, e.next, l, t)) return true;
    e = e.next;
  } while (e !== l);
  return false;
}
function Yi(l, t) {
  return K(l.prev, l, l.next) < 0 ? K(l, t, l.next) >= 0 && K(l, l.prev, t) >= 0 : K(l, t, l.prev) < 0 || K(l, l.next, t) < 0;
}
function Kc(l, t) {
  let e = l, i = false;
  const s = (l.x + t.x) / 2, n = (l.y + t.y) / 2;
  do
    e.y > n != e.next.y > n && e.next.y !== e.y && s < (e.next.x - e.x) * (n - e.y) / (e.next.y - e.y) + e.x && (i = !i), e = e.next;
  while (e !== l);
  return i;
}
function qo(l, t) {
  const e = sr(l.i, l.x, l.y), i = sr(t.i, t.x, t.y), s = l.next, n = t.prev;
  return l.next = t, t.prev = l, e.next = s, s.prev = e, i.next = e, e.prev = i, n.next = i, i.prev = n, i;
}
function Xa(l, t, e, i) {
  const s = sr(l, t, e);
  return i ? (s.next = i.next, s.prev = i, i.next.prev = s, i.next = s) : (s.prev = s, s.next = s), s;
}
function $i(l) {
  l.next.prev = l.prev, l.prev.next = l.next, l.prevZ && (l.prevZ.nextZ = l.nextZ), l.nextZ && (l.nextZ.prevZ = l.prevZ);
}
function sr(l, t, e) {
  return { i: l, x: t, y: e, prev: null, next: null, z: 0, prevZ: null, nextZ: null, steiner: false };
}
function tu(l, t, e, i) {
  let s = 0;
  for (let n = t, r = e - i; n < e; n += i) s += (l[r] - l[n]) * (l[n + 1] + l[r + 1]), r = n;
  return s;
}
class eu {
  static triangulate(t, e, i = 2) {
    return Lc(t, e, i);
  }
}
class $t {
  static area(t) {
    const e = t.length;
    let i = 0;
    for (let s = e - 1, n = 0; n < e; s = n++) i += t[s].x * t[n].y - t[n].x * t[s].y;
    return i * 0.5;
  }
  static isClockWise(t) {
    return $t.area(t) < 0;
  }
  static triangulateShape(t, e) {
    const i = [], s = [], n = [];
    Za(t), Ya(i, t);
    let r = t.length;
    e.forEach(Za);
    for (let o = 0; o < e.length; o++) s.push(r), r += e[o].length, Ya(i, e[o]);
    const a = eu.triangulate(i, s);
    for (let o = 0; o < a.length; o += 3) n.push(a.slice(o, o + 3));
    return n;
  }
}
function Za(l) {
  const t = l.length;
  t > 2 && l[t - 1].equals(l[0]) && l.pop();
}
function Ya(l, t) {
  for (let e = 0; e < t.length; e++) l.push(t[e].x), l.push(t[e].y);
}
class Ar extends H {
  constructor(t = new xi([new I(0.5, 0.5), new I(-0.5, 0.5), new I(-0.5, -0.5), new I(0.5, -0.5)]), e = {}) {
    super(), this.type = "ExtrudeGeometry", this.parameters = { shapes: t, options: e }, t = Array.isArray(t) ? t : [t];
    const i = this, s = [], n = [];
    for (let a = 0, o = t.length; a < o; a++) {
      const h = t[a];
      r(h);
    }
    this.setAttribute("position", new P(s, 3)), this.setAttribute("uv", new P(n, 2)), this.computeVertexNormals();
    function r(a) {
      const o = [], h = e.curveSegments !== void 0 ? e.curveSegments : 12, c = e.steps !== void 0 ? e.steps : 1, u = e.depth !== void 0 ? e.depth : 1;
      let d = e.bevelEnabled !== void 0 ? e.bevelEnabled : true, p = e.bevelThickness !== void 0 ? e.bevelThickness : 0.2, f = e.bevelSize !== void 0 ? e.bevelSize : p - 0.1, m = e.bevelOffset !== void 0 ? e.bevelOffset : 0, g = e.bevelSegments !== void 0 ? e.bevelSegments : 3;
      const y = e.extrudePath, x = e.UVGenerator !== void 0 ? e.UVGenerator : iu;
      let b, M = false, _, v, A, S;
      if (y) {
        b = y.getSpacedPoints(c), M = true, d = false;
        const z = y.isCatmullRomCurve3 ? y.closed : false;
        _ = y.computeFrenetFrames(c, z), v = new w(), A = new w(), S = new w();
      }
      d || (g = 0, p = 0, f = 0, m = 0);
      const T = a.extractPoints(h);
      let C = T.shape;
      const B = T.holes;
      if (!$t.isClockWise(C)) {
        C = C.reverse();
        for (let z = 0, F = B.length; z < F; z++) {
          const k = B[z];
          $t.isClockWise(k) && (B[z] = k.reverse());
        }
      }
      function D(z) {
        const k = 10000000000000001e-36;
        let E = z[0];
        for (let R = 1; R <= z.length; R++) {
          const X = R % z.length, q = z[X], j = q.x - E.x, Q = q.y - E.y, ct = j * j + Q * Q, St = Math.max(Math.abs(q.x), Math.abs(q.y), Math.abs(E.x), Math.abs(E.y)), Ae = k * St * St;
          if (ct <= Ae) {
            z.splice(X, 1), R--;
            continue;
          }
          E = q;
        }
      }
      D(C), B.forEach(D);
      const J = B.length, V = C;
      for (let z = 0; z < J; z++) {
        const F = B[z];
        C = C.concat(F);
      }
      function et(z, F, k) {
        return F || Y("ExtrudeGeometry: vec does not exist"), z.clone().addScaledVector(F, k);
      }
      const at = C.length;
      function Lt(z, F, k) {
        let E, R, X;
        const q = z.x - F.x, j = z.y - F.y, Q = k.x - z.x, ct = k.y - z.y, St = q * q + j * j, Ae = q * ct - j * Q;
        if (Math.abs(Ae) > Number.EPSILON) {
          const At = Math.sqrt(St), Wr = Math.sqrt(Q * Q + ct * ct), Gr = F.x - j / At, qr = F.y + q / At, ah = k.x - ct / Wr, oh = k.y + Q / Wr, Hr = ((ah - Gr) * ct - (oh - qr) * Q) / (q * ct - j * Q);
          E = Gr + q * Hr - z.x, R = qr + j * Hr - z.y;
          const Jr = E * E + R * R;
          if (Jr <= 2) return new I(E, R);
          X = Math.sqrt(Jr / 2);
        } else {
          let At = false;
          q > Number.EPSILON ? Q > Number.EPSILON && (At = true) : q < -Number.EPSILON ? Q < -Number.EPSILON && (At = true) : Math.sign(j) === Math.sign(ct) && (At = true), At ? (E = -j, R = q, X = Math.sqrt(St)) : (E = q, R = j, X = Math.sqrt(St / 2));
        }
        return new I(E / X, R / X);
      }
      const it = [];
      for (let z = 0, F = V.length, k = F - 1, E = z + 1; z < F; z++, k++, E++) k === F && (k = 0), E === F && (E = 0), it[z] = Lt(V[z], V[k], V[E]);
      const ot = [];
      let st, Dt = it.concat();
      for (let z = 0, F = J; z < F; z++) {
        const k = B[z];
        st = [];
        for (let E = 0, R = k.length, X = R - 1, q = E + 1; E < R; E++, X++, q++) X === R && (X = 0), q === R && (q = 0), st[E] = Lt(k[E], k[X], k[q]);
        ot.push(st), Dt = Dt.concat(st);
      }
      let kt;
      if (g === 0) kt = $t.triangulateShape(V, B);
      else {
        const z = [], F = [];
        for (let k = 0; k < g; k++) {
          const E = k / g, R = p * Math.cos(E * Math.PI / 2), X = f * Math.sin(E * Math.PI / 2) + m;
          for (let q = 0, j = V.length; q < j; q++) {
            const Q = et(V[q], it[q], X);
            ee(Q.x, Q.y, -R), E === 0 && z.push(Q);
          }
          for (let q = 0, j = J; q < j; q++) {
            const Q = B[q];
            st = ot[q];
            const ct = [];
            for (let St = 0, Ae = Q.length; St < Ae; St++) {
              const At = et(Q[St], st[St], X);
              ee(At.x, At.y, -R), E === 0 && ct.push(At);
            }
            E === 0 && F.push(ct);
          }
        }
        kt = $t.triangulateShape(z, F);
      }
      const He = kt.length, Ci = f + m;
      for (let z = 0; z < at; z++) {
        const F = d ? et(C[z], Dt[z], Ci) : C[z];
        M ? (A.copy(_.normals[0]).multiplyScalar(F.x), v.copy(_.binormals[0]).multiplyScalar(F.y), S.copy(b[0]).add(A).add(v), ee(S.x, S.y, S.z)) : ee(F.x, F.y, 0);
      }
      for (let z = 1; z <= c; z++) for (let F = 0; F < at; F++) {
        const k = d ? et(C[F], Dt[F], Ci) : C[F];
        M ? (A.copy(_.normals[z]).multiplyScalar(k.x), v.copy(_.binormals[z]).multiplyScalar(k.y), S.copy(b[z]).add(A).add(v), ee(S.x, S.y, S.z)) : ee(k.x, k.y, u / c * z);
      }
      for (let z = g - 1; z >= 0; z--) {
        const F = z / g, k = p * Math.cos(F * Math.PI / 2), E = f * Math.sin(F * Math.PI / 2) + m;
        for (let R = 0, X = V.length; R < X; R++) {
          const q = et(V[R], it[R], E);
          ee(q.x, q.y, u + k);
        }
        for (let R = 0, X = B.length; R < X; R++) {
          const q = B[R];
          st = ot[R];
          for (let j = 0, Q = q.length; j < Q; j++) {
            const ct = et(q[j], st[j], E);
            M ? ee(ct.x, ct.y + b[c - 1].y, b[c - 1].x + k) : ee(ct.x, ct.y, u + k);
          }
        }
      }
      sh(), nh();
      function sh() {
        const z = s.length / 3;
        if (d) {
          let F = 0, k = at * F;
          for (let E = 0; E < He; E++) {
            const R = kt[E];
            Ki(R[2] + k, R[1] + k, R[0] + k);
          }
          F = c + g * 2, k = at * F;
          for (let E = 0; E < He; E++) {
            const R = kt[E];
            Ki(R[0] + k, R[1] + k, R[2] + k);
          }
        } else {
          for (let F = 0; F < He; F++) {
            const k = kt[F];
            Ki(k[2], k[1], k[0]);
          }
          for (let F = 0; F < He; F++) {
            const k = kt[F];
            Ki(k[0] + at * c, k[1] + at * c, k[2] + at * c);
          }
        }
        i.addGroup(z, s.length / 3 - z, 0);
      }
      function nh() {
        const z = s.length / 3;
        let F = 0;
        Ur(V, F), F += V.length;
        for (let k = 0, E = B.length; k < E; k++) {
          const R = B[k];
          Ur(R, F), F += R.length;
        }
        i.addGroup(z, s.length / 3 - z, 1);
      }
      function Ur(z, F) {
        let k = z.length;
        for (; --k >= 0; ) {
          const E = k;
          let R = k - 1;
          R < 0 && (R = z.length - 1);
          for (let X = 0, q = c + g * 2; X < q; X++) {
            const j = at * X, Q = at * (X + 1), ct = F + E + j, St = F + R + j, Ae = F + R + Q, At = F + E + Q;
            rh(ct, St, Ae, At);
          }
        }
      }
      function ee(z, F, k) {
        o.push(z), o.push(F), o.push(k);
      }
      function Ki(z, F, k) {
        ie(z), ie(F), ie(k);
        const E = s.length / 3, R = x.generateTopUV(i, s, E - 3, E - 2, E - 1);
        se(R[0]), se(R[1]), se(R[2]);
      }
      function rh(z, F, k, E) {
        ie(z), ie(F), ie(E), ie(F), ie(k), ie(E);
        const R = s.length / 3, X = x.generateSideWallUV(i, s, R - 6, R - 3, R - 2, R - 1);
        se(X[0]), se(X[1]), se(X[3]), se(X[1]), se(X[2]), se(X[3]);
      }
      function ie(z) {
        s.push(o[z * 3 + 0]), s.push(o[z * 3 + 1]), s.push(o[z * 3 + 2]);
      }
      function se(z) {
        n.push(z.x), n.push(z.y);
      }
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  toJSON() {
    const t = super.toJSON(), e = this.parameters.shapes, i = this.parameters.options;
    return su(e, i, t);
  }
  static fromJSON(t, e) {
    const i = [];
    for (let n = 0, r = t.shapes.length; n < r; n++) {
      const a = e[t.shapes[n]];
      i.push(a);
    }
    const s = t.options.extrudePath;
    return s !== void 0 && (t.options.extrudePath = new js[s.type]().fromJSON(s)), new Ar(i, t.options);
  }
}
const iu = { generateTopUV: function(l, t, e, i, s) {
  const n = t[e * 3], r = t[e * 3 + 1], a = t[i * 3], o = t[i * 3 + 1], h = t[s * 3], c = t[s * 3 + 1];
  return [new I(n, r), new I(a, o), new I(h, c)];
}, generateSideWallUV: function(l, t, e, i, s, n) {
  const r = t[e * 3], a = t[e * 3 + 1], o = t[e * 3 + 2], h = t[i * 3], c = t[i * 3 + 1], u = t[i * 3 + 2], d = t[s * 3], p = t[s * 3 + 1], f = t[s * 3 + 2], m = t[n * 3], g = t[n * 3 + 1], y = t[n * 3 + 2];
  return Math.abs(a - c) < Math.abs(r - h) ? [new I(r, 1 - o), new I(h, 1 - u), new I(d, 1 - f), new I(m, 1 - y)] : [new I(a, 1 - o), new I(c, 1 - u), new I(p, 1 - f), new I(g, 1 - y)];
} };
function su(l, t, e) {
  if (e.shapes = [], Array.isArray(l)) for (let i = 0, s = l.length; i < s; i++) {
    const n = l[i];
    e.shapes.push(n.uuid);
  }
  else e.shapes.push(l.uuid);
  return e.options = Object.assign({}, t), t.extrudePath !== void 0 && (e.options.extrudePath = t.extrudePath.toJSON()), e;
}
class Tr extends Ge {
  constructor(t = 1, e = 0) {
    const i = (1 + Math.sqrt(5)) / 2, s = [-1, i, 0, 1, i, 0, -1, -i, 0, 1, -i, 0, 0, -1, i, 0, 1, i, 0, -1, -i, 0, 1, -i, i, 0, -1, i, 0, 1, -i, 0, -1, -i, 0, 1], n = [0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11, 1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8, 3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9, 4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1];
    super(s, n, t, e), this.type = "IcosahedronGeometry", this.parameters = { radius: t, detail: e };
  }
  static fromJSON(t) {
    return new Tr(t.radius, t.detail);
  }
}
class Cr extends H {
  constructor(t = [new I(0, -0.5), new I(0.5, 0), new I(0, 0.5)], e = 12, i = 0, s = Math.PI * 2) {
    super(), this.type = "LatheGeometry", this.parameters = { points: t, segments: e, phiStart: i, phiLength: s }, e = Math.floor(e), s = L(s, 0, Math.PI * 2);
    const n = [], r = [], a = [], o = [], h = [], c = 1 / e, u = new w(), d = new I(), p = new w(), f = new w(), m = new w();
    let g = 0, y = 0;
    for (let x = 0; x <= t.length - 1; x++) switch (x) {
      case 0:
        g = t[x + 1].x - t[x].x, y = t[x + 1].y - t[x].y, p.x = y * 1, p.y = -g, p.z = y * 0, m.copy(p), p.normalize(), o.push(p.x, p.y, p.z);
        break;
      case t.length - 1:
        o.push(m.x, m.y, m.z);
        break;
      default:
        g = t[x + 1].x - t[x].x, y = t[x + 1].y - t[x].y, p.x = y * 1, p.y = -g, p.z = y * 0, f.copy(p), p.x += m.x, p.y += m.y, p.z += m.z, p.normalize(), o.push(p.x, p.y, p.z), m.copy(f);
    }
    for (let x = 0; x <= e; x++) {
      const b = i + x * c * s, M = Math.sin(b), _ = Math.cos(b);
      for (let v = 0; v <= t.length - 1; v++) {
        u.x = t[v].x * M, u.y = t[v].y, u.z = t[v].x * _, r.push(u.x, u.y, u.z), d.x = x / e, d.y = v / (t.length - 1), a.push(d.x, d.y);
        const A = o[3 * v + 0] * M, S = o[3 * v + 1], T = o[3 * v + 0] * _;
        h.push(A, S, T);
      }
    }
    for (let x = 0; x < e; x++) for (let b = 0; b < t.length - 1; b++) {
      const M = b + x * t.length, _ = M, v = M + t.length, A = M + t.length + 1, S = M + 1;
      n.push(_, v, S), n.push(A, S, v);
    }
    this.setIndex(n), this.setAttribute("position", new P(r, 3)), this.setAttribute("uv", new P(a, 2)), this.setAttribute("normal", new P(h, 3));
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new Cr(t.points, t.segments, t.phiStart, t.phiLength);
  }
}
class on extends Ge {
  constructor(t = 1, e = 0) {
    const i = [1, 0, 0, -1, 0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 1, 0, 0, -1], s = [0, 2, 4, 0, 4, 3, 0, 3, 5, 0, 5, 2, 1, 2, 5, 1, 5, 3, 1, 3, 4, 1, 4, 2];
    super(i, s, t, e), this.type = "OctahedronGeometry", this.parameters = { radius: t, detail: e };
  }
  static fromJSON(t) {
    return new on(t.radius, t.detail);
  }
}
class Ir extends H {
  constructor(t = 1, e = 1, i = 1, s = 1) {
    super(), this.type = "PlaneGeometry", this.parameters = { width: t, height: e, widthSegments: i, heightSegments: s };
    const n = t / 2, r = e / 2, a = Math.floor(i), o = Math.floor(s), h = a + 1, c = o + 1, u = t / a, d = e / o, p = [], f = [], m = [], g = [];
    for (let y = 0; y < c; y++) {
      const x = y * d - r;
      for (let b = 0; b < h; b++) {
        const M = b * u - n;
        f.push(M, -x, 0), m.push(0, 0, 1), g.push(b / a), g.push(1 - y / o);
      }
    }
    for (let y = 0; y < o; y++) for (let x = 0; x < a; x++) {
      const b = x + h * y, M = x + h * (y + 1), _ = x + 1 + h * (y + 1), v = x + 1 + h * y;
      p.push(b, M, v), p.push(M, _, v);
    }
    this.setIndex(p), this.setAttribute("position", new P(f, 3)), this.setAttribute("normal", new P(m, 3)), this.setAttribute("uv", new P(g, 2));
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new Ir(t.width, t.height, t.widthSegments, t.heightSegments);
  }
}
class zr extends H {
  constructor(t = 0.5, e = 1, i = 32, s = 1, n = 0, r = Math.PI * 2) {
    super(), this.type = "RingGeometry", this.parameters = { innerRadius: t, outerRadius: e, thetaSegments: i, phiSegments: s, thetaStart: n, thetaLength: r }, i = Math.max(3, i), s = Math.max(1, s);
    const a = [], o = [], h = [], c = [];
    let u = t;
    const d = (e - t) / s, p = new w(), f = new I();
    for (let m = 0; m <= s; m++) {
      for (let g = 0; g <= i; g++) {
        const y = n + g / i * r;
        p.x = u * Math.cos(y), p.y = u * Math.sin(y), o.push(p.x, p.y, p.z), h.push(0, 0, 1), f.x = (p.x / e + 1) / 2, f.y = (p.y / e + 1) / 2, c.push(f.x, f.y);
      }
      u += d;
    }
    for (let m = 0; m < s; m++) {
      const g = m * (i + 1);
      for (let y = 0; y < i; y++) {
        const x = y + g, b = x, M = x + i + 1, _ = x + i + 2, v = x + 1;
        a.push(b, M, v), a.push(M, _, v);
      }
    }
    this.setIndex(a), this.setAttribute("position", new P(o, 3)), this.setAttribute("normal", new P(h, 3)), this.setAttribute("uv", new P(c, 2));
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new zr(t.innerRadius, t.outerRadius, t.thetaSegments, t.phiSegments, t.thetaStart, t.thetaLength);
  }
}
class Br extends H {
  constructor(t = new xi([new I(0, 0.5), new I(-0.5, -0.5), new I(0.5, -0.5)]), e = 12) {
    super(), this.type = "ShapeGeometry", this.parameters = { shapes: t, curveSegments: e };
    const i = [], s = [], n = [], r = [];
    let a = 0, o = 0;
    if (Array.isArray(t) === false) h(t);
    else for (let c = 0; c < t.length; c++) h(t[c]), this.addGroup(a, o, c), a += o, o = 0;
    this.setIndex(i), this.setAttribute("position", new P(s, 3)), this.setAttribute("normal", new P(n, 3)), this.setAttribute("uv", new P(r, 2));
    function h(c) {
      const u = s.length / 3, d = c.extractPoints(e);
      let p = d.shape;
      const f = d.holes;
      $t.isClockWise(p) === false && (p = p.reverse());
      for (let g = 0, y = f.length; g < y; g++) {
        const x = f[g];
        $t.isClockWise(x) === true && (f[g] = x.reverse());
      }
      const m = $t.triangulateShape(p, f);
      for (let g = 0, y = f.length; g < y; g++) {
        const x = f[g];
        p = p.concat(x);
      }
      for (let g = 0, y = p.length; g < y; g++) {
        const x = p[g];
        s.push(x.x, x.y, 0), n.push(0, 0, 1), r.push(x.x, x.y);
      }
      for (let g = 0, y = m.length; g < y; g++) {
        const x = m[g], b = x[0] + u, M = x[1] + u, _ = x[2] + u;
        i.push(b, M, _), o += 3;
      }
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  toJSON() {
    const t = super.toJSON(), e = this.parameters.shapes;
    return nu(e, t);
  }
  static fromJSON(t, e) {
    const i = [];
    for (let s = 0, n = t.shapes.length; s < n; s++) {
      const r = e[t.shapes[s]];
      i.push(r);
    }
    return new Br(i, t.curveSegments);
  }
}
function nu(l, t) {
  if (t.shapes = [], Array.isArray(l)) for (let e = 0, i = l.length; e < i; e++) {
    const s = l[e];
    t.shapes.push(s.uuid);
  }
  else t.shapes.push(l.uuid);
  return t;
}
class hn extends H {
  constructor(t = 1, e = 32, i = 16, s = 0, n = Math.PI * 2, r = 0, a = Math.PI) {
    super(), this.type = "SphereGeometry", this.parameters = { radius: t, widthSegments: e, heightSegments: i, phiStart: s, phiLength: n, thetaStart: r, thetaLength: a }, e = Math.max(3, Math.floor(e)), i = Math.max(2, Math.floor(i));
    const o = Math.min(r + a, Math.PI);
    let h = 0;
    const c = [], u = new w(), d = new w(), p = [], f = [], m = [], g = [];
    for (let y = 0; y <= i; y++) {
      const x = [], b = y / i;
      let M = 0;
      y === 0 && r === 0 ? M = 0.5 / e : y === i && o === Math.PI && (M = -0.5 / e);
      for (let _ = 0; _ <= e; _++) {
        const v = _ / e;
        u.x = -t * Math.cos(s + v * n) * Math.sin(r + b * a), u.y = t * Math.cos(r + b * a), u.z = t * Math.sin(s + v * n) * Math.sin(r + b * a), f.push(u.x, u.y, u.z), d.copy(u).normalize(), m.push(d.x, d.y, d.z), g.push(v + M, 1 - b), x.push(h++);
      }
      c.push(x);
    }
    for (let y = 0; y < i; y++) for (let x = 0; x < e; x++) {
      const b = c[y][x + 1], M = c[y][x], _ = c[y + 1][x], v = c[y + 1][x + 1];
      (y !== 0 || r > 0) && p.push(b, M, v), (y !== i - 1 || o < Math.PI) && p.push(M, _, v);
    }
    this.setIndex(p), this.setAttribute("position", new P(f, 3)), this.setAttribute("normal", new P(m, 3)), this.setAttribute("uv", new P(g, 2));
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new hn(t.radius, t.widthSegments, t.heightSegments, t.phiStart, t.phiLength, t.thetaStart, t.thetaLength);
  }
}
class Fr extends Ge {
  constructor(t = 1, e = 0) {
    const i = [1, 1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1], s = [2, 1, 0, 0, 3, 2, 1, 3, 0, 2, 3, 1];
    super(i, s, t, e), this.type = "TetrahedronGeometry", this.parameters = { radius: t, detail: e };
  }
  static fromJSON(t) {
    return new Fr(t.radius, t.detail);
  }
}
class kr extends H {
  constructor(t = 1, e = 0.4, i = 12, s = 48, n = Math.PI * 2, r = 0, a = Math.PI * 2) {
    super(), this.type = "TorusGeometry", this.parameters = { radius: t, tube: e, radialSegments: i, tubularSegments: s, arc: n, thetaStart: r, thetaLength: a }, i = Math.floor(i), s = Math.floor(s);
    const o = [], h = [], c = [], u = [], d = new w(), p = new w(), f = new w();
    for (let m = 0; m <= i; m++) {
      const g = r + m / i * a;
      for (let y = 0; y <= s; y++) {
        const x = y / s * n;
        p.x = (t + e * Math.cos(g)) * Math.cos(x), p.y = (t + e * Math.cos(g)) * Math.sin(x), p.z = e * Math.sin(g), h.push(p.x, p.y, p.z), d.x = t * Math.cos(x), d.y = t * Math.sin(x), f.subVectors(p, d).normalize(), c.push(f.x, f.y, f.z), u.push(y / s), u.push(m / i);
      }
    }
    for (let m = 1; m <= i; m++) for (let g = 1; g <= s; g++) {
      const y = (s + 1) * m + g - 1, x = (s + 1) * (m - 1) + g - 1, b = (s + 1) * (m - 1) + g, M = (s + 1) * m + g;
      o.push(y, x, M), o.push(x, b, M);
    }
    this.setIndex(o), this.setAttribute("position", new P(h, 3)), this.setAttribute("normal", new P(c, 3)), this.setAttribute("uv", new P(u, 2));
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new kr(t.radius, t.tube, t.radialSegments, t.tubularSegments, t.arc);
  }
}
class Pr extends H {
  constructor(t = 1, e = 0.4, i = 64, s = 8, n = 2, r = 3) {
    super(), this.type = "TorusKnotGeometry", this.parameters = { radius: t, tube: e, tubularSegments: i, radialSegments: s, p: n, q: r }, i = Math.floor(i), s = Math.floor(s);
    const a = [], o = [], h = [], c = [], u = new w(), d = new w(), p = new w(), f = new w(), m = new w(), g = new w(), y = new w();
    for (let b = 0; b <= i; ++b) {
      const M = b / i * n * Math.PI * 2;
      x(M, n, r, t, p), x(M + 0.01, n, r, t, f), g.subVectors(f, p), y.addVectors(f, p), m.crossVectors(g, y), y.crossVectors(m, g), m.normalize(), y.normalize();
      for (let _ = 0; _ <= s; ++_) {
        const v = _ / s * Math.PI * 2, A = -e * Math.cos(v), S = e * Math.sin(v);
        u.x = p.x + (A * y.x + S * m.x), u.y = p.y + (A * y.y + S * m.y), u.z = p.z + (A * y.z + S * m.z), o.push(u.x, u.y, u.z), d.subVectors(u, p).normalize(), h.push(d.x, d.y, d.z), c.push(b / i), c.push(_ / s);
      }
    }
    for (let b = 1; b <= i; b++) for (let M = 1; M <= s; M++) {
      const _ = (s + 1) * (b - 1) + (M - 1), v = (s + 1) * b + (M - 1), A = (s + 1) * b + M, S = (s + 1) * (b - 1) + M;
      a.push(_, v, S), a.push(v, A, S);
    }
    this.setIndex(a), this.setAttribute("position", new P(o, 3)), this.setAttribute("normal", new P(h, 3)), this.setAttribute("uv", new P(c, 2));
    function x(b, M, _, v, A) {
      const S = Math.cos(b), T = Math.sin(b), C = _ / M * b, B = Math.cos(C);
      A.x = v * (2 + B) * 0.5 * S, A.y = v * (2 + B) * T * 0.5, A.z = v * Math.sin(C) * 0.5;
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new Pr(t.radius, t.tube, t.tubularSegments, t.radialSegments, t.p, t.q);
  }
}
class Rr extends H {
  constructor(t = new Do(new w(-1, -1, 0), new w(-1, 1, 0), new w(1, 1, 0)), e = 64, i = 1, s = 8, n = false) {
    super(), this.type = "TubeGeometry", this.parameters = { path: t, tubularSegments: e, radius: i, radialSegments: s, closed: n };
    const r = t.computeFrenetFrames(e, n);
    this.tangents = r.tangents, this.normals = r.normals, this.binormals = r.binormals;
    const a = new w(), o = new w(), h = new I();
    let c = new w();
    const u = [], d = [], p = [], f = [];
    m(), this.setIndex(f), this.setAttribute("position", new P(u, 3)), this.setAttribute("normal", new P(d, 3)), this.setAttribute("uv", new P(p, 2));
    function m() {
      for (let b = 0; b < e; b++) g(b);
      g(n === false ? e : 0), x(), y();
    }
    function g(b) {
      c = t.getPointAt(b / e, c);
      const M = r.normals[b], _ = r.binormals[b];
      for (let v = 0; v <= s; v++) {
        const A = v / s * Math.PI * 2, S = Math.sin(A), T = -Math.cos(A);
        o.x = T * M.x + S * _.x, o.y = T * M.y + S * _.y, o.z = T * M.z + S * _.z, o.normalize(), d.push(o.x, o.y, o.z), a.x = c.x + i * o.x, a.y = c.y + i * o.y, a.z = c.z + i * o.z, u.push(a.x, a.y, a.z);
      }
    }
    function y() {
      for (let b = 1; b <= e; b++) for (let M = 1; M <= s; M++) {
        const _ = (s + 1) * (b - 1) + (M - 1), v = (s + 1) * b + (M - 1), A = (s + 1) * b + M, S = (s + 1) * (b - 1) + M;
        f.push(_, v, S), f.push(v, A, S);
      }
    }
    function x() {
      for (let b = 0; b <= e; b++) for (let M = 0; M <= s; M++) h.x = b / e, h.y = M / s, p.push(h.x, h.y);
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.path = this.parameters.path.toJSON(), t;
  }
  static fromJSON(t) {
    return new Rr(new js[t.path.type]().fromJSON(t.path), t.tubularSegments, t.radius, t.radialSegments, t.closed);
  }
}
class ru extends H {
  constructor(t = null) {
    if (super(), this.type = "WireframeGeometry", this.parameters = { geometry: t }, t !== null) {
      const e = [], i = /* @__PURE__ */ new Set(), s = new w(), n = new w();
      if (t.index !== null) {
        const r = t.attributes.position, a = t.index;
        let o = t.groups;
        o.length === 0 && (o = [{ start: 0, count: a.count, materialIndex: 0 }]);
        for (let h = 0, c = o.length; h < c; ++h) {
          const u = o[h], d = u.start, p = u.count;
          for (let f = d, m = d + p; f < m; f += 3) for (let g = 0; g < 3; g++) {
            const y = a.getX(f + g), x = a.getX(f + (g + 1) % 3);
            s.fromBufferAttribute(r, y), n.fromBufferAttribute(r, x), $a(s, n, i) === true && (e.push(s.x, s.y, s.z), e.push(n.x, n.y, n.z));
          }
        }
      } else {
        const r = t.attributes.position;
        for (let a = 0, o = r.count / 3; a < o; a++) for (let h = 0; h < 3; h++) {
          const c = 3 * a + h, u = 3 * a + (h + 1) % 3;
          s.fromBufferAttribute(r, c), n.fromBufferAttribute(r, u), $a(s, n, i) === true && (e.push(s.x, s.y, s.z), e.push(n.x, n.y, n.z));
        }
      }
      this.setAttribute("position", new P(e, 3));
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
}
function $a(l, t, e) {
  const i = `${l.x},${l.y},${l.z}-${t.x},${t.y},${t.z}`, s = `${t.x},${t.y},${t.z}-${l.x},${l.y},${l.z}`;
  return e.has(i) === true || e.has(s) === true ? false : (e.add(i), e.add(s), true);
}
var ja = Object.freeze({ __proto__: null, BoxGeometry: br, CapsuleGeometry: Mr, CircleGeometry: wr, ConeGeometry: an, CylinderGeometry: rn, DodecahedronGeometry: _r, EdgesGeometry: Ac, ExtrudeGeometry: Ar, IcosahedronGeometry: Tr, LatheGeometry: Cr, OctahedronGeometry: on, PlaneGeometry: Ir, PolyhedronGeometry: Ge, RingGeometry: zr, ShapeGeometry: Br, SphereGeometry: hn, TetrahedronGeometry: Fr, TorusGeometry: kr, TorusKnotGeometry: Pr, TubeGeometry: Rr, WireframeGeometry: ru });
class au extends bt {
  constructor(t) {
    super(), this.isShadowMaterial = true, this.type = "ShadowMaterial", this.color = new U(0), this.transparent = true, this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.fog = t.fog, this;
  }
}
function ou(l) {
  const t = {};
  for (const e in l) {
    t[e] = {};
    for (const i in l[e]) {
      const s = l[e][i];
      s && (s.isColor || s.isMatrix3 || s.isMatrix4 || s.isVector2 || s.isVector3 || s.isVector4 || s.isTexture || s.isQuaternion) ? s.isRenderTargetTexture ? (N("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."), t[e][i] = null) : t[e][i] = s.clone() : Array.isArray(s) ? t[e][i] = s.slice() : t[e][i] = s;
    }
  }
  return t;
}
function hu(l) {
  const t = [];
  for (let e = 0; e < l.length; e++) t.push(l[e].clone());
  return t;
}
var lu = `void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`, cu = `void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;
class Ho extends bt {
  constructor(t) {
    super(), this.isShaderMaterial = true, this.type = "ShaderMaterial", this.defines = {}, this.uniforms = {}, this.uniformsGroups = [], this.vertexShader = lu, this.fragmentShader = cu, this.linewidth = 1, this.wireframe = false, this.wireframeLinewidth = 1, this.fog = false, this.lights = false, this.clipping = false, this.forceSinglePass = true, this.extensions = { clipCullDistance: false, multiDraw: false }, this.defaultAttributeValues = { color: [1, 1, 1], uv: [0, 0], uv1: [0, 0] }, this.index0AttributeName = void 0, this.uniformsNeedUpdate = false, this.glslVersion = null, t !== void 0 && this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.fragmentShader = t.fragmentShader, this.vertexShader = t.vertexShader, this.uniforms = ou(t.uniforms), this.uniformsGroups = hu(t.uniformsGroups), this.defines = Object.assign({}, t.defines), this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.fog = t.fog, this.lights = t.lights, this.clipping = t.clipping, this.extensions = Object.assign({}, t.extensions), this.glslVersion = t.glslVersion, this.defaultAttributeValues = Object.assign({}, t.defaultAttributeValues), this.index0AttributeName = t.index0AttributeName, this.uniformsNeedUpdate = t.uniformsNeedUpdate, this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    e.glslVersion = this.glslVersion, e.uniforms = {};
    for (const s in this.uniforms) {
      const r = this.uniforms[s].value;
      r && r.isTexture ? e.uniforms[s] = { type: "t", value: r.toJSON(t).uuid } : r && r.isColor ? e.uniforms[s] = { type: "c", value: r.getHex() } : r && r.isVector2 ? e.uniforms[s] = { type: "v2", value: r.toArray() } : r && r.isVector3 ? e.uniforms[s] = { type: "v3", value: r.toArray() } : r && r.isVector4 ? e.uniforms[s] = { type: "v4", value: r.toArray() } : r && r.isMatrix3 ? e.uniforms[s] = { type: "m3", value: r.toArray() } : r && r.isMatrix4 ? e.uniforms[s] = { type: "m4", value: r.toArray() } : e.uniforms[s] = { value: r };
    }
    Object.keys(this.defines).length > 0 && (e.defines = this.defines), e.vertexShader = this.vertexShader, e.fragmentShader = this.fragmentShader, e.lights = this.lights, e.clipping = this.clipping;
    const i = {};
    for (const s in this.extensions) this.extensions[s] === true && (i[s] = true);
    return Object.keys(i).length > 0 && (e.extensions = i), e;
  }
}
class uu extends Ho {
  constructor(t) {
    super(t), this.isRawShaderMaterial = true, this.type = "RawShaderMaterial";
  }
}
class Jo extends bt {
  constructor(t) {
    super(), this.isMeshStandardMaterial = true, this.type = "MeshStandardMaterial", this.defines = { STANDARD: "" }, this.color = new U(16777215), this.roughness = 1, this.metalness = 0, this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new U(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = vi, this.normalScale = new I(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.roughnessMap = null, this.metalnessMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new jt(), this.envMapIntensity = 1, this.wireframe = false, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = false, this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.defines = { STANDARD: "" }, this.color.copy(t.color), this.roughness = t.roughness, this.metalness = t.metalness, this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.roughnessMap = t.roughnessMap, this.metalnessMap = t.metalnessMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.envMapIntensity = t.envMapIntensity, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this;
  }
}
class du extends Jo {
  constructor(t) {
    super(), this.isMeshPhysicalMaterial = true, this.defines = { STANDARD: "", PHYSICAL: "" }, this.type = "MeshPhysicalMaterial", this.anisotropyRotation = 0, this.anisotropyMap = null, this.clearcoatMap = null, this.clearcoatRoughness = 0, this.clearcoatRoughnessMap = null, this.clearcoatNormalScale = new I(1, 1), this.clearcoatNormalMap = null, this.ior = 1.5, Object.defineProperty(this, "reflectivity", { get: function() {
      return L(2.5 * (this.ior - 1) / (this.ior + 1), 0, 1);
    }, set: function(e) {
      this.ior = (1 + 0.4 * e) / (1 - 0.4 * e);
    } }), this.iridescenceMap = null, this.iridescenceIOR = 1.3, this.iridescenceThicknessRange = [100, 400], this.iridescenceThicknessMap = null, this.sheenColor = new U(0), this.sheenColorMap = null, this.sheenRoughness = 1, this.sheenRoughnessMap = null, this.transmissionMap = null, this.thickness = 0, this.thicknessMap = null, this.attenuationDistance = 1 / 0, this.attenuationColor = new U(1, 1, 1), this.specularIntensity = 1, this.specularIntensityMap = null, this.specularColor = new U(1, 1, 1), this.specularColorMap = null, this._anisotropy = 0, this._clearcoat = 0, this._dispersion = 0, this._iridescence = 0, this._sheen = 0, this._transmission = 0, this.setValues(t);
  }
  get anisotropy() {
    return this._anisotropy;
  }
  set anisotropy(t) {
    this._anisotropy > 0 != t > 0 && this.version++, this._anisotropy = t;
  }
  get clearcoat() {
    return this._clearcoat;
  }
  set clearcoat(t) {
    this._clearcoat > 0 != t > 0 && this.version++, this._clearcoat = t;
  }
  get iridescence() {
    return this._iridescence;
  }
  set iridescence(t) {
    this._iridescence > 0 != t > 0 && this.version++, this._iridescence = t;
  }
  get dispersion() {
    return this._dispersion;
  }
  set dispersion(t) {
    this._dispersion > 0 != t > 0 && this.version++, this._dispersion = t;
  }
  get sheen() {
    return this._sheen;
  }
  set sheen(t) {
    this._sheen > 0 != t > 0 && this.version++, this._sheen = t;
  }
  get transmission() {
    return this._transmission;
  }
  set transmission(t) {
    this._transmission > 0 != t > 0 && this.version++, this._transmission = t;
  }
  copy(t) {
    return super.copy(t), this.defines = { STANDARD: "", PHYSICAL: "" }, this.anisotropy = t.anisotropy, this.anisotropyRotation = t.anisotropyRotation, this.anisotropyMap = t.anisotropyMap, this.clearcoat = t.clearcoat, this.clearcoatMap = t.clearcoatMap, this.clearcoatRoughness = t.clearcoatRoughness, this.clearcoatRoughnessMap = t.clearcoatRoughnessMap, this.clearcoatNormalMap = t.clearcoatNormalMap, this.clearcoatNormalScale.copy(t.clearcoatNormalScale), this.dispersion = t.dispersion, this.ior = t.ior, this.iridescence = t.iridescence, this.iridescenceMap = t.iridescenceMap, this.iridescenceIOR = t.iridescenceIOR, this.iridescenceThicknessRange = [...t.iridescenceThicknessRange], this.iridescenceThicknessMap = t.iridescenceThicknessMap, this.sheen = t.sheen, this.sheenColor.copy(t.sheenColor), this.sheenColorMap = t.sheenColorMap, this.sheenRoughness = t.sheenRoughness, this.sheenRoughnessMap = t.sheenRoughnessMap, this.transmission = t.transmission, this.transmissionMap = t.transmissionMap, this.thickness = t.thickness, this.thicknessMap = t.thicknessMap, this.attenuationDistance = t.attenuationDistance, this.attenuationColor.copy(t.attenuationColor), this.specularIntensity = t.specularIntensity, this.specularIntensityMap = t.specularIntensityMap, this.specularColor.copy(t.specularColor), this.specularColorMap = t.specularColorMap, this;
  }
}
class pu extends bt {
  constructor(t) {
    super(), this.isMeshPhongMaterial = true, this.type = "MeshPhongMaterial", this.color = new U(16777215), this.specular = new U(1118481), this.shininess = 30, this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new U(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = vi, this.normalScale = new I(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new jt(), this.combine = ar, this.reflectivity = 1, this.envMapIntensity = 1, this.refractionRatio = 0.98, this.wireframe = false, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = false, this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.specular.copy(t.specular), this.shininess = t.shininess, this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.combine = t.combine, this.reflectivity = t.reflectivity, this.envMapIntensity = t.envMapIntensity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this;
  }
}
class fu extends bt {
  constructor(t) {
    super(), this.isMeshToonMaterial = true, this.defines = { TOON: "" }, this.type = "MeshToonMaterial", this.color = new U(16777215), this.map = null, this.gradientMap = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new U(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = vi, this.normalScale = new I(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.alphaMap = null, this.wireframe = false, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.gradientMap = t.gradientMap, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.alphaMap = t.alphaMap, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.fog = t.fog, this;
  }
}
class mu extends bt {
  constructor(t) {
    super(), this.isMeshNormalMaterial = true, this.type = "MeshNormalMaterial", this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = vi, this.normalScale = new I(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.wireframe = false, this.wireframeLinewidth = 1, this.flatShading = false, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.flatShading = t.flatShading, this;
  }
}
class yu extends bt {
  constructor(t) {
    super(), this.isMeshLambertMaterial = true, this.type = "MeshLambertMaterial", this.color = new U(16777215), this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new U(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = vi, this.normalScale = new I(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new jt(), this.combine = ar, this.reflectivity = 1, this.envMapIntensity = 1, this.refractionRatio = 0.98, this.wireframe = false, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = false, this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.combine = t.combine, this.reflectivity = t.reflectivity, this.envMapIntensity = t.envMapIntensity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this;
  }
}
class gu extends bt {
  constructor(t) {
    super(), this.isMeshDepthMaterial = true, this.type = "MeshDepthMaterial", this.depthPacking = gl, this.map = null, this.alphaMap = null, this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.wireframe = false, this.wireframeLinewidth = 1, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.depthPacking = t.depthPacking, this.map = t.map, this.alphaMap = t.alphaMap, this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this;
  }
}
class xu extends bt {
  constructor(t) {
    super(), this.isMeshDistanceMaterial = true, this.type = "MeshDistanceMaterial", this.map = null, this.alphaMap = null, this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.map = t.map, this.alphaMap = t.alphaMap, this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this;
  }
}
class bu extends bt {
  constructor(t) {
    super(), this.isMeshMatcapMaterial = true, this.defines = { MATCAP: "" }, this.type = "MeshMatcapMaterial", this.color = new U(16777215), this.matcap = null, this.map = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = vi, this.normalScale = new I(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.alphaMap = null, this.wireframe = false, this.wireframeLinewidth = 1, this.flatShading = false, this.fog = true, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.defines = { MATCAP: "" }, this.color.copy(t.color), this.matcap = t.matcap, this.map = t.map, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.alphaMap = t.alphaMap, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.flatShading = t.flatShading, this.fog = t.fog, this;
  }
}
class Mu extends vt {
  constructor(t) {
    super(), this.isLineDashedMaterial = true, this.type = "LineDashedMaterial", this.scale = 1, this.dashSize = 3, this.gapSize = 1, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.scale = t.scale, this.dashSize = t.dashSize, this.gapSize = t.gapSize, this;
  }
}
function De(l, t) {
  return !l || l.constructor === t ? l : typeof t.BYTES_PER_ELEMENT == "number" ? new t(l) : Array.prototype.slice.call(l);
}
function Xo(l) {
  function t(s, n) {
    return l[s] - l[n];
  }
  const e = l.length, i = new Array(e);
  for (let s = 0; s !== e; ++s) i[s] = s;
  return i.sort(t), i;
}
function nr(l, t, e) {
  const i = l.length, s = new l.constructor(i);
  for (let n = 0, r = 0; r !== i; ++n) {
    const a = e[n] * t;
    for (let o = 0; o !== t; ++o) s[r++] = l[a + o];
  }
  return s;
}
function Or(l, t, e, i) {
  let s = 1, n = l[0];
  for (; n !== void 0 && n[i] === void 0; ) n = l[s++];
  if (n === void 0) return;
  let r = n[i];
  if (r !== void 0) if (Array.isArray(r)) do
    r = n[i], r !== void 0 && (t.push(n.time), e.push(...r)), n = l[s++];
  while (n !== void 0);
  else if (r.toArray !== void 0) do
    r = n[i], r !== void 0 && (t.push(n.time), r.toArray(e, e.length)), n = l[s++];
  while (n !== void 0);
  else do
    r = n[i], r !== void 0 && (t.push(n.time), e.push(r)), n = l[s++];
  while (n !== void 0);
}
function wu(l, t, e, i, s = 30) {
  const n = l.clone();
  n.name = t;
  const r = [];
  for (let o = 0; o < n.tracks.length; ++o) {
    const h = n.tracks[o], c = h.getValueSize(), u = [], d = [];
    for (let p = 0; p < h.times.length; ++p) {
      const f = h.times[p] * s;
      if (!(f < e || f >= i)) {
        u.push(h.times[p]);
        for (let m = 0; m < c; ++m) d.push(h.values[p * c + m]);
      }
    }
    u.length !== 0 && (h.times = De(u, h.times.constructor), h.values = De(d, h.values.constructor), r.push(h));
  }
  n.tracks = r;
  let a = 1 / 0;
  for (let o = 0; o < n.tracks.length; ++o) a > n.tracks[o].times[0] && (a = n.tracks[o].times[0]);
  for (let o = 0; o < n.tracks.length; ++o) n.tracks[o].shift(-1 * a);
  return n.resetDuration(), n;
}
function _u(l, t = 0, e = l, i = 30) {
  i <= 0 && (i = 30);
  const s = e.tracks.length, n = t / i;
  for (let r = 0; r < s; ++r) {
    const a = e.tracks[r], o = a.ValueTypeName;
    if (o === "bool" || o === "string") continue;
    const h = l.tracks.find(function(y) {
      return y.name === a.name && y.ValueTypeName === o;
    });
    if (h === void 0) continue;
    let c = 0;
    const u = a.getValueSize();
    a.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline && (c = u / 3);
    let d = 0;
    const p = h.getValueSize();
    h.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline && (d = p / 3);
    const f = a.times.length - 1;
    let m;
    if (n <= a.times[0]) {
      const y = c, x = u - c;
      m = a.values.slice(y, x);
    } else if (n >= a.times[f]) {
      const y = f * u + c, x = y + u - c;
      m = a.values.slice(y, x);
    } else {
      const y = a.createInterpolant(), x = c, b = u - c;
      y.evaluate(n), m = y.resultBuffer.slice(x, b);
    }
    o === "quaternion" && new _t().fromArray(m).normalize().conjugate().toArray(m);
    const g = h.times.length;
    for (let y = 0; y < g; ++y) {
      const x = y * p + d;
      if (o === "quaternion") _t.multiplyQuaternionsFlat(h.values, x, m, 0, h.values, x);
      else {
        const b = p - d * 2;
        for (let M = 0; M < b; ++M) h.values[x + M] -= m[M];
      }
    }
  }
  return l.blendMode = _o, l;
}
class If {
  static convertArray(t, e) {
    return De(t, e);
  }
  static isTypedArray(t) {
    return So(t);
  }
  static getKeyframeOrder(t) {
    return Xo(t);
  }
  static sortedArray(t, e, i) {
    return nr(t, e, i);
  }
  static flattenJSON(t, e, i, s) {
    Or(t, e, i, s);
  }
  static subclip(t, e, i, s, n = 30) {
    return wu(t, e, i, s, n);
  }
  static makeClipAdditive(t, e = 0, i = t, s = 30) {
    return _u(t, e, i, s);
  }
}
class Qi {
  constructor(t, e, i, s) {
    this.parameterPositions = t, this._cachedIndex = 0, this.resultBuffer = s !== void 0 ? s : new e.constructor(i), this.sampleValues = e, this.valueSize = i, this.settings = null, this.DefaultSettings_ = {};
  }
  evaluate(t) {
    const e = this.parameterPositions;
    let i = this._cachedIndex, s = e[i], n = e[i - 1];
    t: {
      e: {
        let r;
        i: {
          s: if (!(t < s)) {
            for (let a = i + 2; ; ) {
              if (s === void 0) {
                if (t < n) break s;
                return i = e.length, this._cachedIndex = i, this.copySampleValue_(i - 1);
              }
              if (i === a) break;
              if (n = s, s = e[++i], t < s) break e;
            }
            r = e.length;
            break i;
          }
          if (!(t >= n)) {
            const a = e[1];
            t < a && (i = 2, n = a);
            for (let o = i - 2; ; ) {
              if (n === void 0) return this._cachedIndex = 0, this.copySampleValue_(0);
              if (i === o) break;
              if (s = n, n = e[--i - 1], t >= n) break e;
            }
            r = i, i = 0;
            break i;
          }
          break t;
        }
        for (; i < r; ) {
          const a = i + r >>> 1;
          t < e[a] ? r = a : i = a + 1;
        }
        if (s = e[i], n = e[i - 1], n === void 0) return this._cachedIndex = 0, this.copySampleValue_(0);
        if (s === void 0) return i = e.length, this._cachedIndex = i, this.copySampleValue_(i - 1);
      }
      this._cachedIndex = i, this.intervalChanged_(i, n, s);
    }
    return this.interpolate_(i, n, t, s);
  }
  getSettings_() {
    return this.settings || this.DefaultSettings_;
  }
  copySampleValue_(t) {
    const e = this.resultBuffer, i = this.sampleValues, s = this.valueSize, n = t * s;
    for (let r = 0; r !== s; ++r) e[r] = i[n + r];
    return e;
  }
  interpolate_() {
    throw new Error("call to abstract method");
  }
  intervalChanged_() {
  }
}
class vu extends Qi {
  constructor(t, e, i, s) {
    super(t, e, i, s), this._weightPrev = -0, this._offsetPrev = -0, this._weightNext = -0, this._offsetNext = -0, this.DefaultSettings_ = { endingStart: fi, endingEnd: fi };
  }
  intervalChanged_(t, e, i) {
    const s = this.parameterPositions;
    let n = t - 2, r = t + 1, a = s[n], o = s[r];
    if (a === void 0) switch (this.getSettings_().endingStart) {
      case mi:
        n = t, a = 2 * e - i;
        break;
      case Js:
        n = s.length - 2, a = e + s[n] - s[n + 1];
        break;
      default:
        n = t, a = i;
    }
    if (o === void 0) switch (this.getSettings_().endingEnd) {
      case mi:
        r = t, o = 2 * i - e;
        break;
      case Js:
        r = 1, o = i + s[1] - s[0];
        break;
      default:
        r = t - 1, o = e;
    }
    const h = (i - e) * 0.5, c = this.valueSize;
    this._weightPrev = h / (e - a), this._weightNext = h / (o - i), this._offsetPrev = n * c, this._offsetNext = r * c;
  }
  interpolate_(t, e, i, s) {
    const n = this.resultBuffer, r = this.sampleValues, a = this.valueSize, o = t * a, h = o - a, c = this._offsetPrev, u = this._offsetNext, d = this._weightPrev, p = this._weightNext, f = (i - e) / (s - e), m = f * f, g = m * f, y = -d * g + 2 * d * m - d * f, x = (1 + d) * g + (-1.5 - 2 * d) * m + (-0.5 + d) * f + 1, b = (-1 - p) * g + (1.5 + p) * m + 0.5 * f, M = p * g - p * m;
    for (let _ = 0; _ !== a; ++_) n[_] = y * r[c + _] + x * r[h + _] + b * r[o + _] + M * r[u + _];
    return n;
  }
}
class Zo extends Qi {
  constructor(t, e, i, s) {
    super(t, e, i, s);
  }
  interpolate_(t, e, i, s) {
    const n = this.resultBuffer, r = this.sampleValues, a = this.valueSize, o = t * a, h = o - a, c = (i - e) / (s - e), u = 1 - c;
    for (let d = 0; d !== a; ++d) n[d] = r[h + d] * u + r[o + d] * c;
    return n;
  }
}
class Su extends Qi {
  constructor(t, e, i, s) {
    super(t, e, i, s);
  }
  interpolate_(t) {
    return this.copySampleValue_(t - 1);
  }
}
class Au extends Qi {
  interpolate_(t, e, i, s) {
    const n = this.resultBuffer, r = this.sampleValues, a = this.valueSize, o = t * a, h = o - a, c = this.settings || this.DefaultSettings_, u = c.inTangents, d = c.outTangents;
    if (!u || !d) {
      const m = (i - e) / (s - e), g = 1 - m;
      for (let y = 0; y !== a; ++y) n[y] = r[h + y] * g + r[o + y] * m;
      return n;
    }
    const p = a * 2, f = t - 1;
    for (let m = 0; m !== a; ++m) {
      const g = r[h + m], y = r[o + m], x = f * p + m * 2, b = d[x], M = d[x + 1], _ = t * p + m * 2, v = u[_], A = u[_ + 1];
      let S = (i - e) / (s - e), T, C, B, O, D;
      for (let J = 0; J < 8; J++) {
        T = S * S, C = T * S, B = 1 - S, O = B * B, D = O * B;
        const et = D * e + 3 * O * S * b + 3 * B * T * v + C * s - i;
        if (Math.abs(et) < 1e-10) break;
        const at = 3 * O * (b - e) + 6 * B * S * (v - b) + 3 * T * (s - v);
        if (Math.abs(at) < 1e-10) break;
        S = S - et / at, S = Math.max(0, Math.min(1, S));
      }
      n[m] = D * g + 3 * O * S * M + 3 * B * T * A + C * y;
    }
    return n;
  }
}
class qt {
  constructor(t, e, i, s) {
    if (t === void 0) throw new Error("THREE.KeyframeTrack: track name is undefined");
    if (e === void 0 || e.length === 0) throw new Error("THREE.KeyframeTrack: no keyframes in track named " + t);
    this.name = t, this.times = De(e, this.TimeBufferType), this.values = De(i, this.ValueBufferType), this.setInterpolation(s || this.DefaultInterpolation);
  }
  static toJSON(t) {
    const e = t.constructor;
    let i;
    if (e.toJSON !== this.toJSON) i = e.toJSON(t);
    else {
      i = { name: t.name, times: De(t.times, Array), values: De(t.values, Array) };
      const s = t.getInterpolation();
      s !== t.DefaultInterpolation && (i.interpolation = s);
    }
    return i.type = t.ValueTypeName, i;
  }
  InterpolantFactoryMethodDiscrete(t) {
    return new Su(this.times, this.values, this.getValueSize(), t);
  }
  InterpolantFactoryMethodLinear(t) {
    return new Zo(this.times, this.values, this.getValueSize(), t);
  }
  InterpolantFactoryMethodSmooth(t) {
    return new vu(this.times, this.values, this.getValueSize(), t);
  }
  InterpolantFactoryMethodBezier(t) {
    const e = new Au(this.times, this.values, this.getValueSize(), t);
    return this.settings && (e.settings = this.settings), e;
  }
  setInterpolation(t) {
    let e;
    switch (t) {
      case Hs:
        e = this.InterpolantFactoryMethodDiscrete;
        break;
      case Kn:
        e = this.InterpolantFactoryMethodLinear;
        break;
      case cn:
        e = this.InterpolantFactoryMethodSmooth;
        break;
      case ra:
        e = this.InterpolantFactoryMethodBezier;
        break;
    }
    if (e === void 0) {
      const i = "unsupported interpolation for " + this.ValueTypeName + " keyframe track named " + this.name;
      if (this.createInterpolant === void 0) if (t !== this.DefaultInterpolation) this.setInterpolation(this.DefaultInterpolation);
      else throw new Error(i);
      return N("KeyframeTrack:", i), this;
    }
    return this.createInterpolant = e, this;
  }
  getInterpolation() {
    switch (this.createInterpolant) {
      case this.InterpolantFactoryMethodDiscrete:
        return Hs;
      case this.InterpolantFactoryMethodLinear:
        return Kn;
      case this.InterpolantFactoryMethodSmooth:
        return cn;
      case this.InterpolantFactoryMethodBezier:
        return ra;
    }
  }
  getValueSize() {
    return this.values.length / this.times.length;
  }
  shift(t) {
    if (t !== 0) {
      const e = this.times;
      for (let i = 0, s = e.length; i !== s; ++i) e[i] += t;
    }
    return this;
  }
  scale(t) {
    if (t !== 1) {
      const e = this.times;
      for (let i = 0, s = e.length; i !== s; ++i) e[i] *= t;
    }
    return this;
  }
  trim(t, e) {
    const i = this.times, s = i.length;
    let n = 0, r = s - 1;
    for (; n !== s && i[n] < t; ) ++n;
    for (; r !== -1 && i[r] > e; ) --r;
    if (++r, n !== 0 || r !== s) {
      n >= r && (r = Math.max(r, 1), n = r - 1);
      const a = this.getValueSize();
      this.times = i.slice(n, r), this.values = this.values.slice(n * a, r * a);
    }
    return this;
  }
  validate() {
    let t = true;
    const e = this.getValueSize();
    e - Math.floor(e) !== 0 && (Y("KeyframeTrack: Invalid value size in track.", this), t = false);
    const i = this.times, s = this.values, n = i.length;
    n === 0 && (Y("KeyframeTrack: Track is empty.", this), t = false);
    let r = null;
    for (let a = 0; a !== n; a++) {
      const o = i[a];
      if (typeof o == "number" && isNaN(o)) {
        Y("KeyframeTrack: Time is not a valid number.", this, a, o), t = false;
        break;
      }
      if (r !== null && r > o) {
        Y("KeyframeTrack: Out of order keys.", this, a, o, r), t = false;
        break;
      }
      r = o;
    }
    if (s !== void 0 && So(s)) for (let a = 0, o = s.length; a !== o; ++a) {
      const h = s[a];
      if (isNaN(h)) {
        Y("KeyframeTrack: Value is not a valid number.", this, a, h), t = false;
        break;
      }
    }
    return t;
  }
  optimize() {
    const t = this.times.slice(), e = this.values.slice(), i = this.getValueSize(), s = this.getInterpolation() === cn, n = t.length - 1;
    let r = 1;
    for (let a = 1; a < n; ++a) {
      let o = false;
      const h = t[a], c = t[a + 1];
      if (h !== c && (a !== 1 || h !== t[0])) if (s) o = true;
      else {
        const u = a * i, d = u - i, p = u + i;
        for (let f = 0; f !== i; ++f) {
          const m = e[u + f];
          if (m !== e[d + f] || m !== e[p + f]) {
            o = true;
            break;
          }
        }
      }
      if (o) {
        if (a !== r) {
          t[r] = t[a];
          const u = a * i, d = r * i;
          for (let p = 0; p !== i; ++p) e[d + p] = e[u + p];
        }
        ++r;
      }
    }
    if (n > 0) {
      t[r] = t[n];
      for (let a = n * i, o = r * i, h = 0; h !== i; ++h) e[o + h] = e[a + h];
      ++r;
    }
    return r !== t.length ? (this.times = t.slice(0, r), this.values = e.slice(0, r * i)) : (this.times = t, this.values = e), this;
  }
  clone() {
    const t = this.times.slice(), e = this.values.slice(), i = this.constructor, s = new i(this.name, t, e);
    return s.createInterpolant = this.createInterpolant, s;
  }
}
qt.prototype.ValueTypeName = "";
qt.prototype.TimeBufferType = Float32Array;
qt.prototype.ValueBufferType = Float32Array;
qt.prototype.DefaultInterpolation = Kn;
class Ai extends qt {
  constructor(t, e, i) {
    super(t, e, i);
  }
}
Ai.prototype.ValueTypeName = "bool";
Ai.prototype.ValueBufferType = Array;
Ai.prototype.DefaultInterpolation = Hs;
Ai.prototype.InterpolantFactoryMethodLinear = void 0;
Ai.prototype.InterpolantFactoryMethodSmooth = void 0;
class Yo extends qt {
  constructor(t, e, i, s) {
    super(t, e, i, s);
  }
}
Yo.prototype.ValueTypeName = "color";
class Qs extends qt {
  constructor(t, e, i, s) {
    super(t, e, i, s);
  }
}
Qs.prototype.ValueTypeName = "number";
class Tu extends Qi {
  constructor(t, e, i, s) {
    super(t, e, i, s);
  }
  interpolate_(t, e, i, s) {
    const n = this.resultBuffer, r = this.sampleValues, a = this.valueSize, o = (i - e) / (s - e);
    let h = t * a;
    for (let c = h + a; h !== c; h += 4) _t.slerpFlat(n, 0, r, h - a, r, h, o);
    return n;
  }
}
class ln extends qt {
  constructor(t, e, i, s) {
    super(t, e, i, s);
  }
  InterpolantFactoryMethodLinear(t) {
    return new Tu(this.times, this.values, this.getValueSize(), t);
  }
}
ln.prototype.ValueTypeName = "quaternion";
ln.prototype.InterpolantFactoryMethodSmooth = void 0;
class Ti extends qt {
  constructor(t, e, i) {
    super(t, e, i);
  }
}
Ti.prototype.ValueTypeName = "string";
Ti.prototype.ValueBufferType = Array;
Ti.prototype.DefaultInterpolation = Hs;
Ti.prototype.InterpolantFactoryMethodLinear = void 0;
Ti.prototype.InterpolantFactoryMethodSmooth = void 0;
class Ks extends qt {
  constructor(t, e, i, s) {
    super(t, e, i, s);
  }
}
Ks.prototype.ValueTypeName = "vector";
class tn {
  constructor(t = "", e = -1, i = [], s = cr) {
    this.name = t, this.tracks = i, this.duration = e, this.blendMode = s, this.uuid = zt(), this.userData = {}, this.duration < 0 && this.resetDuration();
  }
  static parse(t) {
    const e = [], i = t.tracks, s = 1 / (t.fps || 1);
    for (let r = 0, a = i.length; r !== a; ++r) e.push(Iu(i[r]).scale(s));
    const n = new this(t.name, t.duration, e, t.blendMode);
    return n.uuid = t.uuid, n.userData = JSON.parse(t.userData || "{}"), n;
  }
  static toJSON(t) {
    const e = [], i = t.tracks, s = { name: t.name, duration: t.duration, tracks: e, uuid: t.uuid, blendMode: t.blendMode, userData: JSON.stringify(t.userData) };
    for (let n = 0, r = i.length; n !== r; ++n) e.push(qt.toJSON(i[n]));
    return s;
  }
  static CreateFromMorphTargetSequence(t, e, i, s) {
    const n = e.length, r = [];
    for (let a = 0; a < n; a++) {
      let o = [], h = [];
      o.push((a + n - 1) % n, a, (a + 1) % n), h.push(0, 1, 0);
      const c = Xo(o);
      o = nr(o, 1, c), h = nr(h, 1, c), !s && o[0] === 0 && (o.push(n), h.push(h[0])), r.push(new Qs(".morphTargetInfluences[" + e[a].name + "]", o, h).scale(1 / i));
    }
    return new this(t, -1, r);
  }
  static findByName(t, e) {
    let i = t;
    if (!Array.isArray(t)) {
      const s = t;
      i = s.geometry && s.geometry.animations || s.animations;
    }
    for (let s = 0; s < i.length; s++) if (i[s].name === e) return i[s];
    return null;
  }
  static CreateClipsFromMorphTargetSequences(t, e, i) {
    const s = {}, n = /^([\w-]*?)([\d]+)$/;
    for (let a = 0, o = t.length; a < o; a++) {
      const h = t[a], c = h.name.match(n);
      if (c && c.length > 1) {
        const u = c[1];
        let d = s[u];
        d || (s[u] = d = []), d.push(h);
      }
    }
    const r = [];
    for (const a in s) r.push(this.CreateFromMorphTargetSequence(a, s[a], e, i));
    return r;
  }
  static parseAnimation(t, e) {
    if (N("AnimationClip: parseAnimation() is deprecated and will be removed with r185"), !t) return Y("AnimationClip: No animation in JSONLoader data."), null;
    const i = function(u, d, p, f, m) {
      if (p.length !== 0) {
        const g = [], y = [];
        Or(p, g, y, f), g.length !== 0 && m.push(new u(d, g, y));
      }
    }, s = [], n = t.name || "default", r = t.fps || 30, a = t.blendMode;
    let o = t.length || -1;
    const h = t.hierarchy || [];
    for (let u = 0; u < h.length; u++) {
      const d = h[u].keys;
      if (!(!d || d.length === 0)) if (d[0].morphTargets) {
        const p = {};
        let f;
        for (f = 0; f < d.length; f++) if (d[f].morphTargets) for (let m = 0; m < d[f].morphTargets.length; m++) p[d[f].morphTargets[m]] = -1;
        for (const m in p) {
          const g = [], y = [];
          for (let x = 0; x !== d[f].morphTargets.length; ++x) {
            const b = d[f];
            g.push(b.time), y.push(b.morphTarget === m ? 1 : 0);
          }
          s.push(new Qs(".morphTargetInfluence[" + m + "]", g, y));
        }
        o = p.length * r;
      } else {
        const p = ".bones[" + e[u].name + "]";
        i(Ks, p + ".position", d, "pos", s), i(ln, p + ".quaternion", d, "rot", s), i(Ks, p + ".scale", d, "scl", s);
      }
    }
    return s.length === 0 ? null : new this(n, o, s, a);
  }
  resetDuration() {
    const t = this.tracks;
    let e = 0;
    for (let i = 0, s = t.length; i !== s; ++i) {
      const n = this.tracks[i];
      e = Math.max(e, n.times[n.times.length - 1]);
    }
    return this.duration = e, this;
  }
  trim() {
    for (let t = 0; t < this.tracks.length; t++) this.tracks[t].trim(0, this.duration);
    return this;
  }
  validate() {
    let t = true;
    for (let e = 0; e < this.tracks.length; e++) t = t && this.tracks[e].validate();
    return t;
  }
  optimize() {
    for (let t = 0; t < this.tracks.length; t++) this.tracks[t].optimize();
    return this;
  }
  clone() {
    const t = [];
    for (let i = 0; i < this.tracks.length; i++) t.push(this.tracks[i].clone());
    const e = new this.constructor(this.name, this.duration, t, this.blendMode);
    return e.userData = JSON.parse(JSON.stringify(this.userData)), e;
  }
  toJSON() {
    return this.constructor.toJSON(this);
  }
}
function Cu(l) {
  switch (l.toLowerCase()) {
    case "scalar":
    case "double":
    case "float":
    case "number":
    case "integer":
      return Qs;
    case "vector":
    case "vector2":
    case "vector3":
    case "vector4":
      return Ks;
    case "color":
      return Yo;
    case "quaternion":
      return ln;
    case "bool":
    case "boolean":
      return Ai;
    case "string":
      return Ti;
  }
  throw new Error("THREE.KeyframeTrack: Unsupported typeName: " + l);
}
function Iu(l) {
  if (l.type === void 0) throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");
  const t = Cu(l.type);
  if (l.times === void 0) {
    const e = [], i = [];
    Or(l.keys, e, i, "value"), l.times = e, l.values = i;
  }
  return t.parse !== void 0 ? t.parse(l) : new t(l.name, l.times, l.values, l.interpolation);
}
const ue = { enabled: false, files: {}, add: function(l, t) {
  this.enabled !== false && (Qa(l) || (this.files[l] = t));
}, get: function(l) {
  if (this.enabled !== false && !Qa(l)) return this.files[l];
}, remove: function(l) {
  delete this.files[l];
}, clear: function() {
  this.files = {};
} };
function Qa(l) {
  try {
    const t = l.slice(l.indexOf(":") + 1);
    return new URL(t).protocol === "blob:";
  } catch {
    return false;
  }
}
class $o {
  constructor(t, e, i) {
    const s = this;
    let n = false, r = 0, a = 0, o;
    const h = [];
    this.onStart = void 0, this.onLoad = t, this.onProgress = e, this.onError = i, this._abortController = null, this.itemStart = function(c) {
      a++, n === false && s.onStart !== void 0 && s.onStart(c, r, a), n = true;
    }, this.itemEnd = function(c) {
      r++, s.onProgress !== void 0 && s.onProgress(c, r, a), r === a && (n = false, s.onLoad !== void 0 && s.onLoad());
    }, this.itemError = function(c) {
      s.onError !== void 0 && s.onError(c);
    }, this.resolveURL = function(c) {
      return o ? o(c) : c;
    }, this.setURLModifier = function(c) {
      return o = c, this;
    }, this.addHandler = function(c, u) {
      return h.push(c, u), this;
    }, this.removeHandler = function(c) {
      const u = h.indexOf(c);
      return u !== -1 && h.splice(u, 2), this;
    }, this.getHandler = function(c) {
      for (let u = 0, d = h.length; u < d; u += 2) {
        const p = h[u], f = h[u + 1];
        if (p.global && (p.lastIndex = 0), p.test(c)) return f;
      }
      return null;
    }, this.abort = function() {
      return this.abortController.abort(), this._abortController = null, this;
    };
  }
  get abortController() {
    return this._abortController || (this._abortController = new AbortController()), this._abortController;
  }
}
const zu = new $o();
class Ft {
  constructor(t) {
    this.manager = t !== void 0 ? t : zu, this.crossOrigin = "anonymous", this.withCredentials = false, this.path = "", this.resourcePath = "", this.requestHeader = {}, typeof __THREE_DEVTOOLS__ < "u" && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
  }
  load() {
  }
  loadAsync(t, e) {
    const i = this;
    return new Promise(function(s, n) {
      i.load(t, s, e, n);
    });
  }
  parse() {
  }
  setCrossOrigin(t) {
    return this.crossOrigin = t, this;
  }
  setWithCredentials(t) {
    return this.withCredentials = t, this;
  }
  setPath(t) {
    return this.path = t, this;
  }
  setResourcePath(t) {
    return this.resourcePath = t, this;
  }
  setRequestHeader(t) {
    return this.requestHeader = t, this;
  }
  abort() {
    return this;
  }
}
Ft.DEFAULT_MATERIAL_NAME = "__DEFAULT";
const le = {};
class Bu extends Error {
  constructor(t, e) {
    super(t), this.response = e;
  }
}
class ve extends Ft {
  constructor(t) {
    super(t), this.mimeType = "", this.responseType = "", this._abortController = new AbortController();
  }
  load(t, e, i, s) {
    t === void 0 && (t = ""), this.path !== void 0 && (t = this.path + t), t = this.manager.resolveURL(t);
    const n = ue.get(`file:${t}`);
    if (n !== void 0) return this.manager.itemStart(t), setTimeout(() => {
      e && e(n), this.manager.itemEnd(t);
    }, 0), n;
    if (le[t] !== void 0) {
      le[t].push({ onLoad: e, onProgress: i, onError: s });
      return;
    }
    le[t] = [], le[t].push({ onLoad: e, onProgress: i, onError: s });
    const r = new Request(t, { headers: new Headers(this.requestHeader), credentials: this.withCredentials ? "include" : "same-origin", signal: typeof AbortSignal.any == "function" ? AbortSignal.any([this._abortController.signal, this.manager.abortController.signal]) : this._abortController.signal }), a = this.mimeType, o = this.responseType;
    fetch(r).then((h) => {
      if (h.status === 200 || h.status === 0) {
        if (h.status === 0 && N("FileLoader: HTTP Status 0 received."), typeof ReadableStream > "u" || h.body === void 0 || h.body.getReader === void 0) return h;
        const c = le[t], u = h.body.getReader(), d = h.headers.get("X-File-Size") || h.headers.get("Content-Length"), p = d ? parseInt(d) : 0, f = p !== 0;
        let m = 0;
        const g = new ReadableStream({ start(y) {
          x();
          function x() {
            u.read().then(({ done: b, value: M }) => {
              if (b) y.close();
              else {
                m += M.byteLength;
                const _ = new ProgressEvent("progress", { lengthComputable: f, loaded: m, total: p });
                for (let v = 0, A = c.length; v < A; v++) {
                  const S = c[v];
                  S.onProgress && S.onProgress(_);
                }
                y.enqueue(M), x();
              }
            }, (b) => {
              y.error(b);
            });
          }
        } });
        return new Response(g);
      } else throw new Bu(`fetch for "${h.url}" responded with ${h.status}: ${h.statusText}`, h);
    }).then((h) => {
      switch (o) {
        case "arraybuffer":
          return h.arrayBuffer();
        case "blob":
          return h.blob();
        case "document":
          return h.text().then((c) => new DOMParser().parseFromString(c, a));
        case "json":
          return h.json();
        default:
          if (a === "") return h.text();
          {
            const u = /charset="?([^;"\s]*)"?/i.exec(a), d = u && u[1] ? u[1].toLowerCase() : void 0, p = new TextDecoder(d);
            return h.arrayBuffer().then((f) => p.decode(f));
          }
      }
    }).then((h) => {
      ue.add(`file:${t}`, h);
      const c = le[t];
      delete le[t];
      for (let u = 0, d = c.length; u < d; u++) {
        const p = c[u];
        p.onLoad && p.onLoad(h);
      }
    }).catch((h) => {
      const c = le[t];
      if (c === void 0) throw this.manager.itemError(t), h;
      delete le[t];
      for (let u = 0, d = c.length; u < d; u++) {
        const p = c[u];
        p.onError && p.onError(h);
      }
      this.manager.itemError(t);
    }).finally(() => {
      this.manager.itemEnd(t);
    }), this.manager.itemStart(t);
  }
  setResponseType(t) {
    return this.responseType = t, this;
  }
  setMimeType(t) {
    return this.mimeType = t, this;
  }
  abort() {
    return this._abortController.abort(), this._abortController = new AbortController(), this;
  }
}
class zf extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    const n = this, r = new ve(this.manager);
    r.setPath(this.path), r.setRequestHeader(this.requestHeader), r.setWithCredentials(this.withCredentials), r.load(t, function(a) {
      try {
        e(n.parse(JSON.parse(a)));
      } catch (o) {
        s ? s(o) : Y(o), n.manager.itemError(t);
      }
    }, i, s);
  }
  parse(t) {
    const e = [];
    for (let i = 0; i < t.length; i++) {
      const s = tn.parse(t[i]);
      e.push(s);
    }
    return e;
  }
}
class Bf extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    const n = this, r = [], a = new xr(), o = new ve(this.manager);
    o.setPath(this.path), o.setResponseType("arraybuffer"), o.setRequestHeader(this.requestHeader), o.setWithCredentials(n.withCredentials);
    let h = 0;
    function c(u) {
      o.load(t[u], function(d) {
        const p = n.parse(d, true);
        r[u] = { width: p.width, height: p.height, format: p.format, mipmaps: p.mipmaps }, h += 1, h === 6 && (p.mipmapCount === 1 && (a.minFilter = Gt), a.image = r, a.format = p.format, a.needsUpdate = true, e && e(a));
      }, i, s);
    }
    if (Array.isArray(t)) for (let u = 0, d = t.length; u < d; ++u) c(u);
    else o.load(t, function(u) {
      const d = n.parse(u, true);
      if (d.isCubemap) {
        const p = d.mipmaps.length / d.mipmapCount;
        for (let f = 0; f < p; f++) {
          r[f] = { mipmaps: [] };
          for (let m = 0; m < d.mipmapCount; m++) r[f].mipmaps.push(d.mipmaps[f * d.mipmapCount + m]), r[f].format = d.format, r[f].width = d.width, r[f].height = d.height;
        }
        a.image = r;
      } else a.image.width = d.width, a.image.height = d.height, a.mipmaps = d.mipmaps;
      d.mipmapCount === 1 && (a.minFilter = Gt), a.format = d.format, a.needsUpdate = true, e && e(a);
    }, i, s);
    return a;
  }
}
const li = /* @__PURE__ */ new WeakMap();
class en extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    this.path !== void 0 && (t = this.path + t), t = this.manager.resolveURL(t);
    const n = this, r = ue.get(`image:${t}`);
    if (r !== void 0) {
      if (r.complete === true) n.manager.itemStart(t), setTimeout(function() {
        e && e(r), n.manager.itemEnd(t);
      }, 0);
      else {
        let u = li.get(r);
        u === void 0 && (u = [], li.set(r, u)), u.push({ onLoad: e, onError: s });
      }
      return r;
    }
    const a = Zs("img");
    function o() {
      c(), e && e(this);
      const u = li.get(this) || [];
      for (let d = 0; d < u.length; d++) {
        const p = u[d];
        p.onLoad && p.onLoad(this);
      }
      li.delete(this), n.manager.itemEnd(t);
    }
    function h(u) {
      c(), s && s(u), ue.remove(`image:${t}`);
      const d = li.get(this) || [];
      for (let p = 0; p < d.length; p++) {
        const f = d[p];
        f.onError && f.onError(u);
      }
      li.delete(this), n.manager.itemError(t), n.manager.itemEnd(t);
    }
    function c() {
      a.removeEventListener("load", o, false), a.removeEventListener("error", h, false);
    }
    return a.addEventListener("load", o, false), a.addEventListener("error", h, false), t.slice(0, 5) !== "data:" && this.crossOrigin !== void 0 && (a.crossOrigin = this.crossOrigin), ue.add(`image:${t}`, a), n.manager.itemStart(t), a.src = t, a;
  }
}
class Ff extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    const n = new Oo();
    n.colorSpace = Ot;
    const r = new en(this.manager);
    r.setCrossOrigin(this.crossOrigin), r.setPath(this.path);
    let a = 0;
    function o(h) {
      r.load(t[h], function(c) {
        n.images[h] = c, a++, a === 6 && (n.needsUpdate = true, e && e(n));
      }, void 0, s);
    }
    for (let h = 0; h < t.length; ++h) o(h);
    return n;
  }
}
class kf extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    const n = this, r = new pe(), a = new ve(this.manager);
    return a.setResponseType("arraybuffer"), a.setRequestHeader(this.requestHeader), a.setPath(this.path), a.setWithCredentials(n.withCredentials), a.load(t, function(o) {
      let h;
      try {
        h = n.parse(o);
      } catch (c) {
        if (s !== void 0) s(c);
        else {
          c(c);
          return;
        }
      }
      h.image !== void 0 ? r.image = h.image : h.data !== void 0 && (r.image.width = h.width, r.image.height = h.height, r.image.data = h.data), r.wrapS = h.wrapS !== void 0 ? h.wrapS : Zt, r.wrapT = h.wrapT !== void 0 ? h.wrapT : Zt, r.magFilter = h.magFilter !== void 0 ? h.magFilter : Gt, r.minFilter = h.minFilter !== void 0 ? h.minFilter : Gt, r.anisotropy = h.anisotropy !== void 0 ? h.anisotropy : 1, h.colorSpace !== void 0 && (r.colorSpace = h.colorSpace), h.flipY !== void 0 && (r.flipY = h.flipY), h.format !== void 0 && (r.format = h.format), h.type !== void 0 && (r.type = h.type), h.mipmaps !== void 0 && (r.mipmaps = h.mipmaps, r.minFilter = hr), h.mipmapCount === 1 && (r.minFilter = Gt), h.generateMipmaps !== void 0 && (r.generateMipmaps = h.generateMipmaps), r.needsUpdate = true, e && e(r, h);
    }, i, s), r;
  }
}
class Pf extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    const n = new lt(), r = new en(this.manager);
    return r.setCrossOrigin(this.crossOrigin), r.setPath(this.path), r.load(t, function(a) {
      n.image = a, n.needsUpdate = true, e !== void 0 && e(n);
    }, i, s), n;
  }
}
class qe extends $ {
  constructor(t, e = 1) {
    super(), this.isLight = true, this.type = "Light", this.color = new U(t), this.intensity = e;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
  copy(t, e) {
    return super.copy(t, e), this.color.copy(t.color), this.intensity = t.intensity, this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.color = this.color.getHex(), e.object.intensity = this.intensity, e;
  }
}
class Fu extends qe {
  constructor(t, e, i) {
    super(t, i), this.isHemisphereLight = true, this.type = "HemisphereLight", this.position.copy($.DEFAULT_UP), this.updateMatrix(), this.groundColor = new U(e);
  }
  copy(t, e) {
    return super.copy(t, e), this.groundColor.copy(t.groundColor), this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.groundColor = this.groundColor.getHex(), e;
  }
}
const Gn = new G(), Ka = new w(), to = new w();
class Er {
  constructor(t) {
    this.camera = t, this.intensity = 1, this.bias = 0, this.biasNode = null, this.normalBias = 0, this.radius = 1, this.blurSamples = 8, this.mapSize = new I(512, 512), this.mapType = lr, this.map = null, this.mapPass = null, this.matrix = new G(), this.autoUpdate = true, this.needsUpdate = false, this._frustum = new yr(), this._frameExtents = new I(1, 1), this._viewportCount = 1, this._viewports = [new Nt(0, 0, 1, 1)];
  }
  getViewportCount() {
    return this._viewportCount;
  }
  getFrustum() {
    return this._frustum;
  }
  updateMatrices(t) {
    const e = this.camera, i = this.matrix;
    Ka.setFromMatrixPosition(t.matrixWorld), e.position.copy(Ka), to.setFromMatrixPosition(t.target.matrixWorld), e.lookAt(to), e.updateMatrixWorld(), Gn.multiplyMatrices(e.projectionMatrix, e.matrixWorldInverse), this._frustum.setFromProjectionMatrix(Gn, e.coordinateSystem, e.reversedDepth), e.coordinateSystem === Mi || e.reversedDepth ? i.set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 1, 0, 0, 0, 0, 1) : i.set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1), i.multiply(Gn);
  }
  getViewport(t) {
    return this._viewports[t];
  }
  getFrameExtents() {
    return this._frameExtents;
  }
  dispose() {
    this.map && this.map.dispose(), this.mapPass && this.mapPass.dispose();
  }
  copy(t) {
    return this.camera = t.camera.clone(), this.intensity = t.intensity, this.bias = t.bias, this.radius = t.radius, this.autoUpdate = t.autoUpdate, this.needsUpdate = t.needsUpdate, this.normalBias = t.normalBias, this.blurSamples = t.blurSamples, this.mapSize.copy(t.mapSize), this.biasNode = t.biasNode, this;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  toJSON() {
    const t = {};
    return this.intensity !== 1 && (t.intensity = this.intensity), this.bias !== 0 && (t.bias = this.bias), this.normalBias !== 0 && (t.normalBias = this.normalBias), this.radius !== 1 && (t.radius = this.radius), (this.mapSize.x !== 512 || this.mapSize.y !== 512) && (t.mapSize = this.mapSize.toArray()), t.camera = this.camera.toJSON(false).object, delete t.camera.matrix, t;
  }
}
const Os = new w(), Es = new _t(), Xt = new w();
class Nr extends $ {
  constructor() {
    super(), this.isCamera = true, this.type = "Camera", this.matrixWorldInverse = new G(), this.projectionMatrix = new G(), this.projectionMatrixInverse = new G(), this.coordinateSystem = Yt, this._reversedDepth = false;
  }
  get reversedDepth() {
    return this._reversedDepth;
  }
  copy(t, e) {
    return super.copy(t, e), this.matrixWorldInverse.copy(t.matrixWorldInverse), this.projectionMatrix.copy(t.projectionMatrix), this.projectionMatrixInverse.copy(t.projectionMatrixInverse), this.coordinateSystem = t.coordinateSystem, this;
  }
  getWorldDirection(t) {
    return super.getWorldDirection(t).negate();
  }
  updateMatrixWorld(t) {
    super.updateMatrixWorld(t), this.matrixWorld.decompose(Os, Es, Xt), Xt.x === 1 && Xt.y === 1 && Xt.z === 1 ? this.matrixWorldInverse.copy(this.matrixWorld).invert() : this.matrixWorldInverse.compose(Os, Es, Xt.set(1, 1, 1)).invert();
  }
  updateWorldMatrix(t, e) {
    super.updateWorldMatrix(t, e), this.matrixWorld.decompose(Os, Es, Xt), Xt.x === 1 && Xt.y === 1 && Xt.z === 1 ? this.matrixWorldInverse.copy(this.matrixWorld).invert() : this.matrixWorldInverse.compose(Os, Es, Xt.set(1, 1, 1)).invert();
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
const Me = new w(), eo = new I(), io = new I();
class Et extends Nr {
  constructor(t = 50, e = 1, i = 0.1, s = 2e3) {
    super(), this.isPerspectiveCamera = true, this.type = "PerspectiveCamera", this.fov = t, this.zoom = 1, this.near = i, this.far = s, this.focus = 10, this.aspect = e, this.view = null, this.filmGauge = 35, this.filmOffset = 0, this.updateProjectionMatrix();
  }
  copy(t, e) {
    return super.copy(t, e), this.fov = t.fov, this.zoom = t.zoom, this.near = t.near, this.far = t.far, this.focus = t.focus, this.aspect = t.aspect, this.view = t.view === null ? null : Object.assign({}, t.view), this.filmGauge = t.filmGauge, this.filmOffset = t.filmOffset, this;
  }
  setFocalLength(t) {
    const e = 0.5 * this.getFilmHeight() / t;
    this.fov = Ji * 2 * Math.atan(e), this.updateProjectionMatrix();
  }
  getFocalLength() {
    const t = Math.tan(Ve * 0.5 * this.fov);
    return 0.5 * this.getFilmHeight() / t;
  }
  getEffectiveFOV() {
    return Ji * 2 * Math.atan(Math.tan(Ve * 0.5 * this.fov) / this.zoom);
  }
  getFilmWidth() {
    return this.filmGauge * Math.min(this.aspect, 1);
  }
  getFilmHeight() {
    return this.filmGauge / Math.max(this.aspect, 1);
  }
  getViewBounds(t, e, i) {
    Me.set(-1, -1, 0.5).applyMatrix4(this.projectionMatrixInverse), e.set(Me.x, Me.y).multiplyScalar(-t / Me.z), Me.set(1, 1, 0.5).applyMatrix4(this.projectionMatrixInverse), i.set(Me.x, Me.y).multiplyScalar(-t / Me.z);
  }
  getViewSize(t, e) {
    return this.getViewBounds(t, eo, io), e.subVectors(io, eo);
  }
  setViewOffset(t, e, i, s, n, r) {
    this.aspect = t / e, this.view === null && (this.view = { enabled: true, fullWidth: 1, fullHeight: 1, offsetX: 0, offsetY: 0, width: 1, height: 1 }), this.view.enabled = true, this.view.fullWidth = t, this.view.fullHeight = e, this.view.offsetX = i, this.view.offsetY = s, this.view.width = n, this.view.height = r, this.updateProjectionMatrix();
  }
  clearViewOffset() {
    this.view !== null && (this.view.enabled = false), this.updateProjectionMatrix();
  }
  updateProjectionMatrix() {
    const t = this.near;
    let e = t * Math.tan(Ve * 0.5 * this.fov) / this.zoom, i = 2 * e, s = this.aspect * i, n = -0.5 * s;
    const r = this.view;
    if (this.view !== null && this.view.enabled) {
      const o = r.fullWidth, h = r.fullHeight;
      n += r.offsetX * s / o, e -= r.offsetY * i / h, s *= r.width / o, i *= r.height / h;
    }
    const a = this.filmOffset;
    a !== 0 && (n += t * a / this.getFilmWidth()), this.projectionMatrix.makePerspective(n, n + s, e, e - i, t, this.far, this.coordinateSystem, this.reversedDepth), this.projectionMatrixInverse.copy(this.projectionMatrix).invert();
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.fov = this.fov, e.object.zoom = this.zoom, e.object.near = this.near, e.object.far = this.far, e.object.focus = this.focus, e.object.aspect = this.aspect, this.view !== null && (e.object.view = Object.assign({}, this.view)), e.object.filmGauge = this.filmGauge, e.object.filmOffset = this.filmOffset, e;
  }
}
class ku extends Er {
  constructor() {
    super(new Et(50, 1, 0.5, 500)), this.isSpotLightShadow = true, this.focus = 1, this.aspect = 1;
  }
  updateMatrices(t) {
    const e = this.camera, i = Ji * 2 * t.angle * this.focus, s = this.mapSize.width / this.mapSize.height * this.aspect, n = t.distance || e.far;
    (i !== e.fov || s !== e.aspect || n !== e.far) && (e.fov = i, e.aspect = s, e.far = n, e.updateProjectionMatrix()), super.updateMatrices(t);
  }
  copy(t) {
    return super.copy(t), this.focus = t.focus, this;
  }
}
class Pu extends qe {
  constructor(t, e, i = 0, s = Math.PI / 3, n = 0, r = 2) {
    super(t, e), this.isSpotLight = true, this.type = "SpotLight", this.position.copy($.DEFAULT_UP), this.updateMatrix(), this.target = new $(), this.distance = i, this.angle = s, this.penumbra = n, this.decay = r, this.map = null, this.shadow = new ku();
  }
  get power() {
    return this.intensity * Math.PI;
  }
  set power(t) {
    this.intensity = t / Math.PI;
  }
  dispose() {
    super.dispose(), this.shadow.dispose();
  }
  copy(t, e) {
    return super.copy(t, e), this.distance = t.distance, this.angle = t.angle, this.penumbra = t.penumbra, this.decay = t.decay, this.target = t.target.clone(), this.map = t.map, this.shadow = t.shadow.clone(), this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.distance = this.distance, e.object.angle = this.angle, e.object.decay = this.decay, e.object.penumbra = this.penumbra, e.object.target = this.target.uuid, this.map && this.map.isTexture && (e.object.map = this.map.toJSON(t).uuid), e.object.shadow = this.shadow.toJSON(), e;
  }
}
class Ru extends Er {
  constructor() {
    super(new Et(90, 1, 0.5, 500)), this.isPointLightShadow = true;
  }
}
class Ou extends qe {
  constructor(t, e, i = 0, s = 2) {
    super(t, e), this.isPointLight = true, this.type = "PointLight", this.distance = i, this.decay = s, this.shadow = new Ru();
  }
  get power() {
    return this.intensity * 4 * Math.PI;
  }
  set power(t) {
    this.intensity = t / (4 * Math.PI);
  }
  dispose() {
    super.dispose(), this.shadow.dispose();
  }
  copy(t, e) {
    return super.copy(t, e), this.distance = t.distance, this.decay = t.decay, this.shadow = t.shadow.clone(), this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.distance = this.distance, e.object.decay = this.decay, e.object.shadow = this.shadow.toJSON(), e;
  }
}
class jo extends Nr {
  constructor(t = -1, e = 1, i = 1, s = -1, n = 0.1, r = 2e3) {
    super(), this.isOrthographicCamera = true, this.type = "OrthographicCamera", this.zoom = 1, this.view = null, this.left = t, this.right = e, this.top = i, this.bottom = s, this.near = n, this.far = r, this.updateProjectionMatrix();
  }
  copy(t, e) {
    return super.copy(t, e), this.left = t.left, this.right = t.right, this.top = t.top, this.bottom = t.bottom, this.near = t.near, this.far = t.far, this.zoom = t.zoom, this.view = t.view === null ? null : Object.assign({}, t.view), this;
  }
  setViewOffset(t, e, i, s, n, r) {
    this.view === null && (this.view = { enabled: true, fullWidth: 1, fullHeight: 1, offsetX: 0, offsetY: 0, width: 1, height: 1 }), this.view.enabled = true, this.view.fullWidth = t, this.view.fullHeight = e, this.view.offsetX = i, this.view.offsetY = s, this.view.width = n, this.view.height = r, this.updateProjectionMatrix();
  }
  clearViewOffset() {
    this.view !== null && (this.view.enabled = false), this.updateProjectionMatrix();
  }
  updateProjectionMatrix() {
    const t = (this.right - this.left) / (2 * this.zoom), e = (this.top - this.bottom) / (2 * this.zoom), i = (this.right + this.left) / 2, s = (this.top + this.bottom) / 2;
    let n = i - t, r = i + t, a = s + e, o = s - e;
    if (this.view !== null && this.view.enabled) {
      const h = (this.right - this.left) / this.view.fullWidth / this.zoom, c = (this.top - this.bottom) / this.view.fullHeight / this.zoom;
      n += h * this.view.offsetX, r = n + h * this.view.width, a -= c * this.view.offsetY, o = a - c * this.view.height;
    }
    this.projectionMatrix.makeOrthographic(n, r, a, o, this.near, this.far, this.coordinateSystem, this.reversedDepth), this.projectionMatrixInverse.copy(this.projectionMatrix).invert();
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.zoom = this.zoom, e.object.left = this.left, e.object.right = this.right, e.object.top = this.top, e.object.bottom = this.bottom, e.object.near = this.near, e.object.far = this.far, this.view !== null && (e.object.view = Object.assign({}, this.view)), e;
  }
}
class Eu extends Er {
  constructor() {
    super(new jo(-5, 5, 5, -5, 0.5, 500)), this.isDirectionalLightShadow = true;
  }
}
class Nu extends qe {
  constructor(t, e) {
    super(t, e), this.isDirectionalLight = true, this.type = "DirectionalLight", this.position.copy($.DEFAULT_UP), this.updateMatrix(), this.target = new $(), this.shadow = new Eu();
  }
  dispose() {
    super.dispose(), this.shadow.dispose();
  }
  copy(t) {
    return super.copy(t), this.target = t.target.clone(), this.shadow = t.shadow.clone(), this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.shadow = this.shadow.toJSON(), e.object.target = this.target.uuid, e;
  }
}
class Lu extends qe {
  constructor(t, e) {
    super(t, e), this.isAmbientLight = true, this.type = "AmbientLight";
  }
}
class Du extends qe {
  constructor(t, e, i = 10, s = 10) {
    super(t, e), this.isRectAreaLight = true, this.type = "RectAreaLight", this.width = i, this.height = s;
  }
  get power() {
    return this.intensity * this.width * this.height * Math.PI;
  }
  set power(t) {
    this.intensity = t / (this.width * this.height * Math.PI);
  }
  copy(t) {
    return super.copy(t), this.width = t.width, this.height = t.height, this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.width = this.width, e.object.height = this.height, e;
  }
}
class Qo {
  constructor() {
    this.isSphericalHarmonics3 = true, this.coefficients = [];
    for (let t = 0; t < 9; t++) this.coefficients.push(new w());
  }
  set(t) {
    for (let e = 0; e < 9; e++) this.coefficients[e].copy(t[e]);
    return this;
  }
  zero() {
    for (let t = 0; t < 9; t++) this.coefficients[t].set(0, 0, 0);
    return this;
  }
  getAt(t, e) {
    const i = t.x, s = t.y, n = t.z, r = this.coefficients;
    return e.copy(r[0]).multiplyScalar(0.282095), e.addScaledVector(r[1], 0.488603 * s), e.addScaledVector(r[2], 0.488603 * n), e.addScaledVector(r[3], 0.488603 * i), e.addScaledVector(r[4], 1.092548 * (i * s)), e.addScaledVector(r[5], 1.092548 * (s * n)), e.addScaledVector(r[6], 0.315392 * (3 * n * n - 1)), e.addScaledVector(r[7], 1.092548 * (i * n)), e.addScaledVector(r[8], 0.546274 * (i * i - s * s)), e;
  }
  getIrradianceAt(t, e) {
    const i = t.x, s = t.y, n = t.z, r = this.coefficients;
    return e.copy(r[0]).multiplyScalar(0.886227), e.addScaledVector(r[1], 2 * 0.511664 * s), e.addScaledVector(r[2], 2 * 0.511664 * n), e.addScaledVector(r[3], 2 * 0.511664 * i), e.addScaledVector(r[4], 2 * 0.429043 * i * s), e.addScaledVector(r[5], 2 * 0.429043 * s * n), e.addScaledVector(r[6], 0.743125 * n * n - 0.247708), e.addScaledVector(r[7], 2 * 0.429043 * i * n), e.addScaledVector(r[8], 0.429043 * (i * i - s * s)), e;
  }
  add(t) {
    for (let e = 0; e < 9; e++) this.coefficients[e].add(t.coefficients[e]);
    return this;
  }
  addScaledSH(t, e) {
    for (let i = 0; i < 9; i++) this.coefficients[i].addScaledVector(t.coefficients[i], e);
    return this;
  }
  scale(t) {
    for (let e = 0; e < 9; e++) this.coefficients[e].multiplyScalar(t);
    return this;
  }
  lerp(t, e) {
    for (let i = 0; i < 9; i++) this.coefficients[i].lerp(t.coefficients[i], e);
    return this;
  }
  equals(t) {
    for (let e = 0; e < 9; e++) if (!this.coefficients[e].equals(t.coefficients[e])) return false;
    return true;
  }
  copy(t) {
    return this.set(t.coefficients);
  }
  clone() {
    return new this.constructor().copy(this);
  }
  fromArray(t, e = 0) {
    const i = this.coefficients;
    for (let s = 0; s < 9; s++) i[s].fromArray(t, e + s * 3);
    return this;
  }
  toArray(t = [], e = 0) {
    const i = this.coefficients;
    for (let s = 0; s < 9; s++) i[s].toArray(t, e + s * 3);
    return t;
  }
  static getBasisAt(t, e) {
    const i = t.x, s = t.y, n = t.z;
    e[0] = 0.282095, e[1] = 0.488603 * s, e[2] = 0.488603 * n, e[3] = 0.488603 * i, e[4] = 1.092548 * i * s, e[5] = 1.092548 * s * n, e[6] = 0.315392 * (3 * n * n - 1), e[7] = 1.092548 * i * n, e[8] = 0.546274 * (i * i - s * s);
  }
}
class Vu extends qe {
  constructor(t = new Qo(), e = 1) {
    super(void 0, e), this.isLightProbe = true, this.sh = t;
  }
  copy(t) {
    return super.copy(t), this.sh.copy(t.sh), this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.sh = this.sh.toArray(), e;
  }
}
class Lr extends Ft {
  constructor(t) {
    super(t), this.textures = {};
  }
  load(t, e, i, s) {
    const n = this, r = new ve(n.manager);
    r.setPath(n.path), r.setRequestHeader(n.requestHeader), r.setWithCredentials(n.withCredentials), r.load(t, function(a) {
      try {
        e(n.parse(JSON.parse(a)));
      } catch (o) {
        s ? s(o) : Y(o), n.manager.itemError(t);
      }
    }, i, s);
  }
  parse(t) {
    const e = this.textures;
    function i(n) {
      return e[n] === void 0 && N("MaterialLoader: Undefined texture", n), e[n];
    }
    const s = this.createMaterialFromType(t.type);
    if (t.uuid !== void 0 && (s.uuid = t.uuid), t.name !== void 0 && (s.name = t.name), t.color !== void 0 && s.color !== void 0 && s.color.setHex(t.color), t.roughness !== void 0 && (s.roughness = t.roughness), t.metalness !== void 0 && (s.metalness = t.metalness), t.sheen !== void 0 && (s.sheen = t.sheen), t.sheenColor !== void 0 && (s.sheenColor = new U().setHex(t.sheenColor)), t.sheenRoughness !== void 0 && (s.sheenRoughness = t.sheenRoughness), t.emissive !== void 0 && s.emissive !== void 0 && s.emissive.setHex(t.emissive), t.specular !== void 0 && s.specular !== void 0 && s.specular.setHex(t.specular), t.specularIntensity !== void 0 && (s.specularIntensity = t.specularIntensity), t.specularColor !== void 0 && s.specularColor !== void 0 && s.specularColor.setHex(t.specularColor), t.shininess !== void 0 && (s.shininess = t.shininess), t.clearcoat !== void 0 && (s.clearcoat = t.clearcoat), t.clearcoatRoughness !== void 0 && (s.clearcoatRoughness = t.clearcoatRoughness), t.dispersion !== void 0 && (s.dispersion = t.dispersion), t.iridescence !== void 0 && (s.iridescence = t.iridescence), t.iridescenceIOR !== void 0 && (s.iridescenceIOR = t.iridescenceIOR), t.iridescenceThicknessRange !== void 0 && (s.iridescenceThicknessRange = t.iridescenceThicknessRange), t.transmission !== void 0 && (s.transmission = t.transmission), t.thickness !== void 0 && (s.thickness = t.thickness), t.attenuationDistance !== void 0 && (s.attenuationDistance = t.attenuationDistance), t.attenuationColor !== void 0 && s.attenuationColor !== void 0 && s.attenuationColor.setHex(t.attenuationColor), t.anisotropy !== void 0 && (s.anisotropy = t.anisotropy), t.anisotropyRotation !== void 0 && (s.anisotropyRotation = t.anisotropyRotation), t.fog !== void 0 && (s.fog = t.fog), t.flatShading !== void 0 && (s.flatShading = t.flatShading), t.blending !== void 0 && (s.blending = t.blending), t.combine !== void 0 && (s.combine = t.combine), t.side !== void 0 && (s.side = t.side), t.shadowSide !== void 0 && (s.shadowSide = t.shadowSide), t.opacity !== void 0 && (s.opacity = t.opacity), t.transparent !== void 0 && (s.transparent = t.transparent), t.alphaTest !== void 0 && (s.alphaTest = t.alphaTest), t.alphaHash !== void 0 && (s.alphaHash = t.alphaHash), t.depthFunc !== void 0 && (s.depthFunc = t.depthFunc), t.depthTest !== void 0 && (s.depthTest = t.depthTest), t.depthWrite !== void 0 && (s.depthWrite = t.depthWrite), t.colorWrite !== void 0 && (s.colorWrite = t.colorWrite), t.blendSrc !== void 0 && (s.blendSrc = t.blendSrc), t.blendDst !== void 0 && (s.blendDst = t.blendDst), t.blendEquation !== void 0 && (s.blendEquation = t.blendEquation), t.blendSrcAlpha !== void 0 && (s.blendSrcAlpha = t.blendSrcAlpha), t.blendDstAlpha !== void 0 && (s.blendDstAlpha = t.blendDstAlpha), t.blendEquationAlpha !== void 0 && (s.blendEquationAlpha = t.blendEquationAlpha), t.blendColor !== void 0 && s.blendColor !== void 0 && s.blendColor.setHex(t.blendColor), t.blendAlpha !== void 0 && (s.blendAlpha = t.blendAlpha), t.stencilWriteMask !== void 0 && (s.stencilWriteMask = t.stencilWriteMask), t.stencilFunc !== void 0 && (s.stencilFunc = t.stencilFunc), t.stencilRef !== void 0 && (s.stencilRef = t.stencilRef), t.stencilFuncMask !== void 0 && (s.stencilFuncMask = t.stencilFuncMask), t.stencilFail !== void 0 && (s.stencilFail = t.stencilFail), t.stencilZFail !== void 0 && (s.stencilZFail = t.stencilZFail), t.stencilZPass !== void 0 && (s.stencilZPass = t.stencilZPass), t.stencilWrite !== void 0 && (s.stencilWrite = t.stencilWrite), t.wireframe !== void 0 && (s.wireframe = t.wireframe), t.wireframeLinewidth !== void 0 && (s.wireframeLinewidth = t.wireframeLinewidth), t.wireframeLinecap !== void 0 && (s.wireframeLinecap = t.wireframeLinecap), t.wireframeLinejoin !== void 0 && (s.wireframeLinejoin = t.wireframeLinejoin), t.rotation !== void 0 && (s.rotation = t.rotation), t.linewidth !== void 0 && (s.linewidth = t.linewidth), t.dashSize !== void 0 && (s.dashSize = t.dashSize), t.gapSize !== void 0 && (s.gapSize = t.gapSize), t.scale !== void 0 && (s.scale = t.scale), t.polygonOffset !== void 0 && (s.polygonOffset = t.polygonOffset), t.polygonOffsetFactor !== void 0 && (s.polygonOffsetFactor = t.polygonOffsetFactor), t.polygonOffsetUnits !== void 0 && (s.polygonOffsetUnits = t.polygonOffsetUnits), t.dithering !== void 0 && (s.dithering = t.dithering), t.alphaToCoverage !== void 0 && (s.alphaToCoverage = t.alphaToCoverage), t.premultipliedAlpha !== void 0 && (s.premultipliedAlpha = t.premultipliedAlpha), t.forceSinglePass !== void 0 && (s.forceSinglePass = t.forceSinglePass), t.allowOverride !== void 0 && (s.allowOverride = t.allowOverride), t.visible !== void 0 && (s.visible = t.visible), t.toneMapped !== void 0 && (s.toneMapped = t.toneMapped), t.userData !== void 0 && (s.userData = t.userData), t.vertexColors !== void 0 && (typeof t.vertexColors == "number" ? s.vertexColors = t.vertexColors > 0 : s.vertexColors = t.vertexColors), t.uniforms !== void 0) for (const n in t.uniforms) {
      const r = t.uniforms[n];
      switch (s.uniforms[n] = {}, r.type) {
        case "t":
          s.uniforms[n].value = i(r.value);
          break;
        case "c":
          s.uniforms[n].value = new U().setHex(r.value);
          break;
        case "v2":
          s.uniforms[n].value = new I().fromArray(r.value);
          break;
        case "v3":
          s.uniforms[n].value = new w().fromArray(r.value);
          break;
        case "v4":
          s.uniforms[n].value = new Nt().fromArray(r.value);
          break;
        case "m3":
          s.uniforms[n].value = new Qt().fromArray(r.value);
          break;
        case "m4":
          s.uniforms[n].value = new G().fromArray(r.value);
          break;
        default:
          s.uniforms[n].value = r.value;
      }
    }
    if (t.defines !== void 0 && (s.defines = t.defines), t.vertexShader !== void 0 && (s.vertexShader = t.vertexShader), t.fragmentShader !== void 0 && (s.fragmentShader = t.fragmentShader), t.glslVersion !== void 0 && (s.glslVersion = t.glslVersion), t.extensions !== void 0) for (const n in t.extensions) s.extensions[n] = t.extensions[n];
    if (t.lights !== void 0 && (s.lights = t.lights), t.clipping !== void 0 && (s.clipping = t.clipping), t.size !== void 0 && (s.size = t.size), t.sizeAttenuation !== void 0 && (s.sizeAttenuation = t.sizeAttenuation), t.map !== void 0 && (s.map = i(t.map)), t.matcap !== void 0 && (s.matcap = i(t.matcap)), t.alphaMap !== void 0 && (s.alphaMap = i(t.alphaMap)), t.bumpMap !== void 0 && (s.bumpMap = i(t.bumpMap)), t.bumpScale !== void 0 && (s.bumpScale = t.bumpScale), t.normalMap !== void 0 && (s.normalMap = i(t.normalMap)), t.normalMapType !== void 0 && (s.normalMapType = t.normalMapType), t.normalScale !== void 0) {
      let n = t.normalScale;
      Array.isArray(n) === false && (n = [n, n]), s.normalScale = new I().fromArray(n);
    }
    return t.displacementMap !== void 0 && (s.displacementMap = i(t.displacementMap)), t.displacementScale !== void 0 && (s.displacementScale = t.displacementScale), t.displacementBias !== void 0 && (s.displacementBias = t.displacementBias), t.roughnessMap !== void 0 && (s.roughnessMap = i(t.roughnessMap)), t.metalnessMap !== void 0 && (s.metalnessMap = i(t.metalnessMap)), t.emissiveMap !== void 0 && (s.emissiveMap = i(t.emissiveMap)), t.emissiveIntensity !== void 0 && (s.emissiveIntensity = t.emissiveIntensity), t.specularMap !== void 0 && (s.specularMap = i(t.specularMap)), t.specularIntensityMap !== void 0 && (s.specularIntensityMap = i(t.specularIntensityMap)), t.specularColorMap !== void 0 && (s.specularColorMap = i(t.specularColorMap)), t.envMap !== void 0 && (s.envMap = i(t.envMap)), t.envMapRotation !== void 0 && s.envMapRotation.fromArray(t.envMapRotation), t.envMapIntensity !== void 0 && (s.envMapIntensity = t.envMapIntensity), t.reflectivity !== void 0 && (s.reflectivity = t.reflectivity), t.refractionRatio !== void 0 && (s.refractionRatio = t.refractionRatio), t.lightMap !== void 0 && (s.lightMap = i(t.lightMap)), t.lightMapIntensity !== void 0 && (s.lightMapIntensity = t.lightMapIntensity), t.aoMap !== void 0 && (s.aoMap = i(t.aoMap)), t.aoMapIntensity !== void 0 && (s.aoMapIntensity = t.aoMapIntensity), t.gradientMap !== void 0 && (s.gradientMap = i(t.gradientMap)), t.clearcoatMap !== void 0 && (s.clearcoatMap = i(t.clearcoatMap)), t.clearcoatRoughnessMap !== void 0 && (s.clearcoatRoughnessMap = i(t.clearcoatRoughnessMap)), t.clearcoatNormalMap !== void 0 && (s.clearcoatNormalMap = i(t.clearcoatNormalMap)), t.clearcoatNormalScale !== void 0 && (s.clearcoatNormalScale = new I().fromArray(t.clearcoatNormalScale)), t.iridescenceMap !== void 0 && (s.iridescenceMap = i(t.iridescenceMap)), t.iridescenceThicknessMap !== void 0 && (s.iridescenceThicknessMap = i(t.iridescenceThicknessMap)), t.transmissionMap !== void 0 && (s.transmissionMap = i(t.transmissionMap)), t.thicknessMap !== void 0 && (s.thicknessMap = i(t.thicknessMap)), t.anisotropyMap !== void 0 && (s.anisotropyMap = i(t.anisotropyMap)), t.sheenColorMap !== void 0 && (s.sheenColorMap = i(t.sheenColorMap)), t.sheenRoughnessMap !== void 0 && (s.sheenRoughnessMap = i(t.sheenRoughnessMap)), s;
  }
  setTextures(t) {
    return this.textures = t, this;
  }
  createMaterialFromType(t) {
    return Lr.createMaterialFromType(t);
  }
  static createMaterialFromType(t) {
    const e = { ShadowMaterial: au, SpriteMaterial: Fo, RawShaderMaterial: uu, ShaderMaterial: Ho, PointsMaterial: Ro, MeshPhysicalMaterial: du, MeshStandardMaterial: Jo, MeshPhongMaterial: pu, MeshToonMaterial: fu, MeshNormalMaterial: mu, MeshLambertMaterial: yu, MeshDepthMaterial: gu, MeshDistanceMaterial: xu, MeshBasicMaterial: Si, MeshMatcapMaterial: bu, LineDashedMaterial: Mu, LineBasicMaterial: vt, Material: bt };
    return new e[t]();
  }
}
class so {
  static extractUrlBase(t) {
    const e = t.lastIndexOf("/");
    return e === -1 ? "./" : t.slice(0, e + 1);
  }
  static resolveURL(t, e) {
    return typeof t != "string" || t === "" ? "" : (/^https?:\/\//i.test(e) && /^\//.test(t) && (e = e.replace(/(^https?:\/\/[^\/]+).*/i, "$1")), /^(https?:)?\/\//i.test(t) || /^data:.*,.*$/i.test(t) || /^blob:.*$/i.test(t) ? t : e + t);
  }
}
class Uu extends H {
  constructor() {
    super(), this.isInstancedBufferGeometry = true, this.type = "InstancedBufferGeometry", this.instanceCount = 1 / 0;
  }
  copy(t) {
    return super.copy(t), this.instanceCount = t.instanceCount, this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.instanceCount = this.instanceCount, t.isInstancedBufferGeometry = true, t;
  }
}
class Wu extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    const n = this, r = new ve(n.manager);
    r.setPath(n.path), r.setRequestHeader(n.requestHeader), r.setWithCredentials(n.withCredentials), r.load(t, function(a) {
      try {
        e(n.parse(JSON.parse(a)));
      } catch (o) {
        s ? s(o) : Y(o), n.manager.itemError(t);
      }
    }, i, s);
  }
  parse(t) {
    const e = {}, i = {};
    function s(p, f) {
      if (e[f] !== void 0) return e[f];
      const g = p.interleavedBuffers[f], y = n(p, g.buffer), x = yi(g.type, y), b = new fr(x, g.stride);
      return b.uuid = g.uuid, e[f] = b, b;
    }
    function n(p, f) {
      if (i[f] !== void 0) return i[f];
      const g = p.arrayBuffers[f], y = new Uint32Array(g).buffer;
      return i[f] = y, y;
    }
    const r = t.isInstancedBufferGeometry ? new Uu() : new H(), a = t.data.index;
    if (a !== void 0) {
      const p = yi(a.type, a.array);
      r.setIndex(new tt(p, 1));
    }
    const o = t.data.attributes;
    for (const p in o) {
      const f = o[p];
      let m;
      if (f.isInterleavedBufferAttribute) {
        const g = s(t.data, f.data);
        m = new wi(g, f.itemSize, f.offset, f.normalized);
      } else {
        const g = yi(f.type, f.array), y = f.isInstancedBufferAttribute ? Xi : tt;
        m = new y(g, f.itemSize, f.normalized);
      }
      f.name !== void 0 && (m.name = f.name), f.usage !== void 0 && m.setUsage(f.usage), r.setAttribute(p, m);
    }
    const h = t.data.morphAttributes;
    if (h) for (const p in h) {
      const f = h[p], m = [];
      for (let g = 0, y = f.length; g < y; g++) {
        const x = f[g];
        let b;
        if (x.isInterleavedBufferAttribute) {
          const M = s(t.data, x.data);
          b = new wi(M, x.itemSize, x.offset, x.normalized);
        } else {
          const M = yi(x.type, x.array);
          b = new tt(M, x.itemSize, x.normalized);
        }
        x.name !== void 0 && (b.name = x.name), m.push(b);
      }
      r.morphAttributes[p] = m;
    }
    t.data.morphTargetsRelative && (r.morphTargetsRelative = true);
    const u = t.data.groups || t.data.drawcalls || t.data.offsets;
    if (u !== void 0) for (let p = 0, f = u.length; p !== f; ++p) {
      const m = u[p];
      r.addGroup(m.start, m.count, m.materialIndex);
    }
    const d = t.data.boundingSphere;
    return d !== void 0 && (r.boundingSphere = new mt().fromJSON(d)), t.name && (r.name = t.name), t.userData && (r.userData = t.userData), r;
  }
}
class Rf extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    const n = this, r = this.path === "" ? so.extractUrlBase(t) : this.path;
    this.resourcePath = this.resourcePath || r;
    const a = new ve(this.manager);
    a.setPath(this.path), a.setRequestHeader(this.requestHeader), a.setWithCredentials(this.withCredentials), a.load(t, function(o) {
      let h = null;
      try {
        h = JSON.parse(o);
      } catch (u) {
        s !== void 0 && s(u), u("ObjectLoader: Can't parse " + t + ".", u.message);
        return;
      }
      const c = h.metadata;
      if (c === void 0 || c.type === void 0 || c.type.toLowerCase() === "geometry") {
        s !== void 0 && s(new Error("THREE.ObjectLoader: Can't load " + t)), Y("ObjectLoader: Can't load " + t);
        return;
      }
      n.parse(h, e);
    }, i, s);
  }
  async loadAsync(t, e) {
    const i = this, s = this.path === "" ? so.extractUrlBase(t) : this.path;
    this.resourcePath = this.resourcePath || s;
    const n = new ve(this.manager);
    n.setPath(this.path), n.setRequestHeader(this.requestHeader), n.setWithCredentials(this.withCredentials);
    const r = await n.loadAsync(t, e);
    let a;
    try {
      a = JSON.parse(r);
    } catch (h) {
      throw new Error("ObjectLoader: Can't parse " + t + ". " + h.message);
    }
    const o = a.metadata;
    if (o === void 0 || o.type === void 0 || o.type.toLowerCase() === "geometry") throw new Error("THREE.ObjectLoader: Can't load " + t);
    return await i.parseAsync(a);
  }
  parse(t, e) {
    const i = this.parseAnimations(t.animations), s = this.parseShapes(t.shapes), n = this.parseGeometries(t.geometries, s), r = this.parseImages(t.images, function() {
      e !== void 0 && e(h);
    }), a = this.parseTextures(t.textures, r), o = this.parseMaterials(t.materials, a), h = this.parseObject(t.object, n, o, a, i), c = this.parseSkeletons(t.skeletons, h);
    if (this.bindSkeletons(h, c), this.bindLightTargets(h), e !== void 0) {
      let u = false;
      for (const d in r) if (r[d].data instanceof HTMLImageElement) {
        u = true;
        break;
      }
      u === false && e(h);
    }
    return h;
  }
  async parseAsync(t) {
    const e = this.parseAnimations(t.animations), i = this.parseShapes(t.shapes), s = this.parseGeometries(t.geometries, i), n = await this.parseImagesAsync(t.images), r = this.parseTextures(t.textures, n), a = this.parseMaterials(t.materials, r), o = this.parseObject(t.object, s, a, r, e), h = this.parseSkeletons(t.skeletons, o);
    return this.bindSkeletons(o, h), this.bindLightTargets(o), o;
  }
  parseShapes(t) {
    const e = {};
    if (t !== void 0) for (let i = 0, s = t.length; i < s; i++) {
      const n = new xi().fromJSON(t[i]);
      e[n.uuid] = n;
    }
    return e;
  }
  parseSkeletons(t, e) {
    const i = {}, s = {};
    if (e.traverse(function(n) {
      n.isBone && (s[n.uuid] = n);
    }), t !== void 0) for (let n = 0, r = t.length; n < r; n++) {
      const a = new mr().fromJSON(t[n], s);
      i[a.uuid] = a;
    }
    return i;
  }
  parseGeometries(t, e) {
    const i = {};
    if (t !== void 0) {
      const s = new Wu();
      for (let n = 0, r = t.length; n < r; n++) {
        let a;
        const o = t[n];
        switch (o.type) {
          case "BufferGeometry":
          case "InstancedBufferGeometry":
            a = s.parse(o);
            break;
          default:
            o.type in ja ? a = ja[o.type].fromJSON(o, e) : N(`ObjectLoader: Unsupported geometry type "${o.type}"`);
        }
        a.uuid = o.uuid, o.name !== void 0 && (a.name = o.name), o.userData !== void 0 && (a.userData = o.userData), i[o.uuid] = a;
      }
    }
    return i;
  }
  parseMaterials(t, e) {
    const i = {}, s = {};
    if (t !== void 0) {
      const n = new Lr();
      n.setTextures(e);
      for (let r = 0, a = t.length; r < a; r++) {
        const o = t[r];
        i[o.uuid] === void 0 && (i[o.uuid] = n.parse(o)), s[o.uuid] = i[o.uuid];
      }
    }
    return s;
  }
  parseAnimations(t) {
    const e = {};
    if (t !== void 0) for (let i = 0; i < t.length; i++) {
      const s = t[i], n = tn.parse(s);
      e[n.uuid] = n;
    }
    return e;
  }
  parseImages(t, e) {
    const i = this, s = {};
    let n;
    function r(o) {
      return i.manager.itemStart(o), n.load(o, function() {
        i.manager.itemEnd(o);
      }, void 0, function() {
        i.manager.itemError(o), i.manager.itemEnd(o);
      });
    }
    function a(o) {
      if (typeof o == "string") {
        const h = o, c = /^(\/\/)|([a-z]+:(\/\/)?)/i.test(h) ? h : i.resourcePath + h;
        return r(c);
      } else return o.data ? { data: yi(o.type, o.data), width: o.width, height: o.height } : null;
    }
    if (t !== void 0 && t.length > 0) {
      const o = new $o(e);
      n = new en(o), n.setCrossOrigin(this.crossOrigin);
      for (let h = 0, c = t.length; h < c; h++) {
        const u = t[h], d = u.url;
        if (Array.isArray(d)) {
          const p = [];
          for (let f = 0, m = d.length; f < m; f++) {
            const g = d[f], y = a(g);
            y !== null && (y instanceof HTMLImageElement ? p.push(y) : p.push(new pe(y.data, y.width, y.height)));
          }
          s[u.uuid] = new Le(p);
        } else {
          const p = a(u.url);
          s[u.uuid] = new Le(p);
        }
      }
    }
    return s;
  }
  async parseImagesAsync(t) {
    const e = this, i = {};
    let s;
    async function n(r) {
      if (typeof r == "string") {
        const a = r, o = /^(\/\/)|([a-z]+:(\/\/)?)/i.test(a) ? a : e.resourcePath + a;
        return await s.loadAsync(o);
      } else return r.data ? { data: yi(r.type, r.data), width: r.width, height: r.height } : null;
    }
    if (t !== void 0 && t.length > 0) {
      s = new en(this.manager), s.setCrossOrigin(this.crossOrigin);
      for (let r = 0, a = t.length; r < a; r++) {
        const o = t[r], h = o.url;
        if (Array.isArray(h)) {
          const c = [];
          for (let u = 0, d = h.length; u < d; u++) {
            const p = h[u], f = await n(p);
            f !== null && (f instanceof HTMLImageElement ? c.push(f) : c.push(new pe(f.data, f.width, f.height)));
          }
          i[o.uuid] = new Le(c);
        } else {
          const c = await n(o.url);
          i[o.uuid] = new Le(c);
        }
      }
    }
    return i;
  }
  parseTextures(t, e) {
    function i(n, r) {
      return typeof n == "number" ? n : (N("ObjectLoader.parseTexture: Constant should be in numeric form.", n), r[n]);
    }
    const s = {};
    if (t !== void 0) for (let n = 0, r = t.length; n < r; n++) {
      const a = t[n];
      a.image === void 0 && N('ObjectLoader: No "image" specified for', a.uuid), e[a.image] === void 0 && N("ObjectLoader: Undefined image", a.image);
      const o = e[a.image], h = o.data;
      let c;
      Array.isArray(h) ? (c = new Oo(), h.length === 6 && (c.needsUpdate = true)) : (h && h.data ? c = new pe() : c = new lt(), h && (c.needsUpdate = true)), c.source = o, c.uuid = a.uuid, a.name !== void 0 && (c.name = a.name), a.mapping !== void 0 && (c.mapping = i(a.mapping, Gu)), a.channel !== void 0 && (c.channel = a.channel), a.offset !== void 0 && c.offset.fromArray(a.offset), a.repeat !== void 0 && c.repeat.fromArray(a.repeat), a.center !== void 0 && c.center.fromArray(a.center), a.rotation !== void 0 && (c.rotation = a.rotation), a.wrap !== void 0 && (c.wrapS = i(a.wrap[0], no), c.wrapT = i(a.wrap[1], no)), a.format !== void 0 && (c.format = a.format), a.internalFormat !== void 0 && (c.internalFormat = a.internalFormat), a.type !== void 0 && (c.type = a.type), a.colorSpace !== void 0 && (c.colorSpace = a.colorSpace), a.minFilter !== void 0 && (c.minFilter = i(a.minFilter, ro)), a.magFilter !== void 0 && (c.magFilter = i(a.magFilter, ro)), a.anisotropy !== void 0 && (c.anisotropy = a.anisotropy), a.flipY !== void 0 && (c.flipY = a.flipY), a.generateMipmaps !== void 0 && (c.generateMipmaps = a.generateMipmaps), a.premultiplyAlpha !== void 0 && (c.premultiplyAlpha = a.premultiplyAlpha), a.unpackAlignment !== void 0 && (c.unpackAlignment = a.unpackAlignment), a.compareFunction !== void 0 && (c.compareFunction = a.compareFunction), a.userData !== void 0 && (c.userData = a.userData), s[a.uuid] = c;
    }
    return s;
  }
  parseObject(t, e, i, s, n) {
    let r;
    function a(d) {
      return e[d] === void 0 && N("ObjectLoader: Undefined geometry", d), e[d];
    }
    function o(d) {
      if (d !== void 0) {
        if (Array.isArray(d)) {
          const p = [];
          for (let f = 0, m = d.length; f < m; f++) {
            const g = d[f];
            i[g] === void 0 && N("ObjectLoader: Undefined material", g), p.push(i[g]);
          }
          return p;
        }
        return i[d] === void 0 && N("ObjectLoader: Undefined material", d), i[d];
      }
    }
    function h(d) {
      return s[d] === void 0 && N("ObjectLoader: Undefined texture", d), s[d];
    }
    let c, u;
    switch (t.type) {
      case "Scene":
        r = new Zl(), t.background !== void 0 && (Number.isInteger(t.background) ? r.background = new U(t.background) : r.background = h(t.background)), t.environment !== void 0 && (r.environment = h(t.environment)), t.fog !== void 0 && (t.fog.type === "Fog" ? r.fog = new pr(t.fog.color, t.fog.near, t.fog.far) : t.fog.type === "FogExp2" && (r.fog = new dr(t.fog.color, t.fog.density)), t.fog.name !== "" && (r.fog.name = t.fog.name)), t.backgroundBlurriness !== void 0 && (r.backgroundBlurriness = t.backgroundBlurriness), t.backgroundIntensity !== void 0 && (r.backgroundIntensity = t.backgroundIntensity), t.backgroundRotation !== void 0 && r.backgroundRotation.fromArray(t.backgroundRotation), t.environmentIntensity !== void 0 && (r.environmentIntensity = t.environmentIntensity), t.environmentRotation !== void 0 && r.environmentRotation.fromArray(t.environmentRotation);
        break;
      case "PerspectiveCamera":
        r = new Et(t.fov, t.aspect, t.near, t.far), t.focus !== void 0 && (r.focus = t.focus), t.zoom !== void 0 && (r.zoom = t.zoom), t.filmGauge !== void 0 && (r.filmGauge = t.filmGauge), t.filmOffset !== void 0 && (r.filmOffset = t.filmOffset), t.view !== void 0 && (r.view = Object.assign({}, t.view));
        break;
      case "OrthographicCamera":
        r = new jo(t.left, t.right, t.top, t.bottom, t.near, t.far), t.zoom !== void 0 && (r.zoom = t.zoom), t.view !== void 0 && (r.view = Object.assign({}, t.view));
        break;
      case "AmbientLight":
        r = new Lu(t.color, t.intensity);
        break;
      case "DirectionalLight":
        r = new Nu(t.color, t.intensity), r.target = t.target || "";
        break;
      case "PointLight":
        r = new Ou(t.color, t.intensity, t.distance, t.decay);
        break;
      case "RectAreaLight":
        r = new Du(t.color, t.intensity, t.width, t.height);
        break;
      case "SpotLight":
        r = new Pu(t.color, t.intensity, t.distance, t.angle, t.penumbra, t.decay), r.target = t.target || "";
        break;
      case "HemisphereLight":
        r = new Fu(t.color, t.groundColor, t.intensity);
        break;
      case "LightProbe":
        const d = new Qo().fromArray(t.sh);
        r = new Vu(d, t.intensity);
        break;
      case "SkinnedMesh":
        c = a(t.geometry), u = o(t.material), r = new ac(c, u), t.bindMode !== void 0 && (r.bindMode = t.bindMode), t.bindMatrix !== void 0 && r.bindMatrix.fromArray(t.bindMatrix), t.skeleton !== void 0 && (r.skeleton = t.skeleton);
        break;
      case "Mesh":
        c = a(t.geometry), u = o(t.material), r = new Kt(c, u);
        break;
      case "InstancedMesh":
        c = a(t.geometry), u = o(t.material);
        const p = t.count, f = t.instanceMatrix, m = t.instanceColor;
        r = new lc(c, u, p), r.instanceMatrix = new Xi(new Float32Array(f.array), 16), m !== void 0 && (r.instanceColor = new Xi(new Float32Array(m.array), m.itemSize));
        break;
      case "BatchedMesh":
        c = a(t.geometry), u = o(t.material), r = new Mc(t.maxInstanceCount, t.maxVertexCount, t.maxIndexCount, u), r.geometry = c, r.perObjectFrustumCulled = t.perObjectFrustumCulled, r.sortObjects = t.sortObjects, r._drawRanges = t.drawRanges, r._reservedRanges = t.reservedRanges, r._geometryInfo = t.geometryInfo.map((g) => {
          let y = null, x = null;
          return g.boundingBox !== void 0 && (y = new xt().fromJSON(g.boundingBox)), g.boundingSphere !== void 0 && (x = new mt().fromJSON(g.boundingSphere)), { ...g, boundingBox: y, boundingSphere: x };
        }), r._instanceInfo = t.instanceInfo, r._availableInstanceIds = t._availableInstanceIds, r._availableGeometryIds = t._availableGeometryIds, r._nextIndexStart = t.nextIndexStart, r._nextVertexStart = t.nextVertexStart, r._geometryCount = t.geometryCount, r._maxInstanceCount = t.maxInstanceCount, r._maxVertexCount = t.maxVertexCount, r._maxIndexCount = t.maxIndexCount, r._geometryInitialized = t.geometryInitialized, r._matricesTexture = h(t.matricesTexture.uuid), r._indirectTexture = h(t.indirectTexture.uuid), t.colorsTexture !== void 0 && (r._colorsTexture = h(t.colorsTexture.uuid)), t.boundingSphere !== void 0 && (r.boundingSphere = new mt().fromJSON(t.boundingSphere)), t.boundingBox !== void 0 && (r.boundingBox = new xt().fromJSON(t.boundingBox));
        break;
      case "LOD":
        r = new sc();
        break;
      case "Line":
        r = new Ue(a(t.geometry), o(t.material));
        break;
      case "LineLoop":
        r = new wc(a(t.geometry), o(t.material));
        break;
      case "LineSegments":
        r = new fe(a(t.geometry), o(t.material));
        break;
      case "PointCloud":
      case "Points":
        r = new _c(a(t.geometry), o(t.material));
        break;
      case "Sprite":
        r = new ic(o(t.material));
        break;
      case "Group":
        r = new Di();
        break;
      case "Bone":
        r = new Po();
        break;
      default:
        r = new $();
    }
    if (r.uuid = t.uuid, t.name !== void 0 && (r.name = t.name), t.matrix !== void 0 ? (r.matrix.fromArray(t.matrix), t.matrixAutoUpdate !== void 0 && (r.matrixAutoUpdate = t.matrixAutoUpdate), r.matrixAutoUpdate && r.matrix.decompose(r.position, r.quaternion, r.scale)) : (t.position !== void 0 && r.position.fromArray(t.position), t.rotation !== void 0 && r.rotation.fromArray(t.rotation), t.quaternion !== void 0 && r.quaternion.fromArray(t.quaternion), t.scale !== void 0 && r.scale.fromArray(t.scale)), t.up !== void 0 && r.up.fromArray(t.up), t.pivot !== void 0 && (r.pivot = new w().fromArray(t.pivot)), t.morphTargetDictionary !== void 0 && (r.morphTargetDictionary = Object.assign({}, t.morphTargetDictionary)), t.morphTargetInfluences !== void 0 && (r.morphTargetInfluences = t.morphTargetInfluences.slice()), t.castShadow !== void 0 && (r.castShadow = t.castShadow), t.receiveShadow !== void 0 && (r.receiveShadow = t.receiveShadow), t.shadow && (t.shadow.intensity !== void 0 && (r.shadow.intensity = t.shadow.intensity), t.shadow.bias !== void 0 && (r.shadow.bias = t.shadow.bias), t.shadow.normalBias !== void 0 && (r.shadow.normalBias = t.shadow.normalBias), t.shadow.radius !== void 0 && (r.shadow.radius = t.shadow.radius), t.shadow.mapSize !== void 0 && r.shadow.mapSize.fromArray(t.shadow.mapSize), t.shadow.camera !== void 0 && (r.shadow.camera = this.parseObject(t.shadow.camera))), t.visible !== void 0 && (r.visible = t.visible), t.frustumCulled !== void 0 && (r.frustumCulled = t.frustumCulled), t.renderOrder !== void 0 && (r.renderOrder = t.renderOrder), t.static !== void 0 && (r.static = t.static), t.userData !== void 0 && (r.userData = t.userData), t.layers !== void 0 && (r.layers.mask = t.layers), t.children !== void 0) {
      const d = t.children;
      for (let p = 0; p < d.length; p++) r.add(this.parseObject(d[p], e, i, s, n));
    }
    if (t.animations !== void 0) {
      const d = t.animations;
      for (let p = 0; p < d.length; p++) {
        const f = d[p];
        r.animations.push(n[f]);
      }
    }
    if (t.type === "LOD") {
      t.autoUpdate !== void 0 && (r.autoUpdate = t.autoUpdate);
      const d = t.levels;
      for (let p = 0; p < d.length; p++) {
        const f = d[p], m = r.getObjectByProperty("uuid", f.object);
        m !== void 0 && r.addLevel(m, f.distance, f.hysteresis);
      }
    }
    return r;
  }
  bindSkeletons(t, e) {
    Object.keys(e).length !== 0 && t.traverse(function(i) {
      if (i.isSkinnedMesh === true && i.skeleton !== void 0) {
        const s = e[i.skeleton];
        s === void 0 ? N("ObjectLoader: No skeleton found with UUID:", i.skeleton) : i.bind(s, i.bindMatrix);
      }
    });
  }
  bindLightTargets(t) {
    t.traverse(function(e) {
      if (e.isDirectionalLight || e.isSpotLight) {
        const i = e.target, s = t.getObjectByProperty("uuid", i);
        s !== void 0 ? e.target = s : e.target = new $();
      }
    });
  }
}
const Gu = { UVMapping: or, CubeReflectionMapping: sn, CubeRefractionMapping: ch, EquirectangularReflectionMapping: uh, EquirectangularRefractionMapping: dh, CubeUVReflectionMapping: ph }, no = { RepeatWrapping: $n, ClampToEdgeWrapping: Zt, MirroredRepeatWrapping: jn }, ro = { NearestFilter: Bt, NearestMipmapNearestFilter: fh, NearestMipmapLinearFilter: mh, LinearFilter: Gt, LinearMipmapNearestFilter: yh, LinearMipmapLinearFilter: hr }, qn = /* @__PURE__ */ new WeakMap();
class Of extends Ft {
  constructor(t) {
    super(t), this.isImageBitmapLoader = true, typeof createImageBitmap > "u" && N("ImageBitmapLoader: createImageBitmap() not supported."), typeof fetch > "u" && N("ImageBitmapLoader: fetch() not supported."), this.options = { premultiplyAlpha: "none" }, this._abortController = new AbortController();
  }
  setOptions(t) {
    return this.options = t, this;
  }
  load(t, e, i, s) {
    t === void 0 && (t = ""), this.path !== void 0 && (t = this.path + t), t = this.manager.resolveURL(t);
    const n = this, r = ue.get(`image-bitmap:${t}`);
    if (r !== void 0) {
      if (n.manager.itemStart(t), r.then) {
        r.then((h) => {
          if (qn.has(r) === true) s && s(qn.get(r)), n.manager.itemError(t), n.manager.itemEnd(t);
          else return e && e(h), n.manager.itemEnd(t), h;
        });
        return;
      }
      return setTimeout(function() {
        e && e(r), n.manager.itemEnd(t);
      }, 0), r;
    }
    const a = {};
    a.credentials = this.crossOrigin === "anonymous" ? "same-origin" : "include", a.headers = this.requestHeader, a.signal = typeof AbortSignal.any == "function" ? AbortSignal.any([this._abortController.signal, this.manager.abortController.signal]) : this._abortController.signal;
    const o = fetch(t, a).then(function(h) {
      return h.blob();
    }).then(function(h) {
      return createImageBitmap(h, Object.assign(n.options, { colorSpaceConversion: "none" }));
    }).then(function(h) {
      return ue.add(`image-bitmap:${t}`, h), e && e(h), n.manager.itemEnd(t), h;
    }).catch(function(h) {
      s && s(h), qn.set(o, h), ue.remove(`image-bitmap:${t}`), n.manager.itemError(t), n.manager.itemEnd(t);
    });
    ue.add(`image-bitmap:${t}`, o), n.manager.itemStart(t);
  }
  abort() {
    return this._abortController.abort(), this._abortController = new AbortController(), this;
  }
}
let Ns;
class Ko {
  static getContext() {
    return Ns === void 0 && (Ns = new (window.AudioContext || window.webkitAudioContext)()), Ns;
  }
  static setContext(t) {
    Ns = t;
  }
}
class Ef extends Ft {
  constructor(t) {
    super(t);
  }
  load(t, e, i, s) {
    const n = this, r = new ve(this.manager);
    r.setResponseType("arraybuffer"), r.setPath(this.path), r.setRequestHeader(this.requestHeader), r.setWithCredentials(this.withCredentials), r.load(t, function(o) {
      try {
        const h = o.slice(0);
        Ko.getContext().decodeAudioData(h, function(u) {
          e(u);
        }).catch(a);
      } catch (h) {
        a(h);
      }
    }, i, s);
    function a(o) {
      s ? s(o) : Y(o), n.manager.itemError(t);
    }
  }
}
const ao = new G(), oo = new G(), ke = new G();
class Nf {
  constructor() {
    this.type = "StereoCamera", this.aspect = 1, this.eyeSep = 0.064, this.cameraL = new Et(), this.cameraL.layers.enable(1), this.cameraL.matrixAutoUpdate = false, this.cameraR = new Et(), this.cameraR.layers.enable(2), this.cameraR.matrixAutoUpdate = false, this._cache = { focus: null, fov: null, aspect: null, near: null, far: null, zoom: null, eyeSep: null };
  }
  update(t) {
    const e = this._cache;
    if (e.focus !== t.focus || e.fov !== t.fov || e.aspect !== t.aspect * this.aspect || e.near !== t.near || e.far !== t.far || e.zoom !== t.zoom || e.eyeSep !== this.eyeSep) {
      e.focus = t.focus, e.fov = t.fov, e.aspect = t.aspect * this.aspect, e.near = t.near, e.far = t.far, e.zoom = t.zoom, e.eyeSep = this.eyeSep, ke.copy(t.projectionMatrix);
      const s = e.eyeSep / 2, n = s * e.near / e.focus, r = e.near * Math.tan(Ve * e.fov * 0.5) / e.zoom;
      let a, o;
      oo.elements[12] = -s, ao.elements[12] = s, a = -r * e.aspect + n, o = r * e.aspect + n, ke.elements[0] = 2 * e.near / (o - a), ke.elements[8] = (o + a) / (o - a), this.cameraL.projectionMatrix.copy(ke), a = -r * e.aspect - n, o = r * e.aspect - n, ke.elements[0] = 2 * e.near / (o - a), ke.elements[8] = (o + a) / (o - a), this.cameraR.projectionMatrix.copy(ke);
    }
    this.cameraL.matrixWorld.copy(t.matrixWorld).multiply(oo), this.cameraR.matrixWorld.copy(t.matrixWorld).multiply(ao);
  }
}
const ci = -90, ui = 1;
class Lf extends $ {
  constructor(t, e, i) {
    super(), this.type = "CubeCamera", this.renderTarget = i, this.coordinateSystem = null, this.activeMipmapLevel = 0;
    const s = new Et(ci, ui, t, e);
    s.layers = this.layers, this.add(s);
    const n = new Et(ci, ui, t, e);
    n.layers = this.layers, this.add(n);
    const r = new Et(ci, ui, t, e);
    r.layers = this.layers, this.add(r);
    const a = new Et(ci, ui, t, e);
    a.layers = this.layers, this.add(a);
    const o = new Et(ci, ui, t, e);
    o.layers = this.layers, this.add(o);
    const h = new Et(ci, ui, t, e);
    h.layers = this.layers, this.add(h);
  }
  updateCoordinateSystem() {
    const t = this.coordinateSystem, e = this.children.concat(), [i, s, n, r, a, o] = e;
    for (const h of e) this.remove(h);
    if (t === Yt) i.up.set(0, 1, 0), i.lookAt(1, 0, 0), s.up.set(0, 1, 0), s.lookAt(-1, 0, 0), n.up.set(0, 0, -1), n.lookAt(0, 1, 0), r.up.set(0, 0, 1), r.lookAt(0, -1, 0), a.up.set(0, 1, 0), a.lookAt(0, 0, 1), o.up.set(0, 1, 0), o.lookAt(0, 0, -1);
    else if (t === Mi) i.up.set(0, -1, 0), i.lookAt(-1, 0, 0), s.up.set(0, -1, 0), s.lookAt(1, 0, 0), n.up.set(0, 0, 1), n.lookAt(0, 1, 0), r.up.set(0, 0, -1), r.lookAt(0, -1, 0), a.up.set(0, -1, 0), a.lookAt(0, 0, 1), o.up.set(0, -1, 0), o.lookAt(0, 0, -1);
    else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: " + t);
    for (const h of e) this.add(h), h.updateMatrixWorld();
  }
  update(t, e) {
    this.parent === null && this.updateMatrixWorld();
    const { renderTarget: i, activeMipmapLevel: s } = this;
    this.coordinateSystem !== t.coordinateSystem && (this.coordinateSystem = t.coordinateSystem, this.updateCoordinateSystem());
    const [n, r, a, o, h, c] = this.children, u = t.getRenderTarget(), d = t.getActiveCubeFace(), p = t.getActiveMipmapLevel(), f = t.xr.enabled;
    t.xr.enabled = false;
    const m = i.texture.generateMipmaps;
    i.texture.generateMipmaps = false;
    let g = false;
    t.isWebGLRenderer === true ? g = t.state.buffers.depth.getReversed() : g = t.reversedDepthBuffer, t.setRenderTarget(i, 0, s), g && t.autoClear === false && t.clearDepth(), t.render(e, n), t.setRenderTarget(i, 1, s), g && t.autoClear === false && t.clearDepth(), t.render(e, r), t.setRenderTarget(i, 2, s), g && t.autoClear === false && t.clearDepth(), t.render(e, a), t.setRenderTarget(i, 3, s), g && t.autoClear === false && t.clearDepth(), t.render(e, o), t.setRenderTarget(i, 4, s), g && t.autoClear === false && t.clearDepth(), t.render(e, h), i.texture.generateMipmaps = m, t.setRenderTarget(i, 5, s), g && t.autoClear === false && t.clearDepth(), t.render(e, c), t.setRenderTarget(u, d, p), t.xr.enabled = f, i.texture.needsPMREMUpdate = true;
  }
}
class Df extends Et {
  constructor(t = []) {
    super(), this.isArrayCamera = true, this.isMultiViewCamera = false, this.cameras = t;
  }
}
class qu {
  constructor() {
    this._previousTime = 0, this._currentTime = 0, this._startTime = performance.now(), this._delta = 0, this._elapsed = 0, this._timescale = 1, this._document = null, this._pageVisibilityHandler = null;
  }
  connect(t) {
    this._document = t, t.hidden !== void 0 && (this._pageVisibilityHandler = Hu.bind(this), t.addEventListener("visibilitychange", this._pageVisibilityHandler, false));
  }
  disconnect() {
    this._pageVisibilityHandler !== null && (this._document.removeEventListener("visibilitychange", this._pageVisibilityHandler), this._pageVisibilityHandler = null), this._document = null;
  }
  getDelta() {
    return this._delta / 1e3;
  }
  getElapsed() {
    return this._elapsed / 1e3;
  }
  getTimescale() {
    return this._timescale;
  }
  setTimescale(t) {
    return this._timescale = t, this;
  }
  reset() {
    return this._currentTime = performance.now() - this._startTime, this;
  }
  dispose() {
    this.disconnect();
  }
  update(t) {
    return this._pageVisibilityHandler !== null && this._document.hidden === true ? this._delta = 0 : (this._previousTime = this._currentTime, this._currentTime = (t !== void 0 ? t : performance.now()) - this._startTime, this._delta = (this._currentTime - this._previousTime) * this._timescale, this._elapsed += this._delta), this;
  }
}
function Hu() {
  this._document.hidden === false && this.reset();
}
const Pe = new w(), Hn = new _t(), Ju = new w(), Re = new w(), Oe = new w();
class Vf extends $ {
  constructor() {
    super(), this.type = "AudioListener", this.context = Ko.getContext(), this.gain = this.context.createGain(), this.gain.connect(this.context.destination), this.filter = null, this.timeDelta = 0, this._timer = new qu();
  }
  getInput() {
    return this.gain;
  }
  removeFilter() {
    return this.filter !== null && (this.gain.disconnect(this.filter), this.filter.disconnect(this.context.destination), this.gain.connect(this.context.destination), this.filter = null), this;
  }
  getFilter() {
    return this.filter;
  }
  setFilter(t) {
    return this.filter !== null ? (this.gain.disconnect(this.filter), this.filter.disconnect(this.context.destination)) : this.gain.disconnect(this.context.destination), this.filter = t, this.gain.connect(this.filter), this.filter.connect(this.context.destination), this;
  }
  getMasterVolume() {
    return this.gain.gain.value;
  }
  setMasterVolume(t) {
    return this.gain.gain.setTargetAtTime(t, this.context.currentTime, 0.01), this;
  }
  updateMatrixWorld(t) {
    super.updateMatrixWorld(t), this._timer.update();
    const e = this.context.listener;
    if (this.timeDelta = this._timer.getDelta(), this.matrixWorld.decompose(Pe, Hn, Ju), Re.set(0, 0, -1).applyQuaternion(Hn), Oe.set(0, 1, 0).applyQuaternion(Hn), e.positionX) {
      const i = this.context.currentTime + this.timeDelta;
      e.positionX.linearRampToValueAtTime(Pe.x, i), e.positionY.linearRampToValueAtTime(Pe.y, i), e.positionZ.linearRampToValueAtTime(Pe.z, i), e.forwardX.linearRampToValueAtTime(Re.x, i), e.forwardY.linearRampToValueAtTime(Re.y, i), e.forwardZ.linearRampToValueAtTime(Re.z, i), e.upX.linearRampToValueAtTime(Oe.x, i), e.upY.linearRampToValueAtTime(Oe.y, i), e.upZ.linearRampToValueAtTime(Oe.z, i);
    } else e.setPosition(Pe.x, Pe.y, Pe.z), e.setOrientation(Re.x, Re.y, Re.z, Oe.x, Oe.y, Oe.z);
  }
}
class Xu extends $ {
  constructor(t) {
    super(), this.type = "Audio", this.listener = t, this.context = t.context, this.gain = this.context.createGain(), this.gain.connect(t.getInput()), this.autoplay = false, this.buffer = null, this.detune = 0, this.loop = false, this.loopStart = 0, this.loopEnd = 0, this.offset = 0, this.duration = void 0, this.playbackRate = 1, this.isPlaying = false, this.hasPlaybackControl = true, this.source = null, this.sourceType = "empty", this._startedAt = 0, this._progress = 0, this._connected = false, this.filters = [];
  }
  getOutput() {
    return this.gain;
  }
  setNodeSource(t) {
    return this.hasPlaybackControl = false, this.sourceType = "audioNode", this.source = t, this.connect(), this;
  }
  setMediaElementSource(t) {
    return this.hasPlaybackControl = false, this.sourceType = "mediaNode", this.source = this.context.createMediaElementSource(t), this.connect(), this;
  }
  setMediaStreamSource(t) {
    return this.hasPlaybackControl = false, this.sourceType = "mediaStreamNode", this.source = this.context.createMediaStreamSource(t), this.connect(), this;
  }
  setBuffer(t) {
    return this.buffer = t, this.sourceType = "buffer", this.autoplay && this.play(), this;
  }
  play(t = 0) {
    if (this.isPlaying === true) {
      N("Audio: Audio is already playing.");
      return;
    }
    if (this.hasPlaybackControl === false) {
      N("Audio: this Audio has no playback control.");
      return;
    }
    this._startedAt = this.context.currentTime + t;
    const e = this.context.createBufferSource();
    return e.buffer = this.buffer, e.loop = this.loop, e.loopStart = this.loopStart, e.loopEnd = this.loopEnd, e.onended = this.onEnded.bind(this), e.start(this._startedAt, this._progress + this.offset, this.duration), this.isPlaying = true, this.source = e, this.setDetune(this.detune), this.setPlaybackRate(this.playbackRate), this.connect();
  }
  pause() {
    if (this.hasPlaybackControl === false) {
      N("Audio: this Audio has no playback control.");
      return;
    }
    return this.isPlaying === true && (this._progress += Math.max(this.context.currentTime - this._startedAt, 0) * this.playbackRate, this.loop === true && (this._progress = this._progress % (this.duration || this.buffer.duration)), this.source.stop(), this.source.onended = null, this.isPlaying = false), this;
  }
  stop(t = 0) {
    if (this.hasPlaybackControl === false) {
      N("Audio: this Audio has no playback control.");
      return;
    }
    return this._progress = 0, this.source !== null && (this.source.stop(this.context.currentTime + t), this.source.onended = null), this.isPlaying = false, this;
  }
  connect() {
    if (this.filters.length > 0) {
      this.source.connect(this.filters[0]);
      for (let t = 1, e = this.filters.length; t < e; t++) this.filters[t - 1].connect(this.filters[t]);
      this.filters[this.filters.length - 1].connect(this.getOutput());
    } else this.source.connect(this.getOutput());
    return this._connected = true, this;
  }
  disconnect() {
    if (this._connected !== false) {
      if (this.filters.length > 0) {
        this.source.disconnect(this.filters[0]);
        for (let t = 1, e = this.filters.length; t < e; t++) this.filters[t - 1].disconnect(this.filters[t]);
        this.filters[this.filters.length - 1].disconnect(this.getOutput());
      } else this.source.disconnect(this.getOutput());
      return this._connected = false, this;
    }
  }
  getFilters() {
    return this.filters;
  }
  setFilters(t) {
    return t || (t = []), this._connected === true ? (this.disconnect(), this.filters = t.slice(), this.connect()) : this.filters = t.slice(), this;
  }
  setDetune(t) {
    return this.detune = t, this.isPlaying === true && this.source.detune !== void 0 && this.source.detune.setTargetAtTime(this.detune, this.context.currentTime, 0.01), this;
  }
  getDetune() {
    return this.detune;
  }
  getFilter() {
    return this.getFilters()[0];
  }
  setFilter(t) {
    return this.setFilters(t ? [t] : []);
  }
  setPlaybackRate(t) {
    if (this.hasPlaybackControl === false) {
      N("Audio: this Audio has no playback control.");
      return;
    }
    return this.playbackRate = t, this.isPlaying === true && this.source.playbackRate.setTargetAtTime(this.playbackRate, this.context.currentTime, 0.01), this;
  }
  getPlaybackRate() {
    return this.playbackRate;
  }
  onEnded() {
    this.isPlaying = false, this._progress = 0;
  }
  getLoop() {
    return this.hasPlaybackControl === false ? (N("Audio: this Audio has no playback control."), false) : this.loop;
  }
  setLoop(t) {
    if (this.hasPlaybackControl === false) {
      N("Audio: this Audio has no playback control.");
      return;
    }
    return this.loop = t, this.isPlaying === true && (this.source.loop = this.loop), this;
  }
  setLoopStart(t) {
    return this.loopStart = t, this;
  }
  setLoopEnd(t) {
    return this.loopEnd = t, this;
  }
  getVolume() {
    return this.gain.gain.value;
  }
  setVolume(t) {
    return this.gain.gain.setTargetAtTime(t, this.context.currentTime, 0.01), this;
  }
  copy(t, e) {
    return super.copy(t, e), t.sourceType !== "buffer" ? (N("Audio: Audio source type cannot be copied."), this) : (this.autoplay = t.autoplay, this.buffer = t.buffer, this.detune = t.detune, this.loop = t.loop, this.loopStart = t.loopStart, this.loopEnd = t.loopEnd, this.offset = t.offset, this.duration = t.duration, this.playbackRate = t.playbackRate, this.hasPlaybackControl = t.hasPlaybackControl, this.sourceType = t.sourceType, this.filters = t.filters.slice(), this);
  }
  clone(t) {
    return new this.constructor(this.listener).copy(this, t);
  }
}
const Ee = new w(), ho = new _t(), Zu = new w(), Ne = new w();
class Uf extends Xu {
  constructor(t) {
    super(t), this.panner = this.context.createPanner(), this.panner.panningModel = "HRTF", this.panner.connect(this.gain);
  }
  connect() {
    return super.connect(), this.panner.connect(this.gain), this;
  }
  disconnect() {
    return super.disconnect(), this.panner.disconnect(this.gain), this;
  }
  getOutput() {
    return this.panner;
  }
  getRefDistance() {
    return this.panner.refDistance;
  }
  setRefDistance(t) {
    return this.panner.refDistance = t, this;
  }
  getRolloffFactor() {
    return this.panner.rolloffFactor;
  }
  setRolloffFactor(t) {
    return this.panner.rolloffFactor = t, this;
  }
  getDistanceModel() {
    return this.panner.distanceModel;
  }
  setDistanceModel(t) {
    return this.panner.distanceModel = t, this;
  }
  getMaxDistance() {
    return this.panner.maxDistance;
  }
  setMaxDistance(t) {
    return this.panner.maxDistance = t, this;
  }
  setDirectionalCone(t, e, i) {
    return this.panner.coneInnerAngle = t, this.panner.coneOuterAngle = e, this.panner.coneOuterGain = i, this;
  }
  updateMatrixWorld(t) {
    if (super.updateMatrixWorld(t), this.hasPlaybackControl === true && this.isPlaying === false) return;
    this.matrixWorld.decompose(Ee, ho, Zu), Ne.set(0, 0, 1).applyQuaternion(ho);
    const e = this.panner;
    if (e.positionX) {
      const i = this.context.currentTime + this.listener.timeDelta;
      e.positionX.linearRampToValueAtTime(Ee.x, i), e.positionY.linearRampToValueAtTime(Ee.y, i), e.positionZ.linearRampToValueAtTime(Ee.z, i), e.orientationX.linearRampToValueAtTime(Ne.x, i), e.orientationY.linearRampToValueAtTime(Ne.y, i), e.orientationZ.linearRampToValueAtTime(Ne.z, i);
    } else e.setPosition(Ee.x, Ee.y, Ee.z), e.setOrientation(Ne.x, Ne.y, Ne.z);
  }
}
class Wf {
  constructor(t, e = 2048) {
    this.analyser = t.context.createAnalyser(), this.analyser.fftSize = e, this.data = new Uint8Array(this.analyser.frequencyBinCount), t.getOutput().connect(this.analyser);
  }
  getFrequencyData() {
    return this.analyser.getByteFrequencyData(this.data), this.data;
  }
  getAverageFrequency() {
    let t = 0;
    const e = this.getFrequencyData();
    for (let i = 0; i < e.length; i++) t += e[i];
    return t / e.length;
  }
}
class Yu {
  constructor(t, e, i) {
    this.binding = t, this.valueSize = i;
    let s, n, r;
    switch (e) {
      case "quaternion":
        s = this._slerp, n = this._slerpAdditive, r = this._setAdditiveIdentityQuaternion, this.buffer = new Float64Array(i * 6), this._workIndex = 5;
        break;
      case "string":
      case "bool":
        s = this._select, n = this._select, r = this._setAdditiveIdentityOther, this.buffer = new Array(i * 5);
        break;
      default:
        s = this._lerp, n = this._lerpAdditive, r = this._setAdditiveIdentityNumeric, this.buffer = new Float64Array(i * 5);
    }
    this._mixBufferRegion = s, this._mixBufferRegionAdditive = n, this._setIdentity = r, this._origIndex = 3, this._addIndex = 4, this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0, this.useCount = 0, this.referenceCount = 0;
  }
  accumulate(t, e) {
    const i = this.buffer, s = this.valueSize, n = t * s + s;
    let r = this.cumulativeWeight;
    if (r === 0) {
      for (let a = 0; a !== s; ++a) i[n + a] = i[a];
      r = e;
    } else {
      r += e;
      const a = e / r;
      this._mixBufferRegion(i, n, 0, a, s);
    }
    this.cumulativeWeight = r;
  }
  accumulateAdditive(t) {
    const e = this.buffer, i = this.valueSize, s = i * this._addIndex;
    this.cumulativeWeightAdditive === 0 && this._setIdentity(), this._mixBufferRegionAdditive(e, s, 0, t, i), this.cumulativeWeightAdditive += t;
  }
  apply(t) {
    const e = this.valueSize, i = this.buffer, s = t * e + e, n = this.cumulativeWeight, r = this.cumulativeWeightAdditive, a = this.binding;
    if (this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0, n < 1) {
      const o = e * this._origIndex;
      this._mixBufferRegion(i, s, o, 1 - n, e);
    }
    r > 0 && this._mixBufferRegionAdditive(i, s, this._addIndex * e, 1, e);
    for (let o = e, h = e + e; o !== h; ++o) if (i[o] !== i[o + e]) {
      a.setValue(i, s);
      break;
    }
  }
  saveOriginalState() {
    const t = this.binding, e = this.buffer, i = this.valueSize, s = i * this._origIndex;
    t.getValue(e, s);
    for (let n = i, r = s; n !== r; ++n) e[n] = e[s + n % i];
    this._setIdentity(), this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0;
  }
  restoreOriginalState() {
    const t = this.valueSize * 3;
    this.binding.setValue(this.buffer, t);
  }
  _setAdditiveIdentityNumeric() {
    const t = this._addIndex * this.valueSize, e = t + this.valueSize;
    for (let i = t; i < e; i++) this.buffer[i] = 0;
  }
  _setAdditiveIdentityQuaternion() {
    this._setAdditiveIdentityNumeric(), this.buffer[this._addIndex * this.valueSize + 3] = 1;
  }
  _setAdditiveIdentityOther() {
    const t = this._origIndex * this.valueSize, e = this._addIndex * this.valueSize;
    for (let i = 0; i < this.valueSize; i++) this.buffer[e + i] = this.buffer[t + i];
  }
  _select(t, e, i, s, n) {
    if (s >= 0.5) for (let r = 0; r !== n; ++r) t[e + r] = t[i + r];
  }
  _slerp(t, e, i, s) {
    _t.slerpFlat(t, e, t, e, t, i, s);
  }
  _slerpAdditive(t, e, i, s, n) {
    const r = this._workIndex * n;
    _t.multiplyQuaternionsFlat(t, r, t, e, t, i), _t.slerpFlat(t, e, t, e, t, r, s);
  }
  _lerp(t, e, i, s, n) {
    const r = 1 - s;
    for (let a = 0; a !== n; ++a) {
      const o = e + a;
      t[o] = t[o] * r + t[i + a] * s;
    }
  }
  _lerpAdditive(t, e, i, s, n) {
    for (let r = 0; r !== n; ++r) {
      const a = e + r;
      t[a] = t[a] + t[i + r] * s;
    }
  }
}
const Dr = "\\[\\]\\.:\\/", $u = new RegExp("[" + Dr + "]", "g"), Vr = "[^" + Dr + "]", ju = "[^" + Dr.replace("\\.", "") + "]", Qu = /((?:WC+[\/:])*)/.source.replace("WC", Vr), Ku = /(WCOD+)?/.source.replace("WCOD", ju), td = /(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC", Vr), ed = /\.(WC+)(?:\[(.+)\])?/.source.replace("WC", Vr), id = new RegExp("^" + Qu + Ku + td + ed + "$"), sd = ["material", "materials", "bones", "map"];
class nd {
  constructor(t, e, i) {
    const s = i || Z.parseTrackName(e);
    this._targetGroup = t, this._bindings = t.subscribe_(e, s);
  }
  getValue(t, e) {
    this.bind();
    const i = this._targetGroup.nCachedObjects_, s = this._bindings[i];
    s !== void 0 && s.getValue(t, e);
  }
  setValue(t, e) {
    const i = this._bindings;
    for (let s = this._targetGroup.nCachedObjects_, n = i.length; s !== n; ++s) i[s].setValue(t, e);
  }
  bind() {
    const t = this._bindings;
    for (let e = this._targetGroup.nCachedObjects_, i = t.length; e !== i; ++e) t[e].bind();
  }
  unbind() {
    const t = this._bindings;
    for (let e = this._targetGroup.nCachedObjects_, i = t.length; e !== i; ++e) t[e].unbind();
  }
}
class Z {
  constructor(t, e, i) {
    this.path = e, this.parsedPath = i || Z.parseTrackName(e), this.node = Z.findNode(t, this.parsedPath.nodeName), this.rootNode = t, this.getValue = this._getValue_unbound, this.setValue = this._setValue_unbound;
  }
  static create(t, e, i) {
    return t && t.isAnimationObjectGroup ? new Z.Composite(t, e, i) : new Z(t, e, i);
  }
  static sanitizeNodeName(t) {
    return t.replace(/\s/g, "_").replace($u, "");
  }
  static parseTrackName(t) {
    const e = id.exec(t);
    if (e === null) throw new Error("PropertyBinding: Cannot parse trackName: " + t);
    const i = { nodeName: e[2], objectName: e[3], objectIndex: e[4], propertyName: e[5], propertyIndex: e[6] }, s = i.nodeName && i.nodeName.lastIndexOf(".");
    if (s !== void 0 && s !== -1) {
      const n = i.nodeName.substring(s + 1);
      sd.indexOf(n) !== -1 && (i.nodeName = i.nodeName.substring(0, s), i.objectName = n);
    }
    if (i.propertyName === null || i.propertyName.length === 0) throw new Error("PropertyBinding: can not parse propertyName from trackName: " + t);
    return i;
  }
  static findNode(t, e) {
    if (e === void 0 || e === "" || e === "." || e === -1 || e === t.name || e === t.uuid) return t;
    if (t.skeleton) {
      const i = t.skeleton.getBoneByName(e);
      if (i !== void 0) return i;
    }
    if (t.children) {
      const i = function(n) {
        for (let r = 0; r < n.length; r++) {
          const a = n[r];
          if (a.name === e || a.uuid === e) return a;
          const o = i(a.children);
          if (o) return o;
        }
        return null;
      }, s = i(t.children);
      if (s) return s;
    }
    return null;
  }
  _getValue_unavailable() {
  }
  _setValue_unavailable() {
  }
  _getValue_direct(t, e) {
    t[e] = this.targetObject[this.propertyName];
  }
  _getValue_array(t, e) {
    const i = this.resolvedProperty;
    for (let s = 0, n = i.length; s !== n; ++s) t[e++] = i[s];
  }
  _getValue_arrayElement(t, e) {
    t[e] = this.resolvedProperty[this.propertyIndex];
  }
  _getValue_toArray(t, e) {
    this.resolvedProperty.toArray(t, e);
  }
  _setValue_direct(t, e) {
    this.targetObject[this.propertyName] = t[e];
  }
  _setValue_direct_setNeedsUpdate(t, e) {
    this.targetObject[this.propertyName] = t[e], this.targetObject.needsUpdate = true;
  }
  _setValue_direct_setMatrixWorldNeedsUpdate(t, e) {
    this.targetObject[this.propertyName] = t[e], this.targetObject.matrixWorldNeedsUpdate = true;
  }
  _setValue_array(t, e) {
    const i = this.resolvedProperty;
    for (let s = 0, n = i.length; s !== n; ++s) i[s] = t[e++];
  }
  _setValue_array_setNeedsUpdate(t, e) {
    const i = this.resolvedProperty;
    for (let s = 0, n = i.length; s !== n; ++s) i[s] = t[e++];
    this.targetObject.needsUpdate = true;
  }
  _setValue_array_setMatrixWorldNeedsUpdate(t, e) {
    const i = this.resolvedProperty;
    for (let s = 0, n = i.length; s !== n; ++s) i[s] = t[e++];
    this.targetObject.matrixWorldNeedsUpdate = true;
  }
  _setValue_arrayElement(t, e) {
    this.resolvedProperty[this.propertyIndex] = t[e];
  }
  _setValue_arrayElement_setNeedsUpdate(t, e) {
    this.resolvedProperty[this.propertyIndex] = t[e], this.targetObject.needsUpdate = true;
  }
  _setValue_arrayElement_setMatrixWorldNeedsUpdate(t, e) {
    this.resolvedProperty[this.propertyIndex] = t[e], this.targetObject.matrixWorldNeedsUpdate = true;
  }
  _setValue_fromArray(t, e) {
    this.resolvedProperty.fromArray(t, e);
  }
  _setValue_fromArray_setNeedsUpdate(t, e) {
    this.resolvedProperty.fromArray(t, e), this.targetObject.needsUpdate = true;
  }
  _setValue_fromArray_setMatrixWorldNeedsUpdate(t, e) {
    this.resolvedProperty.fromArray(t, e), this.targetObject.matrixWorldNeedsUpdate = true;
  }
  _getValue_unbound(t, e) {
    this.bind(), this.getValue(t, e);
  }
  _setValue_unbound(t, e) {
    this.bind(), this.setValue(t, e);
  }
  bind() {
    let t = this.node;
    const e = this.parsedPath, i = e.objectName, s = e.propertyName;
    let n = e.propertyIndex;
    if (t || (t = Z.findNode(this.rootNode, e.nodeName), this.node = t), this.getValue = this._getValue_unavailable, this.setValue = this._setValue_unavailable, !t) {
      N("PropertyBinding: No target node found for track: " + this.path + ".");
      return;
    }
    if (i) {
      let h = e.objectIndex;
      switch (i) {
        case "materials":
          if (!t.material) {
            Y("PropertyBinding: Can not bind to material as node does not have a material.", this);
            return;
          }
          if (!t.material.materials) {
            Y("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.", this);
            return;
          }
          t = t.material.materials;
          break;
        case "bones":
          if (!t.skeleton) {
            Y("PropertyBinding: Can not bind to bones as node does not have a skeleton.", this);
            return;
          }
          t = t.skeleton.bones;
          for (let c = 0; c < t.length; c++) if (t[c].name === h) {
            h = c;
            break;
          }
          break;
        case "map":
          if ("map" in t) {
            t = t.map;
            break;
          }
          if (!t.material) {
            Y("PropertyBinding: Can not bind to material as node does not have a material.", this);
            return;
          }
          if (!t.material.map) {
            Y("PropertyBinding: Can not bind to material.map as node.material does not have a map.", this);
            return;
          }
          t = t.material.map;
          break;
        default:
          if (t[i] === void 0) {
            Y("PropertyBinding: Can not bind to objectName of node undefined.", this);
            return;
          }
          t = t[i];
      }
      if (h !== void 0) {
        if (t[h] === void 0) {
          Y("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.", this, t);
          return;
        }
        t = t[h];
      }
    }
    const r = t[s];
    if (r === void 0) {
      const h = e.nodeName;
      Y("PropertyBinding: Trying to update property for track: " + h + "." + s + " but it wasn't found.", t);
      return;
    }
    let a = this.Versioning.None;
    this.targetObject = t, t.isMaterial === true ? a = this.Versioning.NeedsUpdate : t.isObject3D === true && (a = this.Versioning.MatrixWorldNeedsUpdate);
    let o = this.BindingType.Direct;
    if (n !== void 0) {
      if (s === "morphTargetInfluences") {
        if (!t.geometry) {
          Y("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.", this);
          return;
        }
        if (!t.geometry.morphAttributes) {
          Y("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.", this);
          return;
        }
        t.morphTargetDictionary[n] !== void 0 && (n = t.morphTargetDictionary[n]);
      }
      o = this.BindingType.ArrayElement, this.resolvedProperty = r, this.propertyIndex = n;
    } else r.fromArray !== void 0 && r.toArray !== void 0 ? (o = this.BindingType.HasFromToArray, this.resolvedProperty = r) : Array.isArray(r) ? (o = this.BindingType.EntireArray, this.resolvedProperty = r) : this.propertyName = s;
    this.getValue = this.GetterByBindingType[o], this.setValue = this.SetterByBindingTypeAndVersioning[o][a];
  }
  unbind() {
    this.node = null, this.getValue = this._getValue_unbound, this.setValue = this._setValue_unbound;
  }
}
Z.Composite = nd;
Z.prototype.BindingType = { Direct: 0, EntireArray: 1, ArrayElement: 2, HasFromToArray: 3 };
Z.prototype.Versioning = { None: 0, NeedsUpdate: 1, MatrixWorldNeedsUpdate: 2 };
Z.prototype.GetterByBindingType = [Z.prototype._getValue_direct, Z.prototype._getValue_array, Z.prototype._getValue_arrayElement, Z.prototype._getValue_toArray];
Z.prototype.SetterByBindingTypeAndVersioning = [[Z.prototype._setValue_direct, Z.prototype._setValue_direct_setNeedsUpdate, Z.prototype._setValue_direct_setMatrixWorldNeedsUpdate], [Z.prototype._setValue_array, Z.prototype._setValue_array_setNeedsUpdate, Z.prototype._setValue_array_setMatrixWorldNeedsUpdate], [Z.prototype._setValue_arrayElement, Z.prototype._setValue_arrayElement_setNeedsUpdate, Z.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate], [Z.prototype._setValue_fromArray, Z.prototype._setValue_fromArray_setNeedsUpdate, Z.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];
class Gf {
  constructor() {
    this.isAnimationObjectGroup = true, this.uuid = zt(), this._objects = Array.prototype.slice.call(arguments), this.nCachedObjects_ = 0;
    const t = {};
    this._indicesByUUID = t;
    for (let i = 0, s = arguments.length; i !== s; ++i) t[arguments[i].uuid] = i;
    this._paths = [], this._parsedPaths = [], this._bindings = [], this._bindingsIndicesByPath = {};
    const e = this;
    this.stats = { objects: { get total() {
      return e._objects.length;
    }, get inUse() {
      return this.total - e.nCachedObjects_;
    } }, get bindingsPerObject() {
      return e._bindings.length;
    } };
  }
  add() {
    const t = this._objects, e = this._indicesByUUID, i = this._paths, s = this._parsedPaths, n = this._bindings, r = n.length;
    let a, o = t.length, h = this.nCachedObjects_;
    for (let c = 0, u = arguments.length; c !== u; ++c) {
      const d = arguments[c], p = d.uuid;
      let f = e[p];
      if (f === void 0) {
        f = o++, e[p] = f, t.push(d);
        for (let m = 0, g = r; m !== g; ++m) n[m].push(new Z(d, i[m], s[m]));
      } else if (f < h) {
        a = t[f];
        const m = --h, g = t[m];
        e[g.uuid] = f, t[f] = g, e[p] = m, t[m] = d;
        for (let y = 0, x = r; y !== x; ++y) {
          const b = n[y], M = b[m];
          let _ = b[f];
          b[f] = M, _ === void 0 && (_ = new Z(d, i[y], s[y])), b[m] = _;
        }
      } else t[f] !== a && Y("AnimationObjectGroup: Different objects with the same UUID detected. Clean the caches or recreate your infrastructure when reloading scenes.");
    }
    this.nCachedObjects_ = h;
  }
  remove() {
    const t = this._objects, e = this._indicesByUUID, i = this._bindings, s = i.length;
    let n = this.nCachedObjects_;
    for (let r = 0, a = arguments.length; r !== a; ++r) {
      const o = arguments[r], h = o.uuid, c = e[h];
      if (c !== void 0 && c >= n) {
        const u = n++, d = t[u];
        e[d.uuid] = c, t[c] = d, e[h] = u, t[u] = o;
        for (let p = 0, f = s; p !== f; ++p) {
          const m = i[p], g = m[u], y = m[c];
          m[c] = g, m[u] = y;
        }
      }
    }
    this.nCachedObjects_ = n;
  }
  uncache() {
    const t = this._objects, e = this._indicesByUUID, i = this._bindings, s = i.length;
    let n = this.nCachedObjects_, r = t.length;
    for (let a = 0, o = arguments.length; a !== o; ++a) {
      const h = arguments[a], c = h.uuid, u = e[c];
      if (u !== void 0) if (delete e[c], u < n) {
        const d = --n, p = t[d], f = --r, m = t[f];
        e[p.uuid] = u, t[u] = p, e[m.uuid] = d, t[d] = m, t.pop();
        for (let g = 0, y = s; g !== y; ++g) {
          const x = i[g], b = x[d], M = x[f];
          x[u] = b, x[d] = M, x.pop();
        }
      } else {
        const d = --r, p = t[d];
        d > 0 && (e[p.uuid] = u), t[u] = p, t.pop();
        for (let f = 0, m = s; f !== m; ++f) {
          const g = i[f];
          g[u] = g[d], g.pop();
        }
      }
    }
    this.nCachedObjects_ = n;
  }
  subscribe_(t, e) {
    const i = this._bindingsIndicesByPath;
    let s = i[t];
    const n = this._bindings;
    if (s !== void 0) return n[s];
    const r = this._paths, a = this._parsedPaths, o = this._objects, h = o.length, c = this.nCachedObjects_, u = new Array(h);
    s = n.length, i[t] = s, r.push(t), a.push(e), n.push(u);
    for (let d = c, p = o.length; d !== p; ++d) {
      const f = o[d];
      u[d] = new Z(f, t, e);
    }
    return u;
  }
  unsubscribe_(t) {
    const e = this._bindingsIndicesByPath, i = e[t];
    if (i !== void 0) {
      const s = this._paths, n = this._parsedPaths, r = this._bindings, a = r.length - 1, o = r[a], h = t[a];
      e[h] = i, r[i] = o, r.pop(), n[i] = n[a], n.pop(), s[i] = s[a], s.pop();
    }
  }
}
class rd {
  constructor(t, e, i = null, s = e.blendMode) {
    this._mixer = t, this._clip = e, this._localRoot = i, this.blendMode = s;
    const n = e.tracks, r = n.length, a = new Array(r), o = { endingStart: fi, endingEnd: fi };
    for (let h = 0; h !== r; ++h) {
      const c = n[h].createInterpolant(null);
      a[h] = c, c.settings = o;
    }
    this._interpolantSettings = o, this._interpolants = a, this._propertyBindings = new Array(r), this._cacheIndex = null, this._byClipCacheIndex = null, this._timeScaleInterpolant = null, this._weightInterpolant = null, this.loop = ml, this._loopCount = -1, this._startTime = null, this.time = 0, this.timeScale = 1, this._effectiveTimeScale = 1, this.weight = 1, this._effectiveWeight = 1, this.repetitions = 1 / 0, this.paused = false, this.enabled = true, this.clampWhenFinished = false, this.zeroSlopeAtStart = true, this.zeroSlopeAtEnd = true;
  }
  play() {
    return this._mixer._activateAction(this), this;
  }
  stop() {
    return this._mixer._deactivateAction(this), this.reset();
  }
  reset() {
    return this.paused = false, this.enabled = true, this.time = 0, this._loopCount = -1, this._startTime = null, this.stopFading().stopWarping();
  }
  isRunning() {
    return this.enabled && !this.paused && this.timeScale !== 0 && this._startTime === null && this._mixer._isActiveAction(this);
  }
  isScheduled() {
    return this._mixer._isActiveAction(this);
  }
  startAt(t) {
    return this._startTime = t, this;
  }
  setLoop(t, e) {
    return this.loop = t, this.repetitions = e, this;
  }
  setEffectiveWeight(t) {
    return this.weight = t, this._effectiveWeight = this.enabled ? t : 0, this.stopFading();
  }
  getEffectiveWeight() {
    return this._effectiveWeight;
  }
  fadeIn(t) {
    return this._scheduleFading(t, 0, 1);
  }
  fadeOut(t) {
    return this._scheduleFading(t, 1, 0);
  }
  crossFadeFrom(t, e, i = false) {
    if (t.fadeOut(e), this.fadeIn(e), i === true) {
      const s = this._clip.duration, n = t._clip.duration, r = n / s, a = s / n;
      t.warp(1, r, e), this.warp(a, 1, e);
    }
    return this;
  }
  crossFadeTo(t, e, i = false) {
    return t.crossFadeFrom(this, e, i);
  }
  stopFading() {
    const t = this._weightInterpolant;
    return t !== null && (this._weightInterpolant = null, this._mixer._takeBackControlInterpolant(t)), this;
  }
  setEffectiveTimeScale(t) {
    return this.timeScale = t, this._effectiveTimeScale = this.paused ? 0 : t, this.stopWarping();
  }
  getEffectiveTimeScale() {
    return this._effectiveTimeScale;
  }
  setDuration(t) {
    return this.timeScale = this._clip.duration / t, this.stopWarping();
  }
  syncWith(t) {
    return this.time = t.time, this.timeScale = t.timeScale, this.stopWarping();
  }
  halt(t) {
    return this.warp(this._effectiveTimeScale, 0, t);
  }
  warp(t, e, i) {
    const s = this._mixer, n = s.time, r = this.timeScale;
    let a = this._timeScaleInterpolant;
    a === null && (a = s._lendControlInterpolant(), this._timeScaleInterpolant = a);
    const o = a.parameterPositions, h = a.sampleValues;
    return o[0] = n, o[1] = n + i, h[0] = t / r, h[1] = e / r, this;
  }
  stopWarping() {
    const t = this._timeScaleInterpolant;
    return t !== null && (this._timeScaleInterpolant = null, this._mixer._takeBackControlInterpolant(t)), this;
  }
  getMixer() {
    return this._mixer;
  }
  getClip() {
    return this._clip;
  }
  getRoot() {
    return this._localRoot || this._mixer._root;
  }
  _update(t, e, i, s) {
    if (!this.enabled) {
      this._updateWeight(t);
      return;
    }
    const n = this._startTime;
    if (n !== null) {
      const o = (t - n) * i;
      o < 0 || i === 0 ? e = 0 : (this._startTime = null, e = i * o);
    }
    e *= this._updateTimeScale(t);
    const r = this._updateTime(e), a = this._updateWeight(t);
    if (a > 0) {
      const o = this._interpolants, h = this._propertyBindings;
      switch (this.blendMode) {
        case _o:
          for (let c = 0, u = o.length; c !== u; ++c) o[c].evaluate(r), h[c].accumulateAdditive(a);
          break;
        case cr:
        default:
          for (let c = 0, u = o.length; c !== u; ++c) o[c].evaluate(r), h[c].accumulate(s, a);
      }
    }
  }
  _updateWeight(t) {
    let e = 0;
    if (this.enabled) {
      e = this.weight;
      const i = this._weightInterpolant;
      if (i !== null) {
        const s = i.evaluate(t)[0];
        e *= s, t > i.parameterPositions[1] && (this.stopFading(), s === 0 && (this.enabled = false));
      }
    }
    return this._effectiveWeight = e, e;
  }
  _updateTimeScale(t) {
    let e = 0;
    if (!this.paused) {
      e = this.timeScale;
      const i = this._timeScaleInterpolant;
      if (i !== null) {
        const s = i.evaluate(t)[0];
        e *= s, t > i.parameterPositions[1] && (this.stopWarping(), e === 0 ? this.paused = true : this.timeScale = e);
      }
    }
    return this._effectiveTimeScale = e, e;
  }
  _updateTime(t) {
    const e = this._clip.duration, i = this.loop;
    let s = this.time + t, n = this._loopCount;
    const r = i === yl;
    if (t === 0) return n === -1 ? s : r && (n & 1) === 1 ? e - s : s;
    if (i === fl) {
      n === -1 && (this._loopCount = 0, this._setEndings(true, true, false));
      t: {
        if (s >= e) s = e;
        else if (s < 0) s = 0;
        else {
          this.time = s;
          break t;
        }
        this.clampWhenFinished ? this.paused = true : this.enabled = false, this.time = s, this._mixer.dispatchEvent({ type: "finished", action: this, direction: t < 0 ? -1 : 1 });
      }
    } else {
      if (n === -1 && (t >= 0 ? (n = 0, this._setEndings(true, this.repetitions === 0, r)) : this._setEndings(this.repetitions === 0, true, r)), s >= e || s < 0) {
        const a = Math.floor(s / e);
        s -= e * a, n += Math.abs(a);
        const o = this.repetitions - n;
        if (o <= 0) this.clampWhenFinished ? this.paused = true : this.enabled = false, s = t > 0 ? e : 0, this.time = s, this._mixer.dispatchEvent({ type: "finished", action: this, direction: t > 0 ? 1 : -1 });
        else {
          if (o === 1) {
            const h = t < 0;
            this._setEndings(h, !h, r);
          } else this._setEndings(false, false, r);
          this._loopCount = n, this.time = s, this._mixer.dispatchEvent({ type: "loop", action: this, loopDelta: a });
        }
      } else this.time = s;
      if (r && (n & 1) === 1) return e - s;
    }
    return s;
  }
  _setEndings(t, e, i) {
    const s = this._interpolantSettings;
    i ? (s.endingStart = mi, s.endingEnd = mi) : (t ? s.endingStart = this.zeroSlopeAtStart ? mi : fi : s.endingStart = Js, e ? s.endingEnd = this.zeroSlopeAtEnd ? mi : fi : s.endingEnd = Js);
  }
  _scheduleFading(t, e, i) {
    const s = this._mixer, n = s.time;
    let r = this._weightInterpolant;
    r === null && (r = s._lendControlInterpolant(), this._weightInterpolant = r);
    const a = r.parameterPositions, o = r.sampleValues;
    return a[0] = n, o[0] = e, a[1] = n + t, o[1] = i, this;
  }
}
const ad = new Float32Array(1);
class qf extends Se {
  constructor(t) {
    super(), this._root = t, this._initMemoryManager(), this._accuIndex = 0, this.time = 0, this.timeScale = 1, typeof __THREE_DEVTOOLS__ < "u" && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
  }
  _bindAction(t, e) {
    const i = t._localRoot || this._root, s = t._clip.tracks, n = s.length, r = t._propertyBindings, a = t._interpolants, o = i.uuid, h = this._bindingsByRootAndName;
    let c = h[o];
    c === void 0 && (c = {}, h[o] = c);
    for (let u = 0; u !== n; ++u) {
      const d = s[u], p = d.name;
      let f = c[p];
      if (f !== void 0) ++f.referenceCount, r[u] = f;
      else {
        if (f = r[u], f !== void 0) {
          f._cacheIndex === null && (++f.referenceCount, this._addInactiveBinding(f, o, p));
          continue;
        }
        const m = e && e._propertyBindings[u].binding.parsedPath;
        f = new Yu(Z.create(i, p, m), d.ValueTypeName, d.getValueSize()), ++f.referenceCount, this._addInactiveBinding(f, o, p), r[u] = f;
      }
      a[u].resultBuffer = f.buffer;
    }
  }
  _activateAction(t) {
    if (!this._isActiveAction(t)) {
      if (t._cacheIndex === null) {
        const i = (t._localRoot || this._root).uuid, s = t._clip.uuid, n = this._actionsByClip[s];
        this._bindAction(t, n && n.knownActions[0]), this._addInactiveAction(t, s, i);
      }
      const e = t._propertyBindings;
      for (let i = 0, s = e.length; i !== s; ++i) {
        const n = e[i];
        n.useCount++ === 0 && (this._lendBinding(n), n.saveOriginalState());
      }
      this._lendAction(t);
    }
  }
  _deactivateAction(t) {
    if (this._isActiveAction(t)) {
      const e = t._propertyBindings;
      for (let i = 0, s = e.length; i !== s; ++i) {
        const n = e[i];
        --n.useCount === 0 && (n.restoreOriginalState(), this._takeBackBinding(n));
      }
      this._takeBackAction(t);
    }
  }
  _initMemoryManager() {
    this._actions = [], this._nActiveActions = 0, this._actionsByClip = {}, this._bindings = [], this._nActiveBindings = 0, this._bindingsByRootAndName = {}, this._controlInterpolants = [], this._nActiveControlInterpolants = 0;
    const t = this;
    this.stats = { actions: { get total() {
      return t._actions.length;
    }, get inUse() {
      return t._nActiveActions;
    } }, bindings: { get total() {
      return t._bindings.length;
    }, get inUse() {
      return t._nActiveBindings;
    } }, controlInterpolants: { get total() {
      return t._controlInterpolants.length;
    }, get inUse() {
      return t._nActiveControlInterpolants;
    } } };
  }
  _isActiveAction(t) {
    const e = t._cacheIndex;
    return e !== null && e < this._nActiveActions;
  }
  _addInactiveAction(t, e, i) {
    const s = this._actions, n = this._actionsByClip;
    let r = n[e];
    if (r === void 0) r = { knownActions: [t], actionByRoot: {} }, t._byClipCacheIndex = 0, n[e] = r;
    else {
      const a = r.knownActions;
      t._byClipCacheIndex = a.length, a.push(t);
    }
    t._cacheIndex = s.length, s.push(t), r.actionByRoot[i] = t;
  }
  _removeInactiveAction(t) {
    const e = this._actions, i = e[e.length - 1], s = t._cacheIndex;
    i._cacheIndex = s, e[s] = i, e.pop(), t._cacheIndex = null;
    const n = t._clip.uuid, r = this._actionsByClip, a = r[n], o = a.knownActions, h = o[o.length - 1], c = t._byClipCacheIndex;
    h._byClipCacheIndex = c, o[c] = h, o.pop(), t._byClipCacheIndex = null;
    const u = a.actionByRoot, d = (t._localRoot || this._root).uuid;
    delete u[d], o.length === 0 && delete r[n], this._removeInactiveBindingsForAction(t);
  }
  _removeInactiveBindingsForAction(t) {
    const e = t._propertyBindings;
    for (let i = 0, s = e.length; i !== s; ++i) {
      const n = e[i];
      --n.referenceCount === 0 && this._removeInactiveBinding(n);
    }
  }
  _lendAction(t) {
    const e = this._actions, i = t._cacheIndex, s = this._nActiveActions++, n = e[s];
    t._cacheIndex = s, e[s] = t, n._cacheIndex = i, e[i] = n;
  }
  _takeBackAction(t) {
    const e = this._actions, i = t._cacheIndex, s = --this._nActiveActions, n = e[s];
    t._cacheIndex = s, e[s] = t, n._cacheIndex = i, e[i] = n;
  }
  _addInactiveBinding(t, e, i) {
    const s = this._bindingsByRootAndName, n = this._bindings;
    let r = s[e];
    r === void 0 && (r = {}, s[e] = r), r[i] = t, t._cacheIndex = n.length, n.push(t);
  }
  _removeInactiveBinding(t) {
    const e = this._bindings, i = t.binding, s = i.rootNode.uuid, n = i.path, r = this._bindingsByRootAndName, a = r[s], o = e[e.length - 1], h = t._cacheIndex;
    o._cacheIndex = h, e[h] = o, e.pop(), delete a[n], Object.keys(a).length === 0 && delete r[s];
  }
  _lendBinding(t) {
    const e = this._bindings, i = t._cacheIndex, s = this._nActiveBindings++, n = e[s];
    t._cacheIndex = s, e[s] = t, n._cacheIndex = i, e[i] = n;
  }
  _takeBackBinding(t) {
    const e = this._bindings, i = t._cacheIndex, s = --this._nActiveBindings, n = e[s];
    t._cacheIndex = s, e[s] = t, n._cacheIndex = i, e[i] = n;
  }
  _lendControlInterpolant() {
    const t = this._controlInterpolants, e = this._nActiveControlInterpolants++;
    let i = t[e];
    return i === void 0 && (i = new Zo(new Float32Array(2), new Float32Array(2), 1, ad), i.__cacheIndex = e, t[e] = i), i;
  }
  _takeBackControlInterpolant(t) {
    const e = this._controlInterpolants, i = t.__cacheIndex, s = --this._nActiveControlInterpolants, n = e[s];
    t.__cacheIndex = s, e[s] = t, n.__cacheIndex = i, e[i] = n;
  }
  clipAction(t, e, i) {
    const s = e || this._root, n = s.uuid;
    let r = typeof t == "string" ? tn.findByName(s, t) : t;
    const a = r !== null ? r.uuid : t, o = this._actionsByClip[a];
    let h = null;
    if (i === void 0 && (r !== null ? i = r.blendMode : i = cr), o !== void 0) {
      const u = o.actionByRoot[n];
      if (u !== void 0 && u.blendMode === i) return u;
      h = o.knownActions[0], r === null && (r = h._clip);
    }
    if (r === null) return null;
    const c = new rd(this, r, e, i);
    return this._bindAction(c, h), this._addInactiveAction(c, a, n), c;
  }
  existingAction(t, e) {
    const i = e || this._root, s = i.uuid, n = typeof t == "string" ? tn.findByName(i, t) : t, r = n ? n.uuid : t, a = this._actionsByClip[r];
    return a !== void 0 && a.actionByRoot[s] || null;
  }
  stopAllAction() {
    const t = this._actions, e = this._nActiveActions;
    for (let i = e - 1; i >= 0; --i) t[i].stop();
    return this;
  }
  update(t) {
    t *= this.timeScale;
    const e = this._actions, i = this._nActiveActions, s = this.time += t, n = Math.sign(t), r = this._accuIndex ^= 1;
    for (let h = 0; h !== i; ++h) e[h]._update(s, t, n, r);
    const a = this._bindings, o = this._nActiveBindings;
    for (let h = 0; h !== o; ++h) a[h].apply(r);
    return this;
  }
  setTime(t) {
    this.time = 0;
    for (let e = 0; e < this._actions.length; e++) this._actions[e].time = 0;
    return this.update(t);
  }
  getRoot() {
    return this._root;
  }
  uncacheClip(t) {
    const e = this._actions, i = t.uuid, s = this._actionsByClip, n = s[i];
    if (n !== void 0) {
      const r = n.knownActions;
      for (let a = 0, o = r.length; a !== o; ++a) {
        const h = r[a];
        this._deactivateAction(h);
        const c = h._cacheIndex, u = e[e.length - 1];
        h._cacheIndex = null, h._byClipCacheIndex = null, u._cacheIndex = c, e[c] = u, e.pop(), this._removeInactiveBindingsForAction(h);
      }
      delete s[i];
    }
  }
  uncacheRoot(t) {
    const e = t.uuid, i = this._actionsByClip;
    for (const r in i) {
      const a = i[r].actionByRoot, o = a[e];
      o !== void 0 && (this._deactivateAction(o), this._removeInactiveAction(o));
    }
    const s = this._bindingsByRootAndName, n = s[e];
    if (n !== void 0) for (const r in n) {
      const a = n[r];
      a.restoreOriginalState(), this._removeInactiveBinding(a);
    }
  }
  uncacheAction(t, e) {
    const i = this.existingAction(t, e);
    i !== null && (this._deactivateAction(i), this._removeInactiveAction(i));
  }
}
class Hf extends To {
  constructor(t = 1, e = 1, i = 1, s = {}) {
    super(t, e, s), this.isRenderTarget3D = true, this.depth = i, this.texture = new Io(null, t, e, i), this._setTextureOptions(s), this.texture.isRenderTargetTexture = true;
  }
}
class th {
  constructor(t) {
    this.value = t;
  }
  clone() {
    return new th(this.value.clone === void 0 ? this.value : this.value.clone());
  }
}
let od = 0;
class Jf extends Se {
  constructor() {
    super(), this.isUniformsGroup = true, Object.defineProperty(this, "id", { value: od++ }), this.name = "", this.usage = Xs, this.uniforms = [];
  }
  add(t) {
    return this.uniforms.push(t), this;
  }
  remove(t) {
    const e = this.uniforms.indexOf(t);
    return e !== -1 && this.uniforms.splice(e, 1), this;
  }
  setName(t) {
    return this.name = t, this;
  }
  setUsage(t) {
    return this.usage = t, this;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
  copy(t) {
    this.name = t.name, this.usage = t.usage;
    const e = t.uniforms;
    this.uniforms.length = 0;
    for (let i = 0, s = e.length; i < s; i++) {
      const n = Array.isArray(e[i]) ? e[i] : [e[i]];
      for (let r = 0; r < n.length; r++) this.uniforms.push(n[r].clone());
    }
    return this;
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
class Xf extends fr {
  constructor(t, e, i = 1) {
    super(t, e), this.isInstancedInterleavedBuffer = true, this.meshPerAttribute = i;
  }
  copy(t) {
    return super.copy(t), this.meshPerAttribute = t.meshPerAttribute, this;
  }
  clone(t) {
    const e = super.clone(t);
    return e.meshPerAttribute = this.meshPerAttribute, e;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.isInstancedInterleavedBuffer = true, e.meshPerAttribute = this.meshPerAttribute, e;
  }
}
class Zf {
  constructor(t, e, i, s, n, r = false) {
    this.isGLBufferAttribute = true, this.name = "", this.buffer = t, this.type = e, this.itemSize = i, this.elementSize = s, this.count = n, this.normalized = r, this.version = 0;
  }
  set needsUpdate(t) {
    t === true && this.version++;
  }
  setBuffer(t) {
    return this.buffer = t, this;
  }
  setType(t, e) {
    return this.type = t, this.elementSize = e, this;
  }
  setItemSize(t) {
    return this.itemSize = t, this;
  }
  setCount(t) {
    return this.count = t, this;
  }
}
const lo = new G();
class Yf {
  constructor(t, e, i = 0, s = 1 / 0) {
    this.ray = new ji(t, e), this.near = i, this.far = s, this.camera = null, this.layers = new zo(), this.params = { Mesh: {}, Line: { threshold: 1 }, LOD: {}, Points: { threshold: 1 }, Sprite: {} };
  }
  set(t, e) {
    this.ray.set(t, e);
  }
  setFromCamera(t, e) {
    e.isPerspectiveCamera ? (this.ray.origin.setFromMatrixPosition(e.matrixWorld), this.ray.direction.set(t.x, t.y, 0.5).unproject(e).sub(this.ray.origin).normalize(), this.camera = e) : e.isOrthographicCamera ? (this.ray.origin.set(t.x, t.y, (e.near + e.far) / (e.near - e.far)).unproject(e), this.ray.direction.set(0, 0, -1).transformDirection(e.matrixWorld), this.camera = e) : Y("Raycaster: Unsupported camera type: " + e.type);
  }
  setFromXRController(t) {
    return lo.identity().extractRotation(t.matrixWorld), this.ray.origin.setFromMatrixPosition(t.matrixWorld), this.ray.direction.set(0, 0, -1).applyMatrix4(lo), this;
  }
  intersectObject(t, e = true, i = []) {
    return rr(t, this, i, e), i.sort(co), i;
  }
  intersectObjects(t, e = true, i = []) {
    for (let s = 0, n = t.length; s < n; s++) rr(t[s], this, i, e);
    return i.sort(co), i;
  }
}
function co(l, t) {
  return l.distance - t.distance;
}
function rr(l, t, e, i) {
  let s = true;
  if (l.layers.test(t.layers) && l.raycast(t, e) === false && (s = false), s === true && i === true) {
    const n = l.children;
    for (let r = 0, a = n.length; r < a; r++) rr(n[r], t, e, true);
  }
}
class $f {
  constructor(t = true) {
    this.autoStart = t, this.startTime = 0, this.oldTime = 0, this.elapsedTime = 0, this.running = false, N("THREE.Clock: This module has been deprecated. Please use THREE.Timer instead.");
  }
  start() {
    this.startTime = performance.now(), this.oldTime = this.startTime, this.elapsedTime = 0, this.running = true;
  }
  stop() {
    this.getElapsedTime(), this.running = false, this.autoStart = false;
  }
  getElapsedTime() {
    return this.getDelta(), this.elapsedTime;
  }
  getDelta() {
    let t = 0;
    if (this.autoStart && !this.running) return this.start(), 0;
    if (this.running) {
      const e = performance.now();
      t = (e - this.oldTime) / 1e3, this.oldTime = e, this.elapsedTime += t;
    }
    return t;
  }
}
class jf {
  constructor(t = 1, e = 0, i = 0) {
    this.radius = t, this.phi = e, this.theta = i;
  }
  set(t, e, i) {
    return this.radius = t, this.phi = e, this.theta = i, this;
  }
  copy(t) {
    return this.radius = t.radius, this.phi = t.phi, this.theta = t.theta, this;
  }
  makeSafe() {
    return this.phi = L(this.phi, 1e-6, Math.PI - 1e-6), this;
  }
  setFromVector3(t) {
    return this.setFromCartesianCoords(t.x, t.y, t.z);
  }
  setFromCartesianCoords(t, e, i) {
    return this.radius = Math.sqrt(t * t + e * e + i * i), this.radius === 0 ? (this.theta = 0, this.phi = 0) : (this.theta = Math.atan2(t, i), this.phi = Math.acos(L(e / this.radius, -1, 1))), this;
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
class Qf {
  constructor(t = 1, e = 0, i = 0) {
    this.radius = t, this.theta = e, this.y = i;
  }
  set(t, e, i) {
    return this.radius = t, this.theta = e, this.y = i, this;
  }
  copy(t) {
    return this.radius = t.radius, this.theta = t.theta, this.y = t.y, this;
  }
  setFromVector3(t) {
    return this.setFromCartesianCoords(t.x, t.y, t.z);
  }
  setFromCartesianCoords(t, e, i) {
    return this.radius = Math.sqrt(t * t + i * i), this.theta = Math.atan2(t, i), this.y = e, this;
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
class eh {
  constructor(t, e, i, s) {
    eh.prototype.isMatrix2 = true, this.elements = [1, 0, 0, 1], t !== void 0 && this.set(t, e, i, s);
  }
  identity() {
    return this.set(1, 0, 0, 1), this;
  }
  fromArray(t, e = 0) {
    for (let i = 0; i < 4; i++) this.elements[i] = t[i + e];
    return this;
  }
  set(t, e, i, s) {
    const n = this.elements;
    return n[0] = t, n[2] = e, n[1] = i, n[3] = s, this;
  }
}
const uo = new I();
class Kf {
  constructor(t = new I(1 / 0, 1 / 0), e = new I(-1 / 0, -1 / 0)) {
    this.isBox2 = true, this.min = t, this.max = e;
  }
  set(t, e) {
    return this.min.copy(t), this.max.copy(e), this;
  }
  setFromPoints(t) {
    this.makeEmpty();
    for (let e = 0, i = t.length; e < i; e++) this.expandByPoint(t[e]);
    return this;
  }
  setFromCenterAndSize(t, e) {
    const i = uo.copy(e).multiplyScalar(0.5);
    return this.min.copy(t).sub(i), this.max.copy(t).add(i), this;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    return this.min.copy(t.min), this.max.copy(t.max), this;
  }
  makeEmpty() {
    return this.min.x = this.min.y = 1 / 0, this.max.x = this.max.y = -1 / 0, this;
  }
  isEmpty() {
    return this.max.x < this.min.x || this.max.y < this.min.y;
  }
  getCenter(t) {
    return this.isEmpty() ? t.set(0, 0) : t.addVectors(this.min, this.max).multiplyScalar(0.5);
  }
  getSize(t) {
    return this.isEmpty() ? t.set(0, 0) : t.subVectors(this.max, this.min);
  }
  expandByPoint(t) {
    return this.min.min(t), this.max.max(t), this;
  }
  expandByVector(t) {
    return this.min.sub(t), this.max.add(t), this;
  }
  expandByScalar(t) {
    return this.min.addScalar(-t), this.max.addScalar(t), this;
  }
  containsPoint(t) {
    return t.x >= this.min.x && t.x <= this.max.x && t.y >= this.min.y && t.y <= this.max.y;
  }
  containsBox(t) {
    return this.min.x <= t.min.x && t.max.x <= this.max.x && this.min.y <= t.min.y && t.max.y <= this.max.y;
  }
  getParameter(t, e) {
    return e.set((t.x - this.min.x) / (this.max.x - this.min.x), (t.y - this.min.y) / (this.max.y - this.min.y));
  }
  intersectsBox(t) {
    return t.max.x >= this.min.x && t.min.x <= this.max.x && t.max.y >= this.min.y && t.min.y <= this.max.y;
  }
  clampPoint(t, e) {
    return e.copy(t).clamp(this.min, this.max);
  }
  distanceToPoint(t) {
    return this.clampPoint(t, uo).distanceTo(t);
  }
  intersect(t) {
    return this.min.max(t.min), this.max.min(t.max), this.isEmpty() && this.makeEmpty(), this;
  }
  union(t) {
    return this.min.min(t.min), this.max.max(t.max), this;
  }
  translate(t) {
    return this.min.add(t), this.max.add(t), this;
  }
  equals(t) {
    return t.min.equals(this.min) && t.max.equals(this.max);
  }
}
const po = new w(), Ls = new w(), di = new w(), pi = new w(), Jn = new w(), hd = new w(), ld = new w();
class tm {
  constructor(t = new w(), e = new w()) {
    this.start = t, this.end = e;
  }
  set(t, e) {
    return this.start.copy(t), this.end.copy(e), this;
  }
  copy(t) {
    return this.start.copy(t.start), this.end.copy(t.end), this;
  }
  getCenter(t) {
    return t.addVectors(this.start, this.end).multiplyScalar(0.5);
  }
  delta(t) {
    return t.subVectors(this.end, this.start);
  }
  distanceSq() {
    return this.start.distanceToSquared(this.end);
  }
  distance() {
    return this.start.distanceTo(this.end);
  }
  at(t, e) {
    return this.delta(e).multiplyScalar(t).add(this.start);
  }
  closestPointToPointParameter(t, e) {
    po.subVectors(t, this.start), Ls.subVectors(this.end, this.start);
    const i = Ls.dot(Ls);
    let n = Ls.dot(po) / i;
    return e && (n = L(n, 0, 1)), n;
  }
  closestPointToPoint(t, e, i) {
    const s = this.closestPointToPointParameter(t, e);
    return this.delta(i).multiplyScalar(s).add(this.start);
  }
  distanceSqToLine3(t, e = hd, i = ld) {
    const s = 10000000000000001e-32;
    let n, r;
    const a = this.start, o = t.start, h = this.end, c = t.end;
    di.subVectors(h, a), pi.subVectors(c, o), Jn.subVectors(a, o);
    const u = di.dot(di), d = pi.dot(pi), p = pi.dot(Jn);
    if (u <= s && d <= s) return e.copy(a), i.copy(o), e.sub(i), e.dot(e);
    if (u <= s) n = 0, r = p / d, r = L(r, 0, 1);
    else {
      const f = di.dot(Jn);
      if (d <= s) r = 0, n = L(-f / u, 0, 1);
      else {
        const m = di.dot(pi), g = u * d - m * m;
        g !== 0 ? n = L((m * p - f * d) / g, 0, 1) : n = 0, r = (m * n + p) / d, r < 0 ? (r = 0, n = L(-f / u, 0, 1)) : r > 1 && (r = 1, n = L((m - f) / u, 0, 1));
      }
    }
    return e.copy(a).addScaledVector(di, n), i.copy(o).addScaledVector(pi, r), e.distanceToSquared(i);
  }
  applyMatrix4(t) {
    return this.start.applyMatrix4(t), this.end.applyMatrix4(t), this;
  }
  equals(t) {
    return t.start.equals(this.start) && t.end.equals(this.end);
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
const fo = new w();
class em extends $ {
  constructor(t, e) {
    super(), this.light = t, this.matrixAutoUpdate = false, this.color = e, this.type = "SpotLightHelper";
    const i = new H(), s = [0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, -1, 1];
    for (let r = 0, a = 1, o = 32; r < o; r++, a++) {
      const h = r / o * Math.PI * 2, c = a / o * Math.PI * 2;
      s.push(Math.cos(h), Math.sin(h), 1, Math.cos(c), Math.sin(c), 1);
    }
    i.setAttribute("position", new P(s, 3));
    const n = new vt({ fog: false, toneMapped: false });
    this.cone = new fe(i, n), this.add(this.cone), this.update();
  }
  dispose() {
    this.cone.geometry.dispose(), this.cone.material.dispose();
  }
  update() {
    this.light.updateWorldMatrix(true, false), this.light.target.updateWorldMatrix(true, false), this.parent ? (this.parent.updateWorldMatrix(true), this.matrix.copy(this.parent.matrixWorld).invert().multiply(this.light.matrixWorld)) : this.matrix.copy(this.light.matrixWorld), this.matrixWorld.copy(this.light.matrixWorld);
    const t = this.light.distance ? this.light.distance : 1e3, e = t * Math.tan(this.light.angle);
    this.cone.scale.set(e, e, t), fo.setFromMatrixPosition(this.light.target.matrixWorld), this.cone.lookAt(fo), this.color !== void 0 ? this.cone.material.color.set(this.color) : this.cone.material.color.copy(this.light.color);
  }
}
const we = new w(), Ds = new G(), Xn = new G();
class im extends fe {
  constructor(t) {
    const e = ih(t), i = new H(), s = [], n = [];
    for (let h = 0; h < e.length; h++) {
      const c = e[h];
      c.parent && c.parent.isBone && (s.push(0, 0, 0), s.push(0, 0, 0), n.push(0, 0, 0), n.push(0, 0, 0));
    }
    i.setAttribute("position", new P(s, 3)), i.setAttribute("color", new P(n, 3));
    const r = new vt({ vertexColors: true, depthTest: false, depthWrite: false, toneMapped: false, transparent: true });
    super(i, r), this.isSkeletonHelper = true, this.type = "SkeletonHelper", this.root = t, this.bones = e, this.matrix = t.matrixWorld, this.matrixAutoUpdate = false;
    const a = new U(255), o = new U(65280);
    this.setColors(a, o);
  }
  updateMatrixWorld(t) {
    const e = this.bones, i = this.geometry, s = i.getAttribute("position");
    Xn.copy(this.root.matrixWorld).invert();
    for (let n = 0, r = 0; n < e.length; n++) {
      const a = e[n];
      a.parent && a.parent.isBone && (Ds.multiplyMatrices(Xn, a.matrixWorld), we.setFromMatrixPosition(Ds), s.setXYZ(r, we.x, we.y, we.z), Ds.multiplyMatrices(Xn, a.parent.matrixWorld), we.setFromMatrixPosition(Ds), s.setXYZ(r + 1, we.x, we.y, we.z), r += 2);
    }
    i.getAttribute("position").needsUpdate = true, super.updateMatrixWorld(t);
  }
  setColors(t, e) {
    const s = this.geometry.getAttribute("color");
    for (let n = 0; n < s.count; n += 2) s.setXYZ(n, t.r, t.g, t.b), s.setXYZ(n + 1, e.r, e.g, e.b);
    return s.needsUpdate = true, this;
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose();
  }
}
function ih(l) {
  const t = [];
  l.isBone === true && t.push(l);
  for (let e = 0; e < l.children.length; e++) t.push(...ih(l.children[e]));
  return t;
}
class sm extends Kt {
  constructor(t, e, i) {
    const s = new hn(e, 4, 2), n = new Si({ wireframe: true, fog: false, toneMapped: false });
    super(s, n), this.light = t, this.color = i, this.type = "PointLightHelper", this.matrix = this.light.matrixWorld, this.matrixAutoUpdate = false, this.update();
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose();
  }
  update() {
    this.light.updateWorldMatrix(true, false), this.color !== void 0 ? this.material.color.set(this.color) : this.material.color.copy(this.light.color);
  }
}
const cd = new w(), mo = new U(), yo = new U();
class nm extends $ {
  constructor(t, e, i) {
    super(), this.light = t, this.matrix = t.matrixWorld, this.matrixAutoUpdate = false, this.color = i, this.type = "HemisphereLightHelper";
    const s = new on(e);
    s.rotateY(Math.PI * 0.5), this.material = new Si({ wireframe: true, fog: false, toneMapped: false }), this.color === void 0 && (this.material.vertexColors = true);
    const n = s.getAttribute("position"), r = new Float32Array(n.count * 3);
    s.setAttribute("color", new tt(r, 3)), this.add(new Kt(s, this.material)), this.update();
  }
  dispose() {
    this.children[0].geometry.dispose(), this.children[0].material.dispose();
  }
  update() {
    const t = this.children[0];
    if (this.color !== void 0) this.material.color.set(this.color);
    else {
      const e = t.geometry.getAttribute("color");
      mo.copy(this.light.color), yo.copy(this.light.groundColor);
      for (let i = 0, s = e.count; i < s; i++) {
        const n = i < s / 2 ? mo : yo;
        e.setXYZ(i, n.r, n.g, n.b);
      }
      e.needsUpdate = true;
    }
    this.light.updateWorldMatrix(true, false), t.lookAt(cd.setFromMatrixPosition(this.light.matrixWorld).negate());
  }
}
class rm extends fe {
  constructor(t = 10, e = 10, i = 4473924, s = 8947848) {
    i = new U(i), s = new U(s);
    const n = e / 2, r = t / e, a = t / 2, o = [], h = [];
    for (let d = 0, p = 0, f = -a; d <= e; d++, f += r) {
      o.push(-a, 0, f, a, 0, f), o.push(f, 0, -a, f, 0, a);
      const m = d === n ? i : s;
      m.toArray(h, p), p += 3, m.toArray(h, p), p += 3, m.toArray(h, p), p += 3, m.toArray(h, p), p += 3;
    }
    const c = new H();
    c.setAttribute("position", new P(o, 3)), c.setAttribute("color", new P(h, 3));
    const u = new vt({ vertexColors: true, toneMapped: false });
    super(c, u), this.type = "GridHelper";
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose();
  }
}
class am extends fe {
  constructor(t = 10, e = 16, i = 8, s = 64, n = 4473924, r = 8947848) {
    n = new U(n), r = new U(r);
    const a = [], o = [];
    if (e > 1) for (let u = 0; u < e; u++) {
      const d = u / e * (Math.PI * 2), p = Math.sin(d) * t, f = Math.cos(d) * t;
      a.push(0, 0, 0), a.push(p, 0, f);
      const m = u & 1 ? n : r;
      o.push(m.r, m.g, m.b), o.push(m.r, m.g, m.b);
    }
    for (let u = 0; u < i; u++) {
      const d = u & 1 ? n : r, p = t - t / i * u;
      for (let f = 0; f < s; f++) {
        let m = f / s * (Math.PI * 2), g = Math.sin(m) * p, y = Math.cos(m) * p;
        a.push(g, 0, y), o.push(d.r, d.g, d.b), m = (f + 1) / s * (Math.PI * 2), g = Math.sin(m) * p, y = Math.cos(m) * p, a.push(g, 0, y), o.push(d.r, d.g, d.b);
      }
    }
    const h = new H();
    h.setAttribute("position", new P(a, 3)), h.setAttribute("color", new P(o, 3));
    const c = new vt({ vertexColors: true, toneMapped: false });
    super(h, c), this.type = "PolarGridHelper";
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose();
  }
}
const go = new w(), Vs = new w(), xo = new w();
class om extends $ {
  constructor(t, e, i) {
    super(), this.light = t, this.matrix = t.matrixWorld, this.matrixAutoUpdate = false, this.color = i, this.type = "DirectionalLightHelper", e === void 0 && (e = 1);
    let s = new H();
    s.setAttribute("position", new P([-e, e, 0, e, e, 0, e, -e, 0, -e, -e, 0, -e, e, 0], 3));
    const n = new vt({ fog: false, toneMapped: false });
    this.lightPlane = new Ue(s, n), this.add(this.lightPlane), s = new H(), s.setAttribute("position", new P([0, 0, 0, 0, 0, 1], 3)), this.targetLine = new Ue(s, n), this.add(this.targetLine), this.update();
  }
  dispose() {
    this.lightPlane.geometry.dispose(), this.lightPlane.material.dispose(), this.targetLine.geometry.dispose(), this.targetLine.material.dispose();
  }
  update() {
    this.light.updateWorldMatrix(true, false), this.light.target.updateWorldMatrix(true, false), go.setFromMatrixPosition(this.light.matrixWorld), Vs.setFromMatrixPosition(this.light.target.matrixWorld), xo.subVectors(Vs, go), this.lightPlane.lookAt(Vs), this.color !== void 0 ? (this.lightPlane.material.color.set(this.color), this.targetLine.material.color.set(this.color)) : (this.lightPlane.material.color.copy(this.light.color), this.targetLine.material.color.copy(this.light.color)), this.targetLine.lookAt(Vs), this.targetLine.scale.z = xo.length();
  }
}
const Us = new w(), nt = new Nr();
class hm extends fe {
  constructor(t) {
    const e = new H(), i = new vt({ color: 16777215, vertexColors: true, toneMapped: false }), s = [], n = [], r = {};
    a("n1", "n2"), a("n2", "n4"), a("n4", "n3"), a("n3", "n1"), a("f1", "f2"), a("f2", "f4"), a("f4", "f3"), a("f3", "f1"), a("n1", "f1"), a("n2", "f2"), a("n3", "f3"), a("n4", "f4"), a("p", "n1"), a("p", "n2"), a("p", "n3"), a("p", "n4"), a("u1", "u2"), a("u2", "u3"), a("u3", "u1"), a("c", "t"), a("p", "c"), a("cn1", "cn2"), a("cn3", "cn4"), a("cf1", "cf2"), a("cf3", "cf4");
    function a(f, m) {
      o(f), o(m);
    }
    function o(f) {
      s.push(0, 0, 0), n.push(0, 0, 0), r[f] === void 0 && (r[f] = []), r[f].push(s.length / 3 - 1);
    }
    e.setAttribute("position", new P(s, 3)), e.setAttribute("color", new P(n, 3)), super(e, i), this.type = "CameraHelper", this.camera = t, this.camera.updateProjectionMatrix && this.camera.updateProjectionMatrix(), this.matrix = t.matrixWorld, this.matrixAutoUpdate = false, this.pointMap = r, this.update();
    const h = new U(16755200), c = new U(16711680), u = new U(43775), d = new U(16777215), p = new U(3355443);
    this.setColors(h, c, u, d, p);
  }
  setColors(t, e, i, s, n) {
    const a = this.geometry.getAttribute("color");
    return a.setXYZ(0, t.r, t.g, t.b), a.setXYZ(1, t.r, t.g, t.b), a.setXYZ(2, t.r, t.g, t.b), a.setXYZ(3, t.r, t.g, t.b), a.setXYZ(4, t.r, t.g, t.b), a.setXYZ(5, t.r, t.g, t.b), a.setXYZ(6, t.r, t.g, t.b), a.setXYZ(7, t.r, t.g, t.b), a.setXYZ(8, t.r, t.g, t.b), a.setXYZ(9, t.r, t.g, t.b), a.setXYZ(10, t.r, t.g, t.b), a.setXYZ(11, t.r, t.g, t.b), a.setXYZ(12, t.r, t.g, t.b), a.setXYZ(13, t.r, t.g, t.b), a.setXYZ(14, t.r, t.g, t.b), a.setXYZ(15, t.r, t.g, t.b), a.setXYZ(16, t.r, t.g, t.b), a.setXYZ(17, t.r, t.g, t.b), a.setXYZ(18, t.r, t.g, t.b), a.setXYZ(19, t.r, t.g, t.b), a.setXYZ(20, t.r, t.g, t.b), a.setXYZ(21, t.r, t.g, t.b), a.setXYZ(22, t.r, t.g, t.b), a.setXYZ(23, t.r, t.g, t.b), a.setXYZ(24, e.r, e.g, e.b), a.setXYZ(25, e.r, e.g, e.b), a.setXYZ(26, e.r, e.g, e.b), a.setXYZ(27, e.r, e.g, e.b), a.setXYZ(28, e.r, e.g, e.b), a.setXYZ(29, e.r, e.g, e.b), a.setXYZ(30, e.r, e.g, e.b), a.setXYZ(31, e.r, e.g, e.b), a.setXYZ(32, i.r, i.g, i.b), a.setXYZ(33, i.r, i.g, i.b), a.setXYZ(34, i.r, i.g, i.b), a.setXYZ(35, i.r, i.g, i.b), a.setXYZ(36, i.r, i.g, i.b), a.setXYZ(37, i.r, i.g, i.b), a.setXYZ(38, s.r, s.g, s.b), a.setXYZ(39, s.r, s.g, s.b), a.setXYZ(40, n.r, n.g, n.b), a.setXYZ(41, n.r, n.g, n.b), a.setXYZ(42, n.r, n.g, n.b), a.setXYZ(43, n.r, n.g, n.b), a.setXYZ(44, n.r, n.g, n.b), a.setXYZ(45, n.r, n.g, n.b), a.setXYZ(46, n.r, n.g, n.b), a.setXYZ(47, n.r, n.g, n.b), a.setXYZ(48, n.r, n.g, n.b), a.setXYZ(49, n.r, n.g, n.b), a.needsUpdate = true, this;
  }
  update() {
    const t = this.geometry, e = this.pointMap, i = 1, s = 1;
    let n, r;
    if (nt.projectionMatrixInverse.copy(this.camera.projectionMatrixInverse), this.camera.reversedDepth === true) n = 1, r = 0;
    else if (this.camera.coordinateSystem === Yt) n = -1, r = 1;
    else if (this.camera.coordinateSystem === Mi) n = 0, r = 1;
    else throw new Error("THREE.CameraHelper.update(): Invalid coordinate system: " + this.camera.coordinateSystem);
    rt("c", e, t, nt, 0, 0, n), rt("t", e, t, nt, 0, 0, r), rt("n1", e, t, nt, -i, -s, n), rt("n2", e, t, nt, i, -s, n), rt("n3", e, t, nt, -i, s, n), rt("n4", e, t, nt, i, s, n), rt("f1", e, t, nt, -i, -s, r), rt("f2", e, t, nt, i, -s, r), rt("f3", e, t, nt, -i, s, r), rt("f4", e, t, nt, i, s, r), rt("u1", e, t, nt, i * 0.7, s * 1.1, n), rt("u2", e, t, nt, -i * 0.7, s * 1.1, n), rt("u3", e, t, nt, 0, s * 2, n), rt("cf1", e, t, nt, -i, 0, r), rt("cf2", e, t, nt, i, 0, r), rt("cf3", e, t, nt, 0, -s, r), rt("cf4", e, t, nt, 0, s, r), rt("cn1", e, t, nt, -i, 0, n), rt("cn2", e, t, nt, i, 0, n), rt("cn3", e, t, nt, 0, -s, n), rt("cn4", e, t, nt, 0, s, n), t.getAttribute("position").needsUpdate = true;
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose();
  }
}
function rt(l, t, e, i, s, n, r) {
  Us.set(s, n, r).unproject(i);
  const a = t[l];
  if (a !== void 0) {
    const o = e.getAttribute("position");
    for (let h = 0, c = a.length; h < c; h++) o.setXYZ(a[h], Us.x, Us.y, Us.z);
  }
}
const Ws = new xt();
class lm extends fe {
  constructor(t, e = 16776960) {
    const i = new Uint16Array([0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 0, 4, 1, 5, 2, 6, 3, 7]), s = new Float32Array(24), n = new H();
    n.setIndex(new tt(i, 1)), n.setAttribute("position", new tt(s, 3)), super(n, new vt({ color: e, toneMapped: false })), this.object = t, this.type = "BoxHelper", this.matrixAutoUpdate = false, this.update();
  }
  update() {
    if (this.object !== void 0 && Ws.setFromObject(this.object), Ws.isEmpty()) return;
    const t = Ws.min, e = Ws.max, i = this.geometry.attributes.position, s = i.array;
    s[0] = e.x, s[1] = e.y, s[2] = e.z, s[3] = t.x, s[4] = e.y, s[5] = e.z, s[6] = t.x, s[7] = t.y, s[8] = e.z, s[9] = e.x, s[10] = t.y, s[11] = e.z, s[12] = e.x, s[13] = e.y, s[14] = t.z, s[15] = t.x, s[16] = e.y, s[17] = t.z, s[18] = t.x, s[19] = t.y, s[20] = t.z, s[21] = e.x, s[22] = t.y, s[23] = t.z, i.needsUpdate = true, this.geometry.computeBoundingSphere();
  }
  setFromObject(t) {
    return this.object = t, this.update(), this;
  }
  copy(t, e) {
    return super.copy(t, e), this.object = t.object, this;
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose();
  }
}
class cm extends fe {
  constructor(t, e = 16776960) {
    const i = new Uint16Array([0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 0, 4, 1, 5, 2, 6, 3, 7]), s = [1, 1, 1, -1, 1, 1, -1, -1, 1, 1, -1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1], n = new H();
    n.setIndex(new tt(i, 1)), n.setAttribute("position", new P(s, 3)), super(n, new vt({ color: e, toneMapped: false })), this.box = t, this.type = "Box3Helper", this.geometry.computeBoundingSphere();
  }
  updateMatrixWorld(t) {
    const e = this.box;
    e.isEmpty() || (e.getCenter(this.position), e.getSize(this.scale), this.scale.multiplyScalar(0.5), super.updateMatrixWorld(t));
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose();
  }
}
class um extends Ue {
  constructor(t, e = 1, i = 16776960) {
    const s = i, n = [1, -1, 0, -1, 1, 0, -1, -1, 0, 1, 1, 0, -1, 1, 0, -1, -1, 0, 1, -1, 0, 1, 1, 0], r = new H();
    r.setAttribute("position", new P(n, 3)), r.computeBoundingSphere(), super(r, new vt({ color: s, toneMapped: false })), this.type = "PlaneHelper", this.plane = t, this.size = e;
    const a = [1, 1, 0, -1, 1, 0, -1, -1, 0, 1, 1, 0, -1, -1, 0, 1, -1, 0], o = new H();
    o.setAttribute("position", new P(a, 3)), o.computeBoundingSphere(), this.add(new Kt(o, new Si({ color: s, opacity: 0.2, transparent: true, depthWrite: false, toneMapped: false })));
  }
  updateMatrixWorld(t) {
    this.position.set(0, 0, 0), this.scale.set(0.5 * this.size, 0.5 * this.size, 1), this.lookAt(this.plane.normal), this.translateZ(-this.plane.constant), super.updateMatrixWorld(t);
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose(), this.children[0].geometry.dispose(), this.children[0].material.dispose();
  }
}
const bo = new w();
let Gs, Zn;
class dm extends $ {
  constructor(t = new w(0, 0, 1), e = new w(0, 0, 0), i = 1, s = 16776960, n = i * 0.2, r = n * 0.2) {
    super(), this.type = "ArrowHelper", Gs === void 0 && (Gs = new H(), Gs.setAttribute("position", new P([0, 0, 0, 0, 1, 0], 3)), Zn = new an(0.5, 1, 5, 1), Zn.translate(0, -0.5, 0)), this.position.copy(e), this.line = new Ue(Gs, new vt({ color: s, toneMapped: false })), this.line.matrixAutoUpdate = false, this.add(this.line), this.cone = new Kt(Zn, new Si({ color: s, toneMapped: false })), this.cone.matrixAutoUpdate = false, this.add(this.cone), this.setDirection(t), this.setLength(i, n, r);
  }
  setDirection(t) {
    if (t.y > 0.99999) this.quaternion.set(0, 0, 0, 1);
    else if (t.y < -0.99999) this.quaternion.set(1, 0, 0, 0);
    else {
      bo.set(t.z, 0, -t.x).normalize();
      const e = Math.acos(t.y);
      this.quaternion.setFromAxisAngle(bo, e);
    }
  }
  setLength(t, e = t * 0.2, i = e * 0.2) {
    this.line.scale.set(1, Math.max(1e-4, t - e), 1), this.line.updateMatrix(), this.cone.scale.set(i, e, i), this.cone.position.y = t, this.cone.updateMatrix();
  }
  setColor(t) {
    this.line.material.color.set(t), this.cone.material.color.set(t);
  }
  copy(t) {
    return super.copy(t, false), this.line.copy(t.line), this.cone.copy(t.cone), this;
  }
  dispose() {
    this.line.geometry.dispose(), this.line.material.dispose(), this.cone.geometry.dispose(), this.cone.material.dispose();
  }
}
class pm extends fe {
  constructor(t = 1) {
    const e = [0, 0, 0, t, 0, 0, 0, 0, 0, 0, t, 0, 0, 0, 0, 0, 0, t], i = [1, 0, 0, 1, 0.6, 0, 0, 1, 0, 0.6, 1, 0, 0, 0, 1, 0, 0.6, 1], s = new H();
    s.setAttribute("position", new P(e, 3)), s.setAttribute("color", new P(i, 3));
    const n = new vt({ vertexColors: true, toneMapped: false });
    super(s, n), this.type = "AxesHelper";
  }
  setColors(t, e, i) {
    const s = new U(), n = this.geometry.attributes.color.array;
    return s.set(t), s.toArray(n, 0), s.toArray(n, 3), s.set(e), s.toArray(n, 6), s.toArray(n, 9), s.set(i), s.toArray(n, 12), s.toArray(n, 15), this.geometry.attributes.color.needsUpdate = true, this;
  }
  dispose() {
    this.geometry.dispose(), this.material.dispose();
  }
}
class fm {
  constructor() {
    this.type = "ShapePath", this.color = new U(), this.subPaths = [], this.currentPath = null;
  }
  moveTo(t, e) {
    return this.currentPath = new er(), this.subPaths.push(this.currentPath), this.currentPath.moveTo(t, e), this;
  }
  lineTo(t, e) {
    return this.currentPath.lineTo(t, e), this;
  }
  quadraticCurveTo(t, e, i, s) {
    return this.currentPath.quadraticCurveTo(t, e, i, s), this;
  }
  bezierCurveTo(t, e, i, s, n, r) {
    return this.currentPath.bezierCurveTo(t, e, i, s, n, r), this;
  }
  splineThru(t) {
    return this.currentPath.splineThru(t), this;
  }
  toShapes(t) {
    function e(y) {
      const x = [];
      for (let b = 0, M = y.length; b < M; b++) {
        const _ = y[b], v = new xi();
        v.curves = _.curves, x.push(v);
      }
      return x;
    }
    function i(y, x) {
      const b = x.length;
      let M = false;
      for (let _ = b - 1, v = 0; v < b; _ = v++) {
        let A = x[_], S = x[v], T = S.x - A.x, C = S.y - A.y;
        if (Math.abs(C) > Number.EPSILON) {
          if (C < 0 && (A = x[v], T = -T, S = x[_], C = -C), y.y < A.y || y.y > S.y) continue;
          if (y.y === A.y) {
            if (y.x === A.x) return true;
          } else {
            const B = C * (y.x - A.x) - T * (y.y - A.y);
            if (B === 0) return true;
            if (B < 0) continue;
            M = !M;
          }
        } else {
          if (y.y !== A.y) continue;
          if (S.x <= y.x && y.x <= A.x || A.x <= y.x && y.x <= S.x) return true;
        }
      }
      return M;
    }
    const s = $t.isClockWise, n = this.subPaths;
    if (n.length === 0) return [];
    let r, a, o;
    const h = [];
    if (n.length === 1) return a = n[0], o = new xi(), o.curves = a.curves, h.push(o), h;
    let c = !s(n[0].getPoints());
    c = t ? !c : c;
    const u = [], d = [];
    let p = [], f = 0, m;
    d[f] = void 0, p[f] = [];
    for (let y = 0, x = n.length; y < x; y++) a = n[y], m = a.getPoints(), r = s(m), r = t ? !r : r, r ? (!c && d[f] && f++, d[f] = { s: new xi(), p: m }, d[f].s.curves = a.curves, c && f++, p[f] = []) : p[f].push({ h: a, p: m[0] });
    if (!d[0]) return e(n);
    if (d.length > 1) {
      let y = false, x = 0;
      for (let b = 0, M = d.length; b < M; b++) u[b] = [];
      for (let b = 0, M = d.length; b < M; b++) {
        const _ = p[b];
        for (let v = 0; v < _.length; v++) {
          const A = _[v];
          let S = true;
          for (let T = 0; T < d.length; T++) i(A.p, d[T].p) && (b !== T && x++, S ? (S = false, u[T].push(A)) : y = true);
          S && u[b].push(A);
        }
      }
      x > 0 && y === false && (p = u);
    }
    let g;
    for (let y = 0, x = d.length; y < x; y++) {
      o = d[y].s, h.push(o), g = p[y];
      for (let b = 0, M = g.length; b < M; b++) o.holes.push(g[b].h);
    }
    return h;
  }
}
class mm extends Se {
  constructor(t, e = null) {
    super(), this.object = t, this.domElement = e, this.enabled = true, this.state = -1, this.keys = {}, this.mouseButtons = { LEFT: null, MIDDLE: null, RIGHT: null }, this.touches = { ONE: null, TWO: null };
  }
  connect(t) {
    if (t === void 0) {
      N("Controls: connect() now requires an element.");
      return;
    }
    this.domElement !== null && this.disconnect(), this.domElement = t;
  }
  disconnect() {
  }
  dispose() {
  }
  update() {
  }
}
function ud(l, t) {
  const e = l.image && l.image.width ? l.image.width / l.image.height : 1;
  return e > t ? (l.repeat.x = 1, l.repeat.y = e / t, l.offset.x = 0, l.offset.y = (1 - l.repeat.y) / 2) : (l.repeat.x = t / e, l.repeat.y = 1, l.offset.x = (1 - l.repeat.x) / 2, l.offset.y = 0), l;
}
function dd(l, t) {
  const e = l.image && l.image.width ? l.image.width / l.image.height : 1;
  return e > t ? (l.repeat.x = t / e, l.repeat.y = 1, l.offset.x = (1 - l.repeat.x) / 2, l.offset.y = 0) : (l.repeat.x = 1, l.repeat.y = e / t, l.offset.x = 0, l.offset.y = (1 - l.repeat.y) / 2), l;
}
function pd(l) {
  return l.repeat.x = 1, l.repeat.y = 1, l.offset.x = 0, l.offset.y = 0, l;
}
function fd(l, t, e, i) {
  const s = md(i);
  switch (e) {
    case Th:
      return l * t;
    case Mo:
      return l * t / s.components * s.byteLength;
    case wo:
      return l * t / s.components * s.byteLength;
    case zh:
      return l * t * 2 / s.components * s.byteLength;
    case Bh:
      return l * t * 2 / s.components * s.byteLength;
    case Ch:
      return l * t * 3 / s.components * s.byteLength;
    case Hi:
      return l * t * 4 / s.components * s.byteLength;
    case Fh:
      return l * t * 4 / s.components * s.byteLength;
    case kh:
    case Ph:
      return Math.floor((l + 3) / 4) * Math.floor((t + 3) / 4) * 8;
    case Rh:
    case Oh:
      return Math.floor((l + 3) / 4) * Math.floor((t + 3) / 4) * 16;
    case Nh:
    case Dh:
      return Math.max(l, 16) * Math.max(t, 8) / 4;
    case Eh:
    case Lh:
      return Math.max(l, 8) * Math.max(t, 8) / 2;
    case Vh:
    case Uh:
    case Gh:
    case qh:
      return Math.floor((l + 3) / 4) * Math.floor((t + 3) / 4) * 8;
    case Wh:
    case Hh:
    case Jh:
      return Math.floor((l + 3) / 4) * Math.floor((t + 3) / 4) * 16;
    case Xh:
      return Math.floor((l + 3) / 4) * Math.floor((t + 3) / 4) * 16;
    case Zh:
      return Math.floor((l + 4) / 5) * Math.floor((t + 3) / 4) * 16;
    case Yh:
      return Math.floor((l + 4) / 5) * Math.floor((t + 4) / 5) * 16;
    case $h:
      return Math.floor((l + 5) / 6) * Math.floor((t + 4) / 5) * 16;
    case jh:
      return Math.floor((l + 5) / 6) * Math.floor((t + 5) / 6) * 16;
    case Qh:
      return Math.floor((l + 7) / 8) * Math.floor((t + 4) / 5) * 16;
    case Kh:
      return Math.floor((l + 7) / 8) * Math.floor((t + 5) / 6) * 16;
    case tl:
      return Math.floor((l + 7) / 8) * Math.floor((t + 7) / 8) * 16;
    case el:
      return Math.floor((l + 9) / 10) * Math.floor((t + 4) / 5) * 16;
    case il:
      return Math.floor((l + 9) / 10) * Math.floor((t + 5) / 6) * 16;
    case sl:
      return Math.floor((l + 9) / 10) * Math.floor((t + 7) / 8) * 16;
    case nl:
      return Math.floor((l + 9) / 10) * Math.floor((t + 9) / 10) * 16;
    case rl:
      return Math.floor((l + 11) / 12) * Math.floor((t + 9) / 10) * 16;
    case al:
      return Math.floor((l + 11) / 12) * Math.floor((t + 11) / 12) * 16;
    case ol:
    case hl:
    case ll:
      return Math.ceil(l / 4) * Math.ceil(t / 4) * 16;
    case cl:
    case ul:
      return Math.ceil(l / 4) * Math.ceil(t / 4) * 8;
    case dl:
    case pl:
      return Math.ceil(l / 4) * Math.ceil(t / 4) * 16;
  }
  throw new Error(`Unable to determine texture byte length for ${e} format.`);
}
function md(l) {
  switch (l) {
    case lr:
    case gh:
      return { byteLength: 1, components: 1 };
    case bh:
    case xh:
    case wh:
      return { byteLength: 2, components: 1 };
    case _h:
    case vh:
      return { byteLength: 2, components: 4 };
    case nn:
    case Mh:
    case bi:
      return { byteLength: 4, components: 1 };
    case Sh:
    case Ah:
      return { byteLength: 4, components: 3 };
  }
  throw new Error(`Unknown texture type ${l}.`);
}
class ym {
  static contain(t, e) {
    return ud(t, e);
  }
  static cover(t, e) {
    return dd(t, e);
  }
  static fill(t) {
    return pd(t);
  }
  static getByteLength(t, e, i, s) {
    return fd(t, e, i, s);
  }
}
typeof __THREE_DEVTOOLS__ < "u" && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register", { detail: { revision: "183" } }));
typeof window < "u" && (window.__THREE__ ? N("WARNING: Multiple instances of Three.js being imported.") : window.__THREE__ = "183");
export {
  Hi as $,
  G as A,
  hh as B,
  Oo as C,
  Sc as D,
  jt as E,
  Hp as F,
  Gp as G,
  wh as H,
  Cd as I,
  ca as J,
  Xi as K,
  vt as L,
  Si as M,
  Kd as N,
  $ as O,
  Sd as P,
  aa as Q,
  yd as R,
  Xs as S,
  lt as T,
  or as U,
  Nt as V,
  Yt as W,
  pe as X,
  Zt as Y,
  Ot as Z,
  Zl as _,
  U as a,
  ph as a$,
  gr as a0,
  yr as a1,
  Yn as a2,
  ef as a3,
  Ou as a4,
  Nu as a5,
  Du as a6,
  Pu as a7,
  Lu as a8,
  Fu as a9,
  hi as aA,
  mt as aB,
  vi as aC,
  Mp as aD,
  wp as aE,
  _p as aF,
  bp as aG,
  dl as aH,
  Hh as aI,
  wi as aJ,
  Xf as aK,
  tt as aL,
  Et as aM,
  Df as aN,
  Ir as aO,
  lr as aP,
  up as aQ,
  Ih as aR,
  Qn as aS,
  kd as aT,
  Zr as aU,
  Ld as aV,
  rn as aW,
  _t as aX,
  pf as aY,
  uh as aZ,
  dh as a_,
  Vu as aa,
  tp as ab,
  ep as ac,
  ip as ad,
  sp as ae,
  rp as af,
  ap as ag,
  Se as ah,
  _f as ai,
  bt as aj,
  Qd as ak,
  jd as al,
  ar as am,
  H as an,
  P as ao,
  Fo as ap,
  cf as aq,
  hr as ar,
  eh as as,
  sn as at,
  ch as au,
  nn as av,
  Mh as aw,
  Lp as ax,
  Up as ay,
  cp as az,
  Rt as b,
  Dh as b$,
  hn as b0,
  af as b1,
  So as b2,
  jn as b3,
  $n as b4,
  yh as b5,
  mh as b6,
  fh as b7,
  Wp as b8,
  Dp as b9,
  ia as bA,
  ea as bB,
  ta as bC,
  qs as bD,
  Kr as bE,
  Qr as bF,
  jr as bG,
  _h as bH,
  vh as bI,
  Sh as bJ,
  Ah as bK,
  gh as bL,
  xh as bM,
  bh as bN,
  Th as bO,
  Ch as bP,
  Mo as bQ,
  wo as bR,
  Bh as bS,
  Fh as bT,
  kh as bU,
  Ph as bV,
  Rh as bW,
  Oh as bX,
  Eh as bY,
  Nh as bZ,
  Lh as b_,
  qp as ba,
  Np as bb,
  oa as bc,
  bi as bd,
  fd as be,
  Od as bf,
  Rd as bg,
  Gd as bh,
  Hd as bi,
  $r as bj,
  Ud as bk,
  Wd as bl,
  qd as bm,
  Jd as bn,
  Yr as bo,
  Vd as bp,
  Dd as bq,
  bd as br,
  Md as bs,
  wd as bt,
  Pd as bu,
  Fd as bv,
  Bd as bw,
  zd as bx,
  Xr as by,
  sa as bz,
  ua as c,
  Lr as c$,
  Vh as c0,
  Uh as c1,
  Wh as c2,
  Gh as c3,
  qh as c4,
  Jh as c5,
  Xh as c6,
  Zh as c7,
  Yh as c8,
  $h as c9,
  Ql as cA,
  jl as cB,
  Op as cC,
  Rp as cD,
  Ep as cE,
  kp as cF,
  Pp as cG,
  Fp as cH,
  ha as cI,
  Bp as cJ,
  Ip as cK,
  Cp as cL,
  Tp as cM,
  Ap as cN,
  zp as cO,
  Sp as cP,
  vp as cQ,
  Je as cR,
  Nd as cS,
  Ed as cT,
  lf as cU,
  Mf as cV,
  dp as cW,
  Lf as cX,
  Di as cY,
  Ft as cZ,
  ve as c_,
  jh as ca,
  Qh as cb,
  Kh as cc,
  tl as cd,
  el as ce,
  il as cf,
  sl as cg,
  nl as ch,
  rl as ci,
  al as cj,
  ol as ck,
  cl,
  ul as cm,
  pl as cn,
  pu as co,
  Jo as cp,
  du as cq,
  fu as cr,
  mu as cs,
  bu as ct,
  Ro as cu,
  au as cv,
  br as cw,
  Vl as cx,
  fr as cy,
  Ji as cz,
  Kt as d,
  Zp as d$,
  Rf as d0,
  _o as d1,
  rd as d2,
  tn as d3,
  zf as d4,
  qf as d5,
  Gf as d6,
  If as d7,
  Tc as d8,
  dm as d9,
  Yo as dA,
  vf as dB,
  Sf as dC,
  xr as dD,
  Bf as dE,
  an as dF,
  Yd as dG,
  Xd as dH,
  mm as dI,
  Ff as dJ,
  Eo as dK,
  Oc as dL,
  vu as dM,
  _d as dN,
  te as dO,
  Nc as dP,
  np as dQ,
  Qf as dR,
  Io as dS,
  kf as dT,
  ff as dU,
  zu as dV,
  lh as dW,
  om as dX,
  Su as dY,
  _r as dZ,
  jp as d_,
  na as da,
  Xu as db,
  Wf as dc,
  Ko as dd,
  Vf as de,
  Ef as df,
  pm as dg,
  gl as dh,
  Mc as di,
  Au as dj,
  Po as dk,
  Ai as dl,
  Kf as dm,
  xt as dn,
  cm as dp,
  lm as dq,
  Wu as dr,
  ue as ds,
  Nr as dt,
  hm as du,
  Af as dv,
  Mr as dw,
  Cc as dx,
  wr as dy,
  $f as dz,
  jo as e,
  Yu as e$,
  Ac as e0,
  vr as e1,
  Cf as e2,
  Ar as e3,
  pr as e4,
  dr as e5,
  Zf as e6,
  Kp as e7,
  tf as e8,
  rm as e9,
  wc as eA,
  fe as eB,
  Zo as eC,
  lp as eD,
  so as eE,
  $o as eF,
  fl as eG,
  yl as eH,
  ml as eI,
  gd as eJ,
  gu as eK,
  xu as eL,
  hp as eM,
  op as eN,
  cr as eO,
  Qs as eP,
  on as eQ,
  $d as eR,
  Zd as eS,
  er as eT,
  um as eU,
  sm as eV,
  _c as eW,
  am as eX,
  Ge as eY,
  Uf as eZ,
  Z as e_,
  nm as ea,
  Tr as eb,
  Of as ec,
  en as ed,
  Nl as ee,
  Uu as ef,
  lc as eg,
  xf as eh,
  bf as ei,
  mf as ej,
  Qi as ek,
  ra as el,
  Hs as em,
  Kn as en,
  cn as eo,
  nf as ep,
  sf as eq,
  qt as er,
  sc as es,
  Cr as et,
  zo as eu,
  qe as ev,
  Ue as ew,
  tm as ex,
  No as ey,
  Ec as ez,
  yu as f,
  Lo as f0,
  Do as f1,
  ln as f2,
  Tu as f3,
  yp as f4,
  gp as f5,
  hl as f6,
  ll as f7,
  xp as f8,
  uu as f9,
  Fr as fA,
  Pf as fB,
  ym as fC,
  qu as fD,
  kr as fE,
  Pr as fF,
  It as fG,
  mp as fH,
  fp as fI,
  pp as fJ,
  Rr as fK,
  yf as fL,
  gf as fM,
  th as fN,
  Jf as fO,
  Ks as fP,
  wf as fQ,
  vc as fR,
  df as fS,
  uf as fT,
  Co as fU,
  ru as fV,
  Js as fW,
  fi as fX,
  mi as fY,
  hf as fZ,
  of as f_,
  ji as fa,
  Yf as fb,
  Hf as fc,
  zr as fd,
  Ho as fe,
  xi as ff,
  Br as fg,
  fm as fh,
  $t as fi,
  mr as fj,
  im as fk,
  ac as fl,
  Le as fm,
  jf as fn,
  Qo as fo,
  Vo as fp,
  em as fq,
  ic as fr,
  $p as fs,
  Xp as ft,
  Nf as fu,
  Qp as fv,
  Jp as fw,
  Yp as fx,
  Ti as fy,
  xd as fz,
  Mu as g,
  Id as h,
  un as i,
  Qt as j,
  Y as k,
  Vp as l,
  rf as m,
  Ad as n,
  Gt as o,
  Bt as p,
  Td as q,
  zh as r,
  Mi as s,
  To as t,
  I as u,
  vo as v,
  N as w,
  vd as x,
  Tf as y,
  w as z
};
