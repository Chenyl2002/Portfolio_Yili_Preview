const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./threejs-override-KmpEGO8-.js","./three.core-BZngiA0R.js","./Game-CHvZjn_1.js","./preload-helper-PPVm8Dsz.js"])))=>i.map(i=>d[i]);
import { _ as l } from "./preload-helper-PPVm8Dsz.js";
import { R as h } from "./three.core-BZngiA0R.js";
(async () => {
  (function() {
    const s = document.createElement("link").relList;
    if (s && s.supports && s.supports("modulepreload")) return;
    for (const e of document.querySelectorAll('link[rel="modulepreload"]')) r(e);
    new MutationObserver((e) => {
      for (const t of e) if (t.type === "childList") for (const n of t.addedNodes) n.tagName === "LINK" && n.rel === "modulepreload" && r(n);
    }).observe(document, {
      childList: true,
      subtree: true
    });
    function i(e) {
      const t = {};
      return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), e.crossOrigin === "use-credentials" ? t.credentials = "include" : e.crossOrigin === "anonymous" ? t.credentials = "omit" : t.credentials = "same-origin", t;
    }
    function r(e) {
      if (e.ep) return;
      e.ep = true;
      const t = i(e);
      fetch(e.href, t);
    }
  })();
  function m({ document: o, reload: s = () => window.location.reload() }) {
    const i = o.querySelector(".js-graphics-fallback"), r = i.querySelector("h1"), e = i.querySelector("[data-fallback-status]"), t = i.querySelector("[data-fallback-retry]"), n = o.querySelector(".game");
    let u = false, a = false;
    return t.addEventListener("click", () => {
      if (!a) {
        a = true, t.disabled = true, t.setAttribute("aria-busy", "true"), e.textContent = "\u6B63\u5728\u91CD\u65B0\u8F7D\u5165\u9875\u9762\u5E76\u5C1D\u8BD5 3D \u573A\u666F\uFF1B\u5982\u679C\u4ECD\u4E0D\u53EF\u7528\uFF0C\u53EF\u7EE7\u7EED\u9605\u8BFB\u4E0B\u65B9\u4F5C\u54C1\u3002";
        try {
          s();
        } catch {
          a = false, t.disabled = false, t.removeAttribute("aria-busy"), e.textContent = "\u9875\u9762\u672A\u80FD\u91CD\u65B0\u8F7D\u5165\u3002\u53EF\u4F7F\u7528\u6D4F\u89C8\u5668\u5237\u65B0\uFF0C\u6216\u7EE7\u7EED\u9605\u8BFB\u4E0B\u65B9\u4F5C\u54C1\u3002";
        }
      }
    }), {
      show() {
        if (u) return false;
        u = true, o.documentElement.classList.add("is-graphics-fallback"), n.hidden = true, n.inert = true, n.setAttribute("aria-hidden", "true"), i.hidden = false, e.textContent = "3D \u573A\u666F\u6682\u65F6\u65E0\u6CD5\u663E\u793A\uFF0C\u5DF2\u5207\u6362\u4E3A\u53EF\u76F4\u63A5\u9605\u8BFB\u7684\u4F5C\u54C1\u96C6\u3002\u9879\u76EE\u8D44\u6599\u4E0E\u8054\u7CFB\u65B9\u5F0F\u4ECD\u53EF\u4F7F\u7528\u3002";
        for (const c of i.querySelectorAll("img[data-fallback-src]")) c.src = c.dataset.fallbackSrc, c.removeAttribute("data-fallback-src");
        return r.focus({
          preventScroll: true
        }), true;
      }
    };
  }
  async function f({ createGame: o, fallback: s, onCreated: i = () => {
  } }) {
    let r;
    try {
      return r = await o(() => s.show()), i(r), await r.ready, r;
    } catch (e) {
      return r == null ? void 0 : r.failGraphics(e), s.show(), null;
    }
  }
  const d = `
\u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2557   \u2588\u2588\u2557\u2588\u2588\u2588\u2557   \u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2557\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557                   
\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2551   \u2588\u2588\u2551\u2588\u2588\u2588\u2588\u2557  \u2588\u2588\u2551\u2588\u2588\u2554\u2550\u2550\u2550\u2588\u2588\u2557\u255A\u2550\u255D\u2588\u2588\u2554\u2550\u2550\u2550\u2550\u255D                   
\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D\u2588\u2588\u2551   \u2588\u2588\u2551\u2588\u2588\u2554\u2588\u2588\u2557 \u2588\u2588\u2551\u2588\u2588\u2551   \u2588\u2588\u2551   \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557                   
\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2551   \u2588\u2588\u2551\u2588\u2588\u2551\u255A\u2588\u2588\u2557\u2588\u2588\u2551\u2588\u2588\u2551   \u2588\u2588\u2551   \u255A\u2550\u2550\u2550\u2550\u2588\u2588\u2551                   
\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D\u2588\u2588\u2551  \u2588\u2588\u2551\u255A\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D\u2588\u2588\u2551 \u255A\u2588\u2588\u2588\u2588\u2551\u255A\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D   \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2551                   
\u255A\u2550\u2550\u2550\u2550\u2550\u255D \u255A\u2550\u255D  \u255A\u2550\u255D \u255A\u2550\u2550\u2550\u2550\u2550\u255D \u255A\u2550\u255D  \u255A\u2550\u2550\u2550\u255D \u255A\u2550\u2550\u2550\u2550\u2550\u255D    \u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D                   
                                                                       
\u2588\u2588\u2588\u2588\u2588\u2588\u2557  \u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2557     \u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2557 
\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u255A\u2550\u2550\u2588\u2588\u2554\u2550\u2550\u255D\u2588\u2588\u2554\u2550\u2550\u2550\u2550\u255D\u2588\u2588\u2554\u2550\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2551     \u2588\u2588\u2551\u2588\u2588\u2554\u2550\u2550\u2550\u2588\u2588\u2557
\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D\u2588\u2588\u2551   \u2588\u2588\u2551\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D   \u2588\u2588\u2551   \u2588\u2588\u2588\u2588\u2588\u2557  \u2588\u2588\u2551   \u2588\u2588\u2551\u2588\u2588\u2551     \u2588\u2588\u2551\u2588\u2588\u2551   \u2588\u2588\u2551
\u2588\u2588\u2554\u2550\u2550\u2550\u255D \u2588\u2588\u2551   \u2588\u2588\u2551\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557   \u2588\u2588\u2551   \u2588\u2588\u2554\u2550\u2550\u255D  \u2588\u2588\u2551   \u2588\u2588\u2551\u2588\u2588\u2551     \u2588\u2588\u2551\u2588\u2588\u2551   \u2588\u2588\u2551
\u2588\u2588\u2551     \u255A\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D\u2588\u2588\u2551  \u2588\u2588\u2551   \u2588\u2588\u2551   \u2588\u2588\u2551     \u255A\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557\u2588\u2588\u2551\u255A\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255D
\u255A\u2550\u255D      \u255A\u2550\u2550\u2550\u2550\u2550\u255D \u255A\u2550\u255D  \u255A\u2550\u255D   \u255A\u2550\u255D   \u255A\u2550\u255D      \u255A\u2550\u2550\u2550\u2550\u2550\u255D \u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D\u255A\u2550\u255D \u255A\u2550\u2550\u2550\u2550\u2550\u255D 

\u2554\u2550 Intro \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551 Thank you for visiting my portfolio, you sneaky developer!
\u2551 If you are curious about the stack and how I built this project, here\u2019s everything you need to know.
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D

\u2554\u2550 Socials \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551 Mail           \u21D2 simon.bruno.77@gmail.com
\u2551 X              \u21D2 https://x.com/bruno_simon
\u2551 BlueSKy        \u21D2 https://bsky.app/profile/bruno-simon.bsky.social
\u2551 Discord public \u21D2 https://discord.com/channels/769928116701233152/1445064878384480288
\u2551 Discord PM     \u21D2 https://discord.com/users/202907325722263553
\u2551 Youtube        \u21D2 https://www.youtube.com/@BrunoSimon
\u2551 Twitch         \u21D2 https://www.twitch.tv/bruno_simon_dev
\u2551 GitHub         \u21D2 https://github.com/brunosimon
\u2551 LinkedIn       \u21D2 https://www.linkedin.com/in/simonbruno77/
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D

\u2554\u2550 Debug \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551 You can access the debug mode by adding #debug at the end of the URL and reloading.
\u2551 Press [V] to toggle the free camera.
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D

\u2554\u2550 Three.js \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551 Three.js is the library I\u2019m using to render this 3D world (release: ${h})
\u2551 https://threejs.org/
\u2551 It was created by mr.doob (https://x.com/mrdoob, https://github.com/mrdoob),
\u2551 followed by hundreds of awesome developers,
\u2551 one of which being Sunag (https://x.com/sea3dformat, https://github.com/sunag) who added TSL,
\u2551 enabling the use of both WebGL and WebGPU, making this portfolio possible.
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D

\u2554\u2550 Three.js Journey \u2550\u2550\u2550\u2550\u2557
\u2551 If you want to learn Three.js, I got you covered with this huge course.
\u2551 https://threejs-journey.com/
\u2551 It contains everything you need to start building awesome stuff with Three.js (and much more).
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D

\u2554\u2550 Devlogs \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551 I\u2019ve been making devlogs since the very start of this portfolio
\u2551 and you can find them all on my Youtube channel.
\u2551 https://www.youtube.com/@BrunoSimon
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D

\u2554\u2550 Source code \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551 The code is available on GitHub under MIT license. Even the Blender files are there, so have fun!
\u2551 https://github.com/brunosimon/folio-2025
\u2551 For security reasons, I\u2019m not sharing the server code, but the portfolio works without it.
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D

\u2554\u2550 Musics \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551 The music you hear was made especially for this portfolio by the awesome Kounine (Linktree).
\u2551 https://linktr.ee/Kounine
\u2551 They are now under CC0 license, meaning you can do whatever you want with them!
\u2551 Download them here.
\u2551 https://github.com/brunosimon/folio-2025/tree/main/static/sounds/musics
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D

\u2554\u2550 Some more links \u2550\u2550\u2550\u2550\u2550\u2557
\u2551 Rapier (Physics library)  \u21D2 https://rapier.rs/
\u2551 Howler.js (Audio library) \u21D2 https://howlerjs.com/
\u2551 Amatic SC (Fonts)         \u21D2 https://fonts.google.com/specimen/Amatic+SC
\u2551 Nunito (Fonts).           \u21D2 https://fonts.google.com/specimen/Nunito?query=Nunito
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D
`;
  for (let o = 0; o < d.length; o++) d[o].match(/[╔║═╗╚╝╔╝]/);
  const p = m({
    document
  });
  await f({
    fallback: p,
    createGame: async (o) => {
      document.fonts && await Promise.allSettled([
        document.fonts.load("400 20px Nunito"),
        document.fonts.load('700 20px "Amatic SC"'),
        document.fonts.load('500 20px "Pally-Medium"'),
        document.fonts.load('700 20px "Yili Sans"')
      ]), await l(() => import("./threejs-override-KmpEGO8-.js"), __vite__mapDeps([0,1]), import.meta.url);
      const { Game: s } = await l(async () => {
        const { Game: i } = await import("./Game-CHvZjn_1.js").then(async (m2) => {
          await m2.__tla;
          return m2;
        }).then((r) => r.G);
        return {
          Game: i
        };
      }, __vite__mapDeps([2,3,1]), import.meta.url);
      return new s({
        onGraphicsFailure: o
      });
    },
    onCreated: (o) => {
    }
  });
})();
